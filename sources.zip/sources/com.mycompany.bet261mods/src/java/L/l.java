package L;

import android.os.Handler;
import android.os.Looper;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class l {
    public static Handler a(Looper looper) {
        return androidx.emoji2.text.b.c(looper);
    }
}
