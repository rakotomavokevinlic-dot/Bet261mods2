package l;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: l.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0099g implements Iterator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f1035a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1036c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1037d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C0093a f1038e;

    public C0099g(C0093a c0093a, int i2) {
        this.f1038e = c0093a;
        this.f1035a = i2;
        this.b = c0093a.d();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f1036c < this.b;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        Object objB = this.f1038e.b(this.f1036c, this.f1035a);
        this.f1036c++;
        this.f1037d = true;
        return objB;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f1037d) {
            throw new IllegalStateException();
        }
        int i2 = this.f1036c - 1;
        this.f1036c = i2;
        this.b--;
        this.f1037d = false;
        this.f1038e.g(i2);
    }
}
