package l;

import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: l.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0101i implements Iterator, Map.Entry {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1040a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C0093a f1042d;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1041c = false;
    public int b = -1;

    public C0101i(C0093a c0093a) {
        this.f1042d = c0093a;
        this.f1040a = c0093a.d() - 1;
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (!this.f1041c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        Map.Entry entry = (Map.Entry) obj;
        Object key = entry.getKey();
        int i2 = this.b;
        C0093a c0093a = this.f1042d;
        Object objB = c0093a.b(i2, 0);
        if (key != objB && (key == null || !key.equals(objB))) {
            return false;
        }
        Object value = entry.getValue();
        Object objB2 = c0093a.b(this.b, 1);
        return value == objB2 || (value != null && value.equals(objB2));
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        if (!this.f1041c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        return this.f1042d.b(this.b, 0);
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        if (!this.f1041c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        return this.f1042d.b(this.b, 1);
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.b < this.f1040a;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        if (!this.f1041c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        int i2 = this.b;
        C0093a c0093a = this.f1042d;
        Object objB = c0093a.b(i2, 0);
        Object objB2 = c0093a.b(this.b, 1);
        return (objB == null ? 0 : objB.hashCode()) ^ (objB2 != null ? objB2.hashCode() : 0);
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        this.b++;
        this.f1041c = true;
        return this;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f1041c) {
            throw new IllegalStateException();
        }
        this.f1042d.g(this.b);
        this.b--;
        this.f1040a--;
        this.f1041c = false;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        if (!this.f1041c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        C0093a c0093a = this.f1042d;
        int i2 = this.b;
        switch (c0093a.f1015d) {
            case 0:
                int i3 = (i2 << 1) + 1;
                Object[] objArr = ((C0094b) c0093a.f1016e).b;
                Object obj2 = objArr[i3];
                objArr[i3] = obj;
                return obj2;
            default:
                throw new UnsupportedOperationException("not a map");
        }
    }

    public final String toString() {
        return getKey() + "=" + getValue();
    }
}
