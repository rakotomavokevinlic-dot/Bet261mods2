package l;

import java.lang.reflect.Array;
import java.util.Map;
import java.util.Set;

/* JADX INFO: renamed from: l.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0093a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public C0100h f1013a;
    public C0100h b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C0102j f1014c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1015d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1016e;

    public /* synthetic */ C0093a(int i2, Object obj) {
        this.f1015d = i2;
        this.f1016e = obj;
    }

    public static boolean h(Set set, Object obj) {
        if (set == obj) {
            return true;
        }
        if (!(obj instanceof Set)) {
            return false;
        }
        Set set2 = (Set) obj;
        try {
            if (set.size() == set2.size()) {
                return set.containsAll(set2);
            }
            return false;
        } catch (ClassCastException | NullPointerException unused) {
            return false;
        }
    }

    public final void a() {
        switch (this.f1015d) {
            case 0:
                ((C0094b) this.f1016e).clear();
                break;
            default:
                ((C0095c) this.f1016e).clear();
                break;
        }
    }

    public final Object b(int i2, int i3) {
        switch (this.f1015d) {
            case 0:
                return ((C0094b) this.f1016e).b[(i2 << 1) + i3];
            default:
                return ((C0095c) this.f1016e).b[i2];
        }
    }

    public final Map c() {
        switch (this.f1015d) {
            case 0:
                return (C0094b) this.f1016e;
            default:
                throw new UnsupportedOperationException("not a map");
        }
    }

    public final int d() {
        switch (this.f1015d) {
            case 0:
                return ((C0094b) this.f1016e).f1048c;
            default:
                return ((C0095c) this.f1016e).f1024c;
        }
    }

    public final int e(Object obj) {
        switch (this.f1015d) {
            case 0:
                return ((C0094b) this.f1016e).d(obj);
            default:
                C0095c c0095c = (C0095c) this.f1016e;
                return obj == null ? c0095c.d() : c0095c.c(obj.hashCode(), obj);
        }
    }

    public final int f(Object obj) {
        switch (this.f1015d) {
            case 0:
                return ((C0094b) this.f1016e).f(obj);
            default:
                C0095c c0095c = (C0095c) this.f1016e;
                return obj == null ? c0095c.d() : c0095c.c(obj.hashCode(), obj);
        }
    }

    public final void g(int i2) {
        switch (this.f1015d) {
            case 0:
                ((C0094b) this.f1016e).h(i2);
                break;
            default:
                ((C0095c) this.f1016e).e(i2);
                break;
        }
    }

    public final Object[] i(Object[] objArr, int i2) {
        int iD = d();
        if (objArr.length < iD) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), iD);
        }
        for (int i3 = 0; i3 < iD; i3++) {
            objArr[i3] = b(i3, i2);
        }
        if (objArr.length > iD) {
            objArr[iD] = null;
        }
        return objArr;
    }
}
