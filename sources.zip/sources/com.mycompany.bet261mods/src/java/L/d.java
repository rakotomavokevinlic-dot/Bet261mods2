package L;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract /* synthetic */ class d {
    public static /* synthetic */ void a(Object obj) {
        if (obj != null) {
            throw new ClassCastException();
        }
    }
}
