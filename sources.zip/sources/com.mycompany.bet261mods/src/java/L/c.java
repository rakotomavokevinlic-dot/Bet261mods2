package L;

import java.util.TreeMap;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f87a;
    public final String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f88c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f89d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f90e;
    public final int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f91g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int[] f92h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final TreeMap f93i;

    public c(String str, String str2, long j2, int i2, int i3, int i4, int[] iArr, TreeMap treeMap) {
        this.f87a = str;
        this.b = str2;
        this.f88c = j2;
        this.f90e = i2;
        this.f = i3;
        this.f91g = i4;
        this.f92h = iArr;
        this.f93i = treeMap;
    }
}
