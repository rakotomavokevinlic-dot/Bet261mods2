package L;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f111a;
    public final byte[] b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f112c;

    public p(int i2, byte[] bArr, boolean z2) {
        this.f111a = i2;
        this.b = bArr;
        this.f112c = z2;
    }
}
