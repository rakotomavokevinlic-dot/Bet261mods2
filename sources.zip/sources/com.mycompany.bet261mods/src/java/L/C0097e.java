package l;

/* JADX INFO: renamed from: l.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0097e implements Cloneable {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Object f1027e = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1028a;
    public long[] b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object[] f1029c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1030d;

    public final void a() {
        int i2 = this.f1030d;
        long[] jArr = this.b;
        Object[] objArr = this.f1029c;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            Object obj = objArr[i4];
            if (obj != f1027e) {
                if (i4 != i3) {
                    jArr[i3] = jArr[i4];
                    objArr[i3] = obj;
                    objArr[i4] = null;
                }
                i3++;
            }
        }
        this.f1028a = false;
        this.f1030d = i3;
    }

    public final void b(long j2, Object obj) {
        int iB = AbstractC0096d.b(this.b, this.f1030d, j2);
        if (iB >= 0) {
            this.f1029c[iB] = obj;
            return;
        }
        int i2 = ~iB;
        int i3 = this.f1030d;
        if (i2 < i3) {
            Object[] objArr = this.f1029c;
            if (objArr[i2] == f1027e) {
                this.b[i2] = j2;
                objArr[i2] = obj;
                return;
            }
        }
        if (this.f1028a && i3 >= this.b.length) {
            a();
            i2 = ~AbstractC0096d.b(this.b, this.f1030d, j2);
        }
        int i4 = this.f1030d;
        if (i4 >= this.b.length) {
            int i5 = (i4 + 1) * 8;
            int i6 = 4;
            while (true) {
                if (i6 >= 32) {
                    break;
                }
                int i7 = (1 << i6) - 12;
                if (i5 <= i7) {
                    i5 = i7;
                    break;
                }
                i6++;
            }
            int i8 = i5 / 8;
            long[] jArr = new long[i8];
            Object[] objArr2 = new Object[i8];
            long[] jArr2 = this.b;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.f1029c;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.b = jArr;
            this.f1029c = objArr2;
        }
        int i9 = this.f1030d - i2;
        if (i9 != 0) {
            long[] jArr3 = this.b;
            int i10 = i2 + 1;
            System.arraycopy(jArr3, i2, jArr3, i10, i9);
            Object[] objArr4 = this.f1029c;
            System.arraycopy(objArr4, i2, objArr4, i10, this.f1030d - i2);
        }
        this.b[i2] = j2;
        this.f1029c[i2] = obj;
        this.f1030d++;
    }

    public final Object clone() {
        try {
            C0097e c0097e = (C0097e) super.clone();
            c0097e.b = (long[]) this.b.clone();
            c0097e.f1029c = (Object[]) this.f1029c.clone();
            return c0097e;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public final String toString() {
        if (this.f1028a) {
            a();
        }
        int i2 = this.f1030d;
        if (i2 <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(i2 * 28);
        sb.append('{');
        for (int i3 = 0; i3 < this.f1030d; i3++) {
            if (i3 > 0) {
                sb.append(", ");
            }
            if (this.f1028a) {
                a();
            }
            sb.append(this.b[i3]);
            sb.append('=');
            if (this.f1028a) {
                a();
            }
            Object obj = this.f1029c[i3];
            if (obj != this) {
                sb.append(obj);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
