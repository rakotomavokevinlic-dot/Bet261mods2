package l;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* JADX INFO: renamed from: l.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0100h implements Set {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1039a;
    public final /* synthetic */ C0093a b;

    public /* synthetic */ C0100h(C0093a c0093a, int i2) {
        this.f1039a = i2;
        this.b = c0093a;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean add(Object obj) {
        switch (this.f1039a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean addAll(Collection collection) {
        switch (this.f1039a) {
            case 0:
                C0093a c0093a = this.b;
                int iD = c0093a.d();
                Iterator it = collection.iterator();
                while (it.hasNext()) {
                    Map.Entry entry = (Map.Entry) it.next();
                    Object key = entry.getKey();
                    Object value = entry.getValue();
                    switch (c0093a.f1015d) {
                        case 0:
                            ((C0094b) c0093a.f1016e).put(key, value);
                            break;
                        default:
                            ((C0095c) c0093a.f1016e).add(key);
                            break;
                    }
                }
                return iD != c0093a.d();
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final void clear() {
        switch (this.f1039a) {
            case 0:
                this.b.a();
                break;
            default:
                this.b.a();
                break;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean contains(Object obj) {
        switch (this.f1039a) {
            case 0:
                if (!(obj instanceof Map.Entry)) {
                    return false;
                }
                Map.Entry entry = (Map.Entry) obj;
                Object key = entry.getKey();
                C0093a c0093a = this.b;
                int iE = c0093a.e(key);
                if (iE < 0) {
                    return false;
                }
                Object objB = c0093a.b(iE, 1);
                Object value = entry.getValue();
                return objB == value || (objB != null && objB.equals(value));
            default:
                return this.b.e(obj) >= 0;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean containsAll(Collection collection) {
        switch (this.f1039a) {
            case 0:
                Iterator it = collection.iterator();
                while (it.hasNext()) {
                    if (!contains(it.next())) {
                        break;
                    }
                }
                break;
            default:
                Map mapC = this.b.c();
                Iterator it2 = collection.iterator();
                while (it2.hasNext()) {
                    if (!mapC.containsKey(it2.next())) {
                        break;
                    }
                }
                break;
        }
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean equals(Object obj) {
        switch (this.f1039a) {
        }
        return C0093a.h(this, obj);
    }

    @Override // java.util.Set, java.util.Collection
    public final int hashCode() {
        switch (this.f1039a) {
            case 0:
                C0093a c0093a = this.b;
                int iHashCode = 0;
                for (int iD = c0093a.d() - 1; iD >= 0; iD--) {
                    Object objB = c0093a.b(iD, 0);
                    Object objB2 = c0093a.b(iD, 1);
                    iHashCode += (objB == null ? 0 : objB.hashCode()) ^ (objB2 == null ? 0 : objB2.hashCode());
                }
                return iHashCode;
            default:
                C0093a c0093a2 = this.b;
                int iHashCode2 = 0;
                for (int iD2 = c0093a2.d() - 1; iD2 >= 0; iD2--) {
                    Object objB3 = c0093a2.b(iD2, 0);
                    iHashCode2 += objB3 == null ? 0 : objB3.hashCode();
                }
                return iHashCode2;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean isEmpty() {
        switch (this.f1039a) {
            case 0:
                if (this.b.d() == 0) {
                }
                break;
            default:
                if (this.b.d() == 0) {
                }
                break;
        }
        return false;
    }

    @Override // java.util.Set, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        switch (this.f1039a) {
            case 0:
                return new C0101i(this.b);
            default:
                return new C0099g(this.b, 0);
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean remove(Object obj) {
        switch (this.f1039a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                C0093a c0093a = this.b;
                int iE = c0093a.e(obj);
                if (iE < 0) {
                    return false;
                }
                c0093a.g(iE);
                return true;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean removeAll(Collection collection) {
        switch (this.f1039a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                Map mapC = this.b.c();
                int size = mapC.size();
                Iterator it = collection.iterator();
                while (it.hasNext()) {
                    mapC.remove(it.next());
                }
                return size != mapC.size();
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean retainAll(Collection collection) {
        switch (this.f1039a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                Map mapC = this.b.c();
                int size = mapC.size();
                Iterator it = mapC.keySet().iterator();
                while (it.hasNext()) {
                    if (!collection.contains(it.next())) {
                        it.remove();
                    }
                }
                return size != mapC.size();
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final int size() {
        switch (this.f1039a) {
        }
        return this.b.d();
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        switch (this.f1039a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                return this.b.i(objArr, 0);
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray() {
        switch (this.f1039a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                C0093a c0093a = this.b;
                int iD = c0093a.d();
                Object[] objArr = new Object[iD];
                for (int i2 = 0; i2 < iD; i2++) {
                    objArr[i2] = c0093a.b(i2, 0);
                }
                return objArr;
        }
    }
}
