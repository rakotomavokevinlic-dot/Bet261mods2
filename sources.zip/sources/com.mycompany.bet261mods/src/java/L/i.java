package L;

import android.content.Context;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final /* synthetic */ class i implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f104a;
    public final /* synthetic */ Context b;

    public /* synthetic */ i(Context context, int i2) {
        this.f104a = i2;
        this.b = context;
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x006e  */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void run() {
        /*
            r11 = this;
            int r0 = r11.f104a
            switch(r0) {
                case 0: goto L97;
                case 1: goto L89;
                default: goto L5;
            }
        L5:
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 1
            r2 = 33
            if (r0 < r2) goto L86
            android.content.ComponentName r3 = new android.content.ComponentName
            android.content.Context r4 = r11.b
            java.lang.String r5 = "androidx.appcompat.app.AppLocalesMetadataHolderService"
            r3.<init>(r4, r5)
            android.content.pm.PackageManager r5 = r4.getPackageManager()
            int r5 = r5.getComponentEnabledSetting(r3)
            if (r5 == r1) goto L86
            java.lang.String r5 = "locale"
            if (r0 < r2) goto L5d
            l.c r0 = e.o.f510g
            java.util.Iterator r0 = r0.iterator()
        L29:
            r2 = r0
            l.g r2 = (l.C0099g) r2
            boolean r6 = r2.hasNext()
            if (r6 == 0) goto L4b
            java.lang.Object r2 = r2.next()
            java.lang.ref.WeakReference r2 = (java.lang.ref.WeakReference) r2
            java.lang.Object r2 = r2.get()
            e.o r2 = (e.o) r2
            if (r2 == 0) goto L29
            e.B r2 = (e.LayoutInflaterFactory2C0004B) r2
            android.content.Context r2 = r2.f391k
            if (r2 == 0) goto L29
            java.lang.Object r0 = r2.getSystemService(r5)
            goto L4c
        L4b:
            r0 = 0
        L4c:
            if (r0 == 0) goto L62
            android.os.LocaleList r0 = e.AbstractC0017l.a(r0)
            u.c r2 = new u.c
            u.d r6 = new u.d
            r6.<init>(r0)
            r2.<init>(r6)
            goto L64
        L5d:
            u.c r2 = e.o.f507c
            if (r2 == 0) goto L62
            goto L64
        L62:
            u.c r2 = u.C0126c.b
        L64:
            u.d r0 = r2.f1140a
            android.os.LocaleList r0 = r0.f1141a
            boolean r0 = r0.isEmpty()
            if (r0 == 0) goto L7f
            java.lang.String r0 = o.e.f(r4)
            java.lang.Object r2 = r4.getSystemService(r5)
            if (r2 == 0) goto L7f
            android.os.LocaleList r0 = e.AbstractC0016k.a(r0)
            e.AbstractC0017l.b(r2, r0)
        L7f:
            android.content.pm.PackageManager r0 = r4.getPackageManager()
            r0.setComponentEnabledSetting(r3, r1, r1)
        L86:
            e.o.f = r1
            return
        L89:
            L.e r0 = new L.e
            r0.<init>()
            F.d r1 = L.g.f94a
            r2 = 0
            android.content.Context r3 = r11.b
            L.g.s(r3, r0, r1, r2)
            return
        L97:
            java.util.concurrent.ThreadPoolExecutor r4 = new java.util.concurrent.ThreadPoolExecutor
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.MILLISECONDS
            java.util.concurrent.LinkedBlockingQueue r10 = new java.util.concurrent.LinkedBlockingQueue
            r10.<init>()
            r6 = 1
            r7 = 0
            r5 = 0
            r4.<init>(r5, r6, r7, r9, r10)
            L.i r0 = new L.i
            android.content.Context r1 = r11.b
            r2 = 1
            r0.<init>(r1, r2)
            r4.execute(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: L.i.run():void");
    }
}
