package L;

import android.content.res.AssetManager;
import android.os.Build;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Executor f81a;
    public final f b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final byte[] f82c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final File f83d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f84e;
    public boolean f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public c[] f85g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public byte[] f86h;

    public b(AssetManager assetManager, Executor executor, f fVar, String str, File file) {
        this.f81a = executor;
        this.b = fVar;
        this.f84e = str;
        this.f83d = file;
        int i2 = Build.VERSION.SDK_INT;
        byte[] bArr = null;
        if (i2 <= 34) {
            switch (i2) {
                case 24:
                case 25:
                    bArr = g.f99h;
                    break;
                case 26:
                    bArr = g.f98g;
                    break;
                case 27:
                    bArr = g.f;
                    break;
                case 28:
                case 29:
                case 30:
                    bArr = g.f97e;
                    break;
                case 31:
                case 32:
                case 33:
                case 34:
                    bArr = g.f96d;
                    break;
            }
        }
        this.f82c = bArr;
    }

    public final FileInputStream a(AssetManager assetManager, String str) {
        try {
            return assetManager.openFd(str).createInputStream();
        } catch (FileNotFoundException e2) {
            String message = e2.getMessage();
            if (message == null || !message.contains("compressed")) {
                return null;
            }
            this.b.q();
            return null;
        }
    }

    public final void b(final int i2, final Serializable serializable) {
        this.f81a.execute(new Runnable() { // from class: L.a
            @Override // java.lang.Runnable
            public final void run() {
                this.f79a.b.l(i2, serializable);
            }
        });
    }
}
