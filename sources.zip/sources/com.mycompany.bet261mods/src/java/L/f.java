package L;

import java.io.Serializable;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface f {
    void l(int i2, Serializable serializable);

    void q();
}
