package l;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Map;
import java.util.Set;

/* JADX INFO: renamed from: l.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0094b extends C0103k implements Map {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public C0093a f1017h;

    @Override // java.util.Map
    public final Set entrySet() {
        if (this.f1017h == null) {
            this.f1017h = new C0093a(0, this);
        }
        C0093a c0093a = this.f1017h;
        if (c0093a.f1013a == null) {
            c0093a.f1013a = new C0100h(c0093a, 0);
        }
        return c0093a.f1013a;
    }

    @Override // java.util.Map
    public final Set keySet() {
        if (this.f1017h == null) {
            this.f1017h = new C0093a(0, this);
        }
        C0093a c0093a = this.f1017h;
        if (c0093a.b == null) {
            c0093a.b = new C0100h(c0093a, 1);
        }
        return c0093a.b;
    }

    @Override // java.util.Map
    public final void putAll(Map map) {
        int size = map.size() + this.f1048c;
        int i2 = this.f1048c;
        int[] iArr = this.f1047a;
        if (iArr.length < size) {
            Object[] objArr = this.b;
            a(size);
            if (this.f1048c > 0) {
                System.arraycopy(iArr, 0, this.f1047a, 0, i2);
                System.arraycopy(objArr, 0, this.b, 0, i2 << 1);
            }
            C0103k.b(iArr, objArr, i2);
        }
        if (this.f1048c != i2) {
            throw new ConcurrentModificationException();
        }
        for (Map.Entry entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    @Override // java.util.Map
    public final Collection values() {
        if (this.f1017h == null) {
            this.f1017h = new C0093a(0, this);
        }
        C0093a c0093a = this.f1017h;
        if (c0093a.f1014c == null) {
            c0093a.f1014c = new C0102j(c0093a);
        }
        return c0093a.f1014c;
    }
}
