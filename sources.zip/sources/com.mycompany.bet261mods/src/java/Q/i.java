package q;

import android.content.res.ColorStateList;
import android.content.res.Resources;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class i {
    public static int a(Resources resources, int i2, Resources.Theme theme) {
        return resources.getColor(i2, theme);
    }

    public static ColorStateList b(Resources resources, int i2, Resources.Theme theme) {
        return resources.getColorStateList(i2, theme);
    }
}
