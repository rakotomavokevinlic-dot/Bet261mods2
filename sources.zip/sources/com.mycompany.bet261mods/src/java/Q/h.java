package q;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class h implements e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final W.d f1099a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1100c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f1101d;

    public h(W.d dVar, int i2, int i3, String str) {
        this.f1099a = dVar;
        this.f1100c = i2;
        this.b = i3;
        this.f1101d = str;
    }
}
