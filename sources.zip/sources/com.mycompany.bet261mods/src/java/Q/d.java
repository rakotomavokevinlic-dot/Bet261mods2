package q;

import android.content.res.TypedArray;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class d {
    public static int a(TypedArray typedArray, int i2) {
        return typedArray.getType(i2);
    }
}
