package q;

import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ColorStateList f1102a;
    public final Configuration b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1103c;

    public j(ColorStateList colorStateList, Configuration configuration, Resources.Theme theme) {
        this.f1102a = colorStateList;
        this.b = configuration;
        this.f1103c = theme == null ? 0 : theme.hashCode();
    }
}
