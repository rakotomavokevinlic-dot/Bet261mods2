package q;

import android.content.res.Resources;
import java.util.Objects;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Resources f1104a;
    public final Resources.Theme b;

    public k(Resources resources, Resources.Theme theme) {
        this.f1104a = resources;
        this.b = theme;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && k.class == obj.getClass()) {
            k kVar = (k) obj;
            if (this.f1104a.equals(kVar.f1104a) && Objects.equals(this.b, kVar.b)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(this.f1104a, this.b);
    }
}
