package q;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class f implements e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g[] f1094a;

    public f(g[] gVarArr) {
        this.f1094a = gVarArr;
    }
}
