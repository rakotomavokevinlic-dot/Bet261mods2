package q;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f1095a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f1096c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f1097d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f1098e;
    public final int f;

    public g(String str, int i2, boolean z2, String str2, int i3, int i4) {
        this.f1095a = str;
        this.b = i2;
        this.f1096c = z2;
        this.f1097d = str2;
        this.f1098e = i3;
        this.f = i4;
    }
}
