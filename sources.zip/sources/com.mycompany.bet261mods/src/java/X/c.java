package X;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class c {
    public static final c b = new c(0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final c f293c = new c(1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f294a;

    public /* synthetic */ c(int i2) {
        this.f294a = i2;
    }

    public String toString() {
        switch (this.f294a) {
            case 1:
                return "kotlin.Unit";
            default:
                return super.toString();
        }
    }
}
