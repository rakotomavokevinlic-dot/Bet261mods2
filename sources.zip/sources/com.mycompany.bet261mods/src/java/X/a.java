package X;

import java.io.Serializable;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class a implements Serializable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f290a;
    public final Object b;

    public a(Object obj, Object obj2) {
        this.f290a = obj;
        this.b = obj2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return e0.c.a(this.f290a, aVar.f290a) && e0.c.a(this.b, aVar.b);
    }

    public final int hashCode() {
        Object obj = this.f290a;
        int iHashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        Object obj2 = this.b;
        return iHashCode + (obj2 != null ? obj2.hashCode() : 0);
    }

    public final String toString() {
        return "(" + this.f290a + ", " + this.b + ')';
    }
}
