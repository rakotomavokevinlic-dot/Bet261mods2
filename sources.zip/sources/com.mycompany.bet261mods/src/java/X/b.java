package X;

import androidx.activity.o;
import java.io.Serializable;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class b implements Serializable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public o f291a;
    public volatile Object b = c.b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f292c = this;

    public b(o oVar) {
        this.f291a = oVar;
    }

    public final Object a() {
        Object objA;
        Object obj = this.b;
        c cVar = c.b;
        if (obj != cVar) {
            return obj;
        }
        synchronized (this.f292c) {
            objA = this.b;
            if (objA == cVar) {
                o oVar = this.f291a;
                e0.c.b(oVar);
                objA = oVar.a();
                this.b = objA;
                this.f291a = null;
            }
        }
        return objA;
    }

    public final String toString() {
        return this.b != c.b ? String.valueOf(a()) : "Lazy value not initialized yet.";
    }
}
