package y;

import android.view.View;
import android.view.WindowInsets;

/* JADX INFO: renamed from: y.B, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class AbstractC0143B {
    public static f0 a(View view) {
        WindowInsets rootWindowInsets = view.getRootWindowInsets();
        if (rootWindowInsets == null) {
            return null;
        }
        f0 f0VarC = f0.c(rootWindowInsets, null);
        d0 d0Var = f0VarC.f1202a;
        d0Var.p(f0VarC);
        d0Var.d(view.getRootView());
        return f0VarC;
    }

    public static int b(View view) {
        return view.getScrollIndicators();
    }

    public static void c(View view, int i2) {
        view.setScrollIndicators(i2);
    }

    public static void d(View view, int i2, int i3) {
        view.setScrollIndicators(i2, i3);
    }
}
