package Y;

import java.lang.reflect.Array;
import java.util.AbstractList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class a extends AbstractList implements List {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Object[] f295d = new Object[0];

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f296a;
    public Object[] b = f295d;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f297c;

    public final void a(int i2, Collection collection) {
        Iterator it = collection.iterator();
        int length = this.b.length;
        while (i2 < length && it.hasNext()) {
            this.b[i2] = it.next();
            i2++;
        }
        int i3 = this.f296a;
        for (int i4 = 0; i4 < i3 && it.hasNext(); i4++) {
            this.b[i4] = it.next();
        }
        this.f297c = collection.size() + this.f297c;
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i2, Object obj) {
        int length;
        int i3 = this.f297c;
        if (i2 < 0 || i2 > i3) {
            throw new IndexOutOfBoundsException("index: " + i2 + ", size: " + i3);
        }
        if (i2 == i3) {
            addLast(obj);
            return;
        }
        if (i2 == 0) {
            addFirst(obj);
            return;
        }
        b(i3 + 1);
        int iD = d(this.f296a + i2);
        int i4 = this.f297c;
        if (i2 < ((i4 + 1) >> 1)) {
            if (iD == 0) {
                Object[] objArr = this.b;
                e0.c.e(objArr, "<this>");
                iD = objArr.length;
            }
            int i5 = iD - 1;
            int i6 = this.f296a;
            if (i6 == 0) {
                Object[] objArr2 = this.b;
                e0.c.e(objArr2, "<this>");
                length = objArr2.length - 1;
            } else {
                length = i6 - 1;
            }
            int i7 = this.f296a;
            if (i5 >= i7) {
                Object[] objArr3 = this.b;
                objArr3[length] = objArr3[i7];
                b.k0(objArr3, objArr3, i7, i7 + 1, i5 + 1);
            } else {
                Object[] objArr4 = this.b;
                b.k0(objArr4, objArr4, i7 - 1, i7, objArr4.length);
                Object[] objArr5 = this.b;
                objArr5[objArr5.length - 1] = objArr5[0];
                b.k0(objArr5, objArr5, 0, 1, i5 + 1);
            }
            this.b[i5] = obj;
            this.f296a = length;
        } else {
            int iD2 = d(this.f296a + i4);
            if (iD < iD2) {
                Object[] objArr6 = this.b;
                b.k0(objArr6, objArr6, iD + 1, iD, iD2);
            } else {
                Object[] objArr7 = this.b;
                b.k0(objArr7, objArr7, 1, 0, iD2);
                Object[] objArr8 = this.b;
                objArr8[0] = objArr8[objArr8.length - 1];
                b.k0(objArr8, objArr8, iD + 1, iD, objArr8.length - 1);
            }
            this.b[iD] = obj;
        }
        this.f297c++;
    }

    @Override // java.util.AbstractList, java.util.List
    public final boolean addAll(int i2, Collection collection) {
        e0.c.e(collection, "elements");
        int i3 = this.f297c;
        if (i2 < 0 || i2 > i3) {
            throw new IndexOutOfBoundsException("index: " + i2 + ", size: " + i3);
        }
        if (collection.isEmpty()) {
            return false;
        }
        int i4 = this.f297c;
        if (i2 == i4) {
            return addAll(collection);
        }
        b(collection.size() + i4);
        int iD = d(this.f296a + this.f297c);
        int iD2 = d(this.f296a + i2);
        int size = collection.size();
        if (i2 >= ((this.f297c + 1) >> 1)) {
            int i5 = iD2 + size;
            if (iD2 < iD) {
                int i6 = size + iD;
                Object[] objArr = this.b;
                if (i6 <= objArr.length) {
                    b.k0(objArr, objArr, i5, iD2, iD);
                } else if (i5 >= objArr.length) {
                    b.k0(objArr, objArr, i5 - objArr.length, iD2, iD);
                } else {
                    int length = iD - (i6 - objArr.length);
                    b.k0(objArr, objArr, 0, length, iD);
                    Object[] objArr2 = this.b;
                    b.k0(objArr2, objArr2, i5, iD2, length);
                }
            } else {
                Object[] objArr3 = this.b;
                b.k0(objArr3, objArr3, size, 0, iD);
                Object[] objArr4 = this.b;
                if (i5 >= objArr4.length) {
                    b.k0(objArr4, objArr4, i5 - objArr4.length, iD2, objArr4.length);
                } else {
                    b.k0(objArr4, objArr4, 0, objArr4.length - size, objArr4.length);
                    Object[] objArr5 = this.b;
                    b.k0(objArr5, objArr5, i5, iD2, objArr5.length - size);
                }
            }
            a(iD2, collection);
            return true;
        }
        int i7 = this.f296a;
        int length2 = i7 - size;
        if (iD2 < i7) {
            Object[] objArr6 = this.b;
            b.k0(objArr6, objArr6, length2, i7, objArr6.length);
            if (size >= iD2) {
                Object[] objArr7 = this.b;
                b.k0(objArr7, objArr7, objArr7.length - size, 0, iD2);
            } else {
                Object[] objArr8 = this.b;
                b.k0(objArr8, objArr8, objArr8.length - size, 0, size);
                Object[] objArr9 = this.b;
                b.k0(objArr9, objArr9, 0, size, iD2);
            }
        } else if (length2 >= 0) {
            Object[] objArr10 = this.b;
            b.k0(objArr10, objArr10, length2, i7, iD2);
        } else {
            Object[] objArr11 = this.b;
            length2 += objArr11.length;
            int i8 = iD2 - i7;
            int length3 = objArr11.length - length2;
            if (length3 >= i8) {
                b.k0(objArr11, objArr11, length2, i7, iD2);
            } else {
                b.k0(objArr11, objArr11, length2, i7, i7 + length3);
                Object[] objArr12 = this.b;
                b.k0(objArr12, objArr12, 0, this.f296a + length3, iD2);
            }
        }
        this.f296a = length2;
        int length4 = iD2 - size;
        if (length4 < 0) {
            length4 += this.b.length;
        }
        a(length4, collection);
        return true;
    }

    public final void addFirst(Object obj) {
        b(this.f297c + 1);
        int length = this.f296a;
        if (length == 0) {
            Object[] objArr = this.b;
            e0.c.e(objArr, "<this>");
            length = objArr.length;
        }
        int i2 = length - 1;
        this.f296a = i2;
        this.b[i2] = obj;
        this.f297c++;
    }

    public final void addLast(Object obj) {
        b(this.f297c + 1);
        this.b[d(this.f296a + this.f297c)] = obj;
        this.f297c++;
    }

    public final void b(int i2) {
        if (i2 < 0) {
            throw new IllegalStateException("Deque is too big.");
        }
        Object[] objArr = this.b;
        if (i2 <= objArr.length) {
            return;
        }
        if (objArr == f295d) {
            if (i2 < 10) {
                i2 = 10;
            }
            this.b = new Object[i2];
            return;
        }
        int length = objArr.length;
        int i3 = length + (length >> 1);
        if (i3 - i2 < 0) {
            i3 = i2;
        }
        if (i3 - 2147483639 > 0) {
            i3 = i2 > 2147483639 ? Integer.MAX_VALUE : 2147483639;
        }
        Object[] objArr2 = new Object[i3];
        b.k0(objArr, objArr2, 0, this.f296a, objArr.length);
        Object[] objArr3 = this.b;
        int length2 = objArr3.length;
        int i4 = this.f296a;
        b.k0(objArr3, objArr2, length2 - i4, 0, i4);
        this.f296a = 0;
        this.b = objArr2;
    }

    public final int c(int i2) {
        e0.c.e(this.b, "<this>");
        if (i2 == r0.length - 1) {
            return 0;
        }
        return i2 + 1;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final void clear() {
        int iD = d(this.f296a + this.f297c);
        int i2 = this.f296a;
        if (i2 < iD) {
            Object[] objArr = this.b;
            e0.c.e(objArr, "<this>");
            Arrays.fill(objArr, i2, iD, (Object) null);
        } else if (!isEmpty()) {
            Object[] objArr2 = this.b;
            Arrays.fill(objArr2, this.f296a, objArr2.length, (Object) null);
            Object[] objArr3 = this.b;
            e0.c.e(objArr3, "<this>");
            Arrays.fill(objArr3, 0, iD, (Object) null);
        }
        this.f296a = 0;
        this.f297c = 0;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean contains(Object obj) {
        return indexOf(obj) != -1;
    }

    public final int d(int i2) {
        Object[] objArr = this.b;
        return i2 >= objArr.length ? i2 - objArr.length : i2;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i2) {
        int i3 = this.f297c;
        if (i2 >= 0 && i2 < i3) {
            return this.b[d(this.f296a + i2)];
        }
        throw new IndexOutOfBoundsException("index: " + i2 + ", size: " + i3);
    }

    @Override // java.util.AbstractList, java.util.List
    public final int indexOf(Object obj) {
        int i2;
        int iD = d(this.f296a + this.f297c);
        int length = this.f296a;
        if (length < iD) {
            while (length < iD) {
                if (e0.c.a(obj, this.b[length])) {
                    i2 = this.f296a;
                } else {
                    length++;
                }
            }
            return -1;
        }
        if (length < iD) {
            return -1;
        }
        int length2 = this.b.length;
        while (true) {
            if (length >= length2) {
                for (int i3 = 0; i3 < iD; i3++) {
                    if (e0.c.a(obj, this.b[i3])) {
                        length = i3 + this.b.length;
                        i2 = this.f296a;
                    }
                }
                return -1;
            }
            if (e0.c.a(obj, this.b[length])) {
                i2 = this.f296a;
                break;
            }
            length++;
        }
        return length - i2;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean isEmpty() {
        return this.f297c == 0;
    }

    @Override // java.util.AbstractList, java.util.List
    public final int lastIndexOf(Object obj) {
        int length;
        int i2;
        int iD = d(this.f296a + this.f297c);
        int i3 = this.f296a;
        if (i3 < iD) {
            length = iD - 1;
            if (i3 <= length) {
                while (!e0.c.a(obj, this.b[length])) {
                    if (length != i3) {
                        length--;
                    }
                }
                i2 = this.f296a;
                return length - i2;
            }
            return -1;
        }
        if (i3 > iD) {
            int i4 = iD - 1;
            while (true) {
                if (-1 >= i4) {
                    Object[] objArr = this.b;
                    e0.c.e(objArr, "<this>");
                    length = objArr.length - 1;
                    int i5 = this.f296a;
                    if (i5 <= length) {
                        while (!e0.c.a(obj, this.b[length])) {
                            if (length != i5) {
                                length--;
                            }
                        }
                        i2 = this.f296a;
                    }
                } else {
                    if (e0.c.a(obj, this.b[i4])) {
                        length = i4 + this.b.length;
                        i2 = this.f296a;
                        break;
                    }
                    i4--;
                }
            }
        }
        return -1;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object remove(int i2) {
        int i3 = this.f297c;
        if (i2 < 0 || i2 >= i3) {
            throw new IndexOutOfBoundsException("index: " + i2 + ", size: " + i3);
        }
        if (i2 == i3 - 1) {
            return removeLast();
        }
        if (i2 == 0) {
            return removeFirst();
        }
        int iD = d(this.f296a + i2);
        Object[] objArr = this.b;
        Object obj = objArr[iD];
        int i4 = this.f297c;
        if (i2 < (i4 >> 1)) {
            int i5 = this.f296a;
            if (iD >= i5) {
                b.k0(objArr, objArr, i5 + 1, i5, iD);
            } else {
                b.k0(objArr, objArr, 1, 0, iD);
                Object[] objArr2 = this.b;
                objArr2[0] = objArr2[objArr2.length - 1];
                int i6 = this.f296a;
                b.k0(objArr2, objArr2, i6 + 1, i6, objArr2.length - 1);
            }
            Object[] objArr3 = this.b;
            int i7 = this.f296a;
            objArr3[i7] = null;
            this.f296a = c(i7);
        } else {
            int iD2 = d((i4 - 1) + this.f296a);
            if (iD <= iD2) {
                Object[] objArr4 = this.b;
                b.k0(objArr4, objArr4, iD, iD + 1, iD2 + 1);
            } else {
                Object[] objArr5 = this.b;
                b.k0(objArr5, objArr5, iD, iD + 1, objArr5.length);
                Object[] objArr6 = this.b;
                objArr6[objArr6.length - 1] = objArr6[0];
                b.k0(objArr6, objArr6, 0, 1, iD2 + 1);
            }
            this.b[iD2] = null;
        }
        this.f297c--;
        return obj;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean removeAll(Collection collection) {
        int iD;
        e0.c.e(collection, "elements");
        boolean z2 = false;
        z2 = false;
        z2 = false;
        if (!isEmpty() && this.b.length != 0) {
            int iD2 = d(this.f296a + this.f297c);
            int i2 = this.f296a;
            if (i2 < iD2) {
                iD = i2;
                while (i2 < iD2) {
                    Object obj = this.b[i2];
                    if (collection.contains(obj)) {
                        z2 = true;
                    } else {
                        this.b[iD] = obj;
                        iD++;
                    }
                    i2++;
                }
                Object[] objArr = this.b;
                e0.c.e(objArr, "<this>");
                Arrays.fill(objArr, iD, iD2, (Object) null);
            } else {
                int length = this.b.length;
                boolean z3 = false;
                int i3 = i2;
                while (i2 < length) {
                    Object[] objArr2 = this.b;
                    Object obj2 = objArr2[i2];
                    objArr2[i2] = null;
                    if (collection.contains(obj2)) {
                        z3 = true;
                    } else {
                        this.b[i3] = obj2;
                        i3++;
                    }
                    i2++;
                }
                iD = d(i3);
                for (int i4 = 0; i4 < iD2; i4++) {
                    Object[] objArr3 = this.b;
                    Object obj3 = objArr3[i4];
                    objArr3[i4] = null;
                    if (collection.contains(obj3)) {
                        z3 = true;
                    } else {
                        this.b[iD] = obj3;
                        iD = c(iD);
                    }
                }
                z2 = z3;
            }
            if (z2) {
                int length2 = iD - this.f296a;
                if (length2 < 0) {
                    length2 += this.b.length;
                }
                this.f297c = length2;
            }
        }
        return z2;
    }

    public final Object removeFirst() {
        if (isEmpty()) {
            throw new NoSuchElementException("ArrayDeque is empty.");
        }
        Object[] objArr = this.b;
        int i2 = this.f296a;
        Object obj = objArr[i2];
        objArr[i2] = null;
        this.f296a = c(i2);
        this.f297c--;
        return obj;
    }

    public final Object removeLast() {
        if (isEmpty()) {
            throw new NoSuchElementException("ArrayDeque is empty.");
        }
        int iD = d((this.f297c - 1) + this.f296a);
        Object[] objArr = this.b;
        Object obj = objArr[iD];
        objArr[iD] = null;
        this.f297c--;
        return obj;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean retainAll(Collection collection) {
        int iD;
        e0.c.e(collection, "elements");
        boolean z2 = false;
        z2 = false;
        z2 = false;
        if (!isEmpty() && this.b.length != 0) {
            int iD2 = d(this.f296a + this.f297c);
            int i2 = this.f296a;
            if (i2 < iD2) {
                iD = i2;
                while (i2 < iD2) {
                    Object obj = this.b[i2];
                    if (collection.contains(obj)) {
                        this.b[iD] = obj;
                        iD++;
                    } else {
                        z2 = true;
                    }
                    i2++;
                }
                Object[] objArr = this.b;
                e0.c.e(objArr, "<this>");
                Arrays.fill(objArr, iD, iD2, (Object) null);
            } else {
                int length = this.b.length;
                boolean z3 = false;
                int i3 = i2;
                while (i2 < length) {
                    Object[] objArr2 = this.b;
                    Object obj2 = objArr2[i2];
                    objArr2[i2] = null;
                    if (collection.contains(obj2)) {
                        this.b[i3] = obj2;
                        i3++;
                    } else {
                        z3 = true;
                    }
                    i2++;
                }
                iD = d(i3);
                for (int i4 = 0; i4 < iD2; i4++) {
                    Object[] objArr3 = this.b;
                    Object obj3 = objArr3[i4];
                    objArr3[i4] = null;
                    if (collection.contains(obj3)) {
                        this.b[iD] = obj3;
                        iD = c(iD);
                    } else {
                        z3 = true;
                    }
                }
                z2 = z3;
            }
            if (z2) {
                int length2 = iD - this.f296a;
                if (length2 < 0) {
                    length2 += this.b.length;
                }
                this.f297c = length2;
            }
        }
        return z2;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i2, Object obj) {
        int i3 = this.f297c;
        if (i2 < 0 || i2 >= i3) {
            throw new IndexOutOfBoundsException("index: " + i2 + ", size: " + i3);
        }
        int iD = d(this.f296a + i2);
        Object[] objArr = this.b;
        Object obj2 = objArr[iD];
        objArr[iD] = obj;
        return obj2;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f297c;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final Object[] toArray() {
        return toArray(new Object[this.f297c]);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final Object[] toArray(Object[] objArr) {
        e0.c.e(objArr, "array");
        int length = objArr.length;
        int i2 = this.f297c;
        if (length < i2) {
            Object objNewInstance = Array.newInstance(objArr.getClass().getComponentType(), i2);
            e0.c.c(objNewInstance, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.arrayOfNulls>");
            objArr = (Object[]) objNewInstance;
        }
        int iD = d(this.f296a + this.f297c);
        int i3 = this.f296a;
        if (i3 < iD) {
            b.k0(this.b, objArr, 0, i3, iD);
        } else if (!isEmpty()) {
            Object[] objArr2 = this.b;
            b.k0(objArr2, objArr, 0, this.f296a, objArr2.length);
            Object[] objArr3 = this.b;
            b.k0(objArr3, objArr, objArr3.length - this.f296a, 0, iD);
        }
        int length2 = objArr.length;
        int i4 = this.f297c;
        if (length2 > i4) {
            objArr[i4] = null;
        }
        return objArr;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean remove(Object obj) {
        int iIndexOf = indexOf(obj);
        if (iIndexOf == -1) {
            return false;
        }
        remove(iIndexOf);
        return true;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean add(Object obj) {
        addLast(obj);
        return true;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean addAll(Collection collection) {
        e0.c.e(collection, "elements");
        if (collection.isEmpty()) {
            return false;
        }
        b(collection.size() + this.f297c);
        a(d(this.f296a + this.f297c), collection);
        return true;
    }
}
