package y;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import i.C0084x;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class K {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static WeakHashMap f1165a;
    public static Field b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static boolean f1166c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final C0169v f1167d = new C0169v();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final ViewTreeObserverOnGlobalLayoutListenerC0171x f1168e = new ViewTreeObserverOnGlobalLayoutListenerC0171x();

    public static Q a(View view) {
        if (f1165a == null) {
            f1165a = new WeakHashMap();
        }
        Q q2 = (Q) f1165a.get(view);
        if (q2 != null) {
            return q2;
        }
        Q q3 = new Q(view);
        f1165a.put(view, q3);
        return q3;
    }

    public static boolean b(View view, KeyEvent keyEvent) {
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        ArrayList arrayList = J.f1162d;
        J j2 = (J) view.getTag(2131230892);
        if (j2 == null) {
            j2 = new J();
            j2.f1163a = null;
            j2.b = null;
            j2.f1164c = null;
            view.setTag(2131230892, j2);
        }
        if (keyEvent.getAction() == 0) {
            WeakHashMap weakHashMap = j2.f1163a;
            if (weakHashMap != null) {
                weakHashMap.clear();
            }
            ArrayList arrayList2 = J.f1162d;
            if (!arrayList2.isEmpty()) {
                synchronized (arrayList2) {
                    try {
                        if (j2.f1163a == null) {
                            j2.f1163a = new WeakHashMap();
                        }
                        for (int size = arrayList2.size() - 1; size >= 0; size--) {
                            ArrayList arrayList3 = J.f1162d;
                            View view2 = (View) ((WeakReference) arrayList3.get(size)).get();
                            if (view2 == null) {
                                arrayList3.remove(size);
                            } else {
                                j2.f1163a.put(view2, Boolean.TRUE);
                                for (ViewParent parent = view2.getParent(); parent instanceof View; parent = parent.getParent()) {
                                    j2.f1163a.put((View) parent, Boolean.TRUE);
                                }
                            }
                        }
                    } finally {
                    }
                }
            }
        }
        View viewA = j2.a(view);
        if (keyEvent.getAction() == 0) {
            int keyCode = keyEvent.getKeyCode();
            if (viewA != null && !KeyEvent.isModifierKey(keyCode)) {
                if (j2.b == null) {
                    j2.b = new SparseArray();
                }
                j2.b.put(keyCode, new WeakReference(viewA));
            }
        }
        return viewA != null;
    }

    public static View.AccessibilityDelegate c(View view) {
        if (Build.VERSION.SDK_INT >= 29) {
            return AbstractC0146E.a(view);
        }
        if (f1166c) {
            return null;
        }
        if (b == null) {
            try {
                Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                b = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable unused) {
                f1166c = true;
                return null;
            }
        }
        try {
            Object obj = b.get(view);
            if (obj instanceof View.AccessibilityDelegate) {
                return (View.AccessibilityDelegate) obj;
            }
            return null;
        } catch (Throwable unused2) {
            f1166c = true;
            return null;
        }
    }

    public static String[] d(C0084x c0084x) {
        return Build.VERSION.SDK_INT >= 31 ? AbstractC0148G.a(c0084x) : (String[]) c0084x.getTag(2131230888);
    }

    public static void e(View view, int i2) {
        Object tag;
        AccessibilityManager accessibilityManager = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled()) {
            int i3 = Build.VERSION.SDK_INT;
            Object objB = null;
            if (i3 >= 28) {
                tag = AbstractC0145D.b(view);
            } else {
                tag = view.getTag(2131230885);
                if (!CharSequence.class.isInstance(tag)) {
                    tag = null;
                }
            }
            boolean z2 = ((CharSequence) tag) != null && view.isShown() && view.getWindowVisibility() == 0;
            if (view.getAccessibilityLiveRegion() != 0 || z2) {
                AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain();
                accessibilityEventObtain.setEventType(z2 ? 32 : 2048);
                accessibilityEventObtain.setContentChangeTypes(i2);
                if (z2) {
                    List<CharSequence> text = accessibilityEventObtain.getText();
                    if (i3 >= 28) {
                        objB = AbstractC0145D.b(view);
                    } else {
                        Object tag2 = view.getTag(2131230885);
                        if (CharSequence.class.isInstance(tag2)) {
                            objB = tag2;
                        }
                    }
                    text.add((CharSequence) objB);
                    if (view.getImportantForAccessibility() == 0) {
                        view.setImportantForAccessibility(1);
                    }
                }
                view.sendAccessibilityEventUnchecked(accessibilityEventObtain);
                return;
            }
            if (i2 != 32) {
                if (view.getParent() != null) {
                    try {
                        view.getParent().notifySubtreeAccessibilityStateChanged(view, view, i2);
                        return;
                    } catch (AbstractMethodError e2) {
                        Log.e("ViewCompat", view.getParent().getClass().getSimpleName().concat(" does not fully implement ViewParent"), e2);
                        return;
                    }
                }
                return;
            }
            AccessibilityEvent accessibilityEventObtain2 = AccessibilityEvent.obtain();
            view.onInitializeAccessibilityEvent(accessibilityEventObtain2);
            accessibilityEventObtain2.setEventType(32);
            accessibilityEventObtain2.setContentChangeTypes(i2);
            accessibilityEventObtain2.setSource(view);
            view.onPopulateAccessibilityEvent(accessibilityEventObtain2);
            List<CharSequence> text2 = accessibilityEventObtain2.getText();
            if (i3 >= 28) {
                objB = AbstractC0145D.b(view);
            } else {
                Object tag3 = view.getTag(2131230885);
                if (CharSequence.class.isInstance(tag3)) {
                    objB = tag3;
                }
            }
            text2.add((CharSequence) objB);
            accessibilityManager.sendAccessibilityEvent(accessibilityEventObtain2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static C0155g f(View view, C0155g c0155g) {
        if (Log.isLoggable("ViewCompat", 3)) {
            Log.d("ViewCompat", "performReceiveContent: " + c0155g + ", view=" + view.getClass().getSimpleName() + "[" + view.getId() + "]");
        }
        if (Build.VERSION.SDK_INT >= 31) {
            return AbstractC0148G.b(view, c0155g);
        }
        InterfaceC0165q interfaceC0165q = (InterfaceC0165q) view.getTag(2131230887);
        r rVar = f1167d;
        if (interfaceC0165q == null) {
            if (view instanceof r) {
                rVar = (r) view;
            }
            return rVar.a(c0155g);
        }
        C0155g c0155gA = ((D.u) interfaceC0165q).a(view, c0155g);
        if (c0155gA == null) {
            return null;
        }
        if (view instanceof r) {
            rVar = (r) view;
        }
        return rVar.a(c0155gA);
    }

    public static void g(View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i2) {
        if (Build.VERSION.SDK_INT >= 29) {
            AbstractC0146E.d(view, context, iArr, attributeSet, typedArray, i2, 0);
        }
    }

    public static void h(View view, C0150b c0150b) {
        if (c0150b == null && (c(view) instanceof C0149a)) {
            c0150b = new C0150b();
        }
        if (view.getImportantForAccessibility() == 0) {
            view.setImportantForAccessibility(1);
        }
        view.setAccessibilityDelegate(c0150b == null ? null : c0150b.b);
    }

    public static void i(View view, CharSequence charSequence) {
        new C0170w(2131230885, CharSequence.class, 8, 28, 1).d(view, charSequence);
        ViewTreeObserverOnGlobalLayoutListenerC0171x viewTreeObserverOnGlobalLayoutListenerC0171x = f1168e;
        if (charSequence == null) {
            viewTreeObserverOnGlobalLayoutListenerC0171x.f1221a.remove(view);
            view.removeOnAttachStateChangeListener(viewTreeObserverOnGlobalLayoutListenerC0171x);
            view.getViewTreeObserver().removeOnGlobalLayoutListener(viewTreeObserverOnGlobalLayoutListenerC0171x);
        } else {
            viewTreeObserverOnGlobalLayoutListenerC0171x.f1221a.put(view, Boolean.valueOf(view.isShown() && view.getWindowVisibility() == 0));
            view.addOnAttachStateChangeListener(viewTreeObserverOnGlobalLayoutListenerC0171x);
            if (view.isAttachedToWindow()) {
                view.getViewTreeObserver().addOnGlobalLayoutListener(viewTreeObserverOnGlobalLayoutListenerC0171x);
            }
        }
    }
}
