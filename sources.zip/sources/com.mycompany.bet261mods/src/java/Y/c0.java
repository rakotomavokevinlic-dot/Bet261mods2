package y;

import android.view.View;
import android.view.WindowInsets;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class c0 extends b0 {

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final f0 f1196q = f0.c(WindowInsets.CONSUMED, null);

    public c0(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    @Override // y.Y, y.d0
    public r.c f(int i2) {
        return r.c.b(this.f1185c.getInsets(e0.a(i2)));
    }

    @Override // y.Y, y.d0
    public final void d(View view) {
    }
}
