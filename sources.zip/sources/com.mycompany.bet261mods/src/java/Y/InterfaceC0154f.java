package y;

import android.content.ClipData;
import android.view.ContentInfo;

/* JADX INFO: renamed from: y.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface InterfaceC0154f {
    int f();

    ClipData j();

    int n();

    ContentInfo s();
}
