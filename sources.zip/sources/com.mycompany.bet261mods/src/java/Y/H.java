package y;

import android.view.ContentInfo;
import android.view.OnReceiveContentListener;
import android.view.View;
import java.util.Objects;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class H implements OnReceiveContentListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final InterfaceC0165q f1161a;

    public H(InterfaceC0165q interfaceC0165q) {
        this.f1161a = interfaceC0165q;
    }

    @Override // android.view.OnReceiveContentListener
    public final ContentInfo onReceiveContent(View view, ContentInfo contentInfo) {
        C0155g c0155g = new C0155g(new C.j(contentInfo));
        C0155g c0155gA = ((D.u) this.f1161a).a(view, c0155g);
        if (c0155gA == null) {
            return null;
        }
        if (c0155gA == c0155g) {
            return contentInfo;
        }
        ContentInfo contentInfoS = c0155gA.f1203a.s();
        Objects.requireNonNull(contentInfoS);
        return AbstractC0151c.e(contentInfoS);
    }
}
