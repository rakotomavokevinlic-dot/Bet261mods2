package y;

/* JADX INFO: renamed from: y.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface InterfaceC0165q {
}
