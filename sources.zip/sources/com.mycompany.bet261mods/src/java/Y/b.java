package Y;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class b extends D.g {
    public static final void k0(Object[] objArr, Object[] objArr2, int i2, int i3, int i4) {
        e0.c.e(objArr, "<this>");
        e0.c.e(objArr2, "destination");
        System.arraycopy(objArr, i3, objArr2, i2, i4 - i3);
    }
}
