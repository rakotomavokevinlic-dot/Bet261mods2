package y;

import android.os.Build;
import android.view.View;
import java.util.Objects;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public class d0 {
    public static final f0 b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f0 f1197a;

    static {
        int i2 = Build.VERSION.SDK_INT;
        b = (i2 >= 30 ? new W() : i2 >= 29 ? new V() : new U()).b().f1202a.a().f1202a.b().f1202a.c();
    }

    public d0(f0 f0Var) {
        this.f1197a = f0Var;
    }

    public f0 a() {
        return this.f1197a;
    }

    public f0 b() {
        return this.f1197a;
    }

    public f0 c() {
        return this.f1197a;
    }

    public C0158j e() {
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d0)) {
            return false;
        }
        d0 d0Var = (d0) obj;
        return n() == d0Var.n() && m() == d0Var.m() && Objects.equals(j(), d0Var.j()) && Objects.equals(h(), d0Var.h()) && Objects.equals(e(), d0Var.e());
    }

    public r.c f(int i2) {
        return r.c.f1117e;
    }

    public r.c g() {
        return j();
    }

    public r.c h() {
        return r.c.f1117e;
    }

    public int hashCode() {
        return Objects.hash(Boolean.valueOf(n()), Boolean.valueOf(m()), j(), h(), e());
    }

    public r.c i() {
        return j();
    }

    public r.c j() {
        return r.c.f1117e;
    }

    public r.c k() {
        return j();
    }

    public f0 l(int i2, int i3, int i4, int i5) {
        return b;
    }

    public boolean m() {
        return false;
    }

    public boolean n() {
        return false;
    }

    public void d(View view) {
    }

    public void o(r.c[] cVarArr) {
    }

    public void p(f0 f0Var) {
    }

    public void q(r.c cVar) {
    }
}
