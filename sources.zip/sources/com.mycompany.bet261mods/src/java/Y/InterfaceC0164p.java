package y;

import android.view.View;

/* JADX INFO: renamed from: y.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface InterfaceC0164p {
    f0 a(View view, f0 f0Var);
}
