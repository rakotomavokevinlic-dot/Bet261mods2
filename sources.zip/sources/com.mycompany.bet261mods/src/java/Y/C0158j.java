package y;

import android.view.DisplayCutout;
import java.util.Objects;

/* JADX INFO: renamed from: y.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0158j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final DisplayCutout f1210a;

    public C0158j(DisplayCutout displayCutout) {
        this.f1210a = displayCutout;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0158j.class != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.f1210a, ((C0158j) obj).f1210a);
    }

    public final int hashCode() {
        return androidx.emoji2.text.b.b(this.f1210a);
    }

    public final String toString() {
        return "DisplayCutoutCompat{" + this.f1210a + "}";
    }
}
