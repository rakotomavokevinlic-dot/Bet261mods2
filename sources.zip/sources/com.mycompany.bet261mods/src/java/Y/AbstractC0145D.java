package y;

import android.view.View;
import java.util.Objects;
import l.C0103k;

/* JADX INFO: renamed from: y.D, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class AbstractC0145D {
    public static void a(View view, I i2) {
        C0103k c0103k = (C0103k) view.getTag(2131230893);
        if (c0103k == null) {
            c0103k = new C0103k();
            view.setTag(2131230893, c0103k);
        }
        Objects.requireNonNull(i2);
        View.OnUnhandledKeyEventListener viewOnUnhandledKeyEventListenerC0144C = new ViewOnUnhandledKeyEventListenerC0144C();
        c0103k.put(i2, viewOnUnhandledKeyEventListenerC0144C);
        view.addOnUnhandledKeyEventListener(viewOnUnhandledKeyEventListenerC0144C);
    }

    public static CharSequence b(View view) {
        return view.getAccessibilityPaneTitle();
    }

    public static boolean c(View view) {
        return view.isAccessibilityHeading();
    }

    public static boolean d(View view) {
        return view.isScreenReaderFocusable();
    }

    public static void e(View view, I i2) {
        View.OnUnhandledKeyEventListener onUnhandledKeyEventListener;
        C0103k c0103k = (C0103k) view.getTag(2131230893);
        if (c0103k == null || (onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener) c0103k.getOrDefault(i2, null)) == null) {
            return;
        }
        view.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener);
    }

    public static <T> T f(View view, int i2) {
        return (T) view.requireViewById(i2);
    }

    public static void g(View view, boolean z2) {
        view.setAccessibilityHeading(z2);
    }

    public static void h(View view, CharSequence charSequence) {
        view.setAccessibilityPaneTitle(charSequence);
    }

    public static void i(View view, A.a aVar) {
        view.setAutofillId(null);
    }

    public static void j(View view, boolean z2) {
        view.setScreenReaderFocusable(z2);
    }
}
