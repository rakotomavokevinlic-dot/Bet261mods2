package y;

import android.view.WindowInsets;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public class b0 extends a0 {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public r.c f1193n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public r.c f1194o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public r.c f1195p;

    public b0(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
        this.f1193n = null;
        this.f1194o = null;
        this.f1195p = null;
    }

    @Override // y.d0
    public r.c g() {
        if (this.f1194o == null) {
            this.f1194o = r.c.b(this.f1185c.getMandatorySystemGestureInsets());
        }
        return this.f1194o;
    }

    @Override // y.d0
    public r.c i() {
        if (this.f1193n == null) {
            this.f1193n = r.c.b(this.f1185c.getSystemGestureInsets());
        }
        return this.f1193n;
    }

    @Override // y.d0
    public r.c k() {
        if (this.f1195p == null) {
            this.f1195p = r.c.b(this.f1185c.getTappableElementInsets());
        }
        return this.f1195p;
    }

    @Override // y.Y, y.d0
    public f0 l(int i2, int i3, int i4, int i5) {
        return f0.c(this.f1185c.inset(i2, i3, i4, i5), null);
    }

    @Override // y.Z, y.d0
    public void q(r.c cVar) {
    }
}
