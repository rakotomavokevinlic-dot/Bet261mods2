package Y;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class g extends D.g {
    public static Map k0(ArrayList arrayList) {
        e eVar = e.f300a;
        int size = arrayList.size();
        if (size == 0) {
            return eVar;
        }
        if (size == 1) {
            X.a aVar = (X.a) arrayList.get(0);
            e0.c.e(aVar, "pair");
            Map mapSingletonMap = Collections.singletonMap(aVar.f290a, aVar.b);
            e0.c.d(mapSingletonMap, "singletonMap(pair.first, pair.second)");
            return mapSingletonMap;
        }
        int size2 = arrayList.size();
        if (size2 >= 0) {
            size2 = size2 < 3 ? size2 + 1 : size2 < 1073741824 ? (int) ((size2 / 0.75f) + 1.0f) : Integer.MAX_VALUE;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(size2);
        int size3 = arrayList.size();
        int i2 = 0;
        while (i2 < size3) {
            Object obj = arrayList.get(i2);
            i2++;
            X.a aVar2 = (X.a) obj;
            linkedHashMap.put(aVar2.f290a, aVar2.b);
        }
        return linkedHashMap;
    }
}
