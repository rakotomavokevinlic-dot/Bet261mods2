package y;

import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: renamed from: y.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface InterfaceC0162n {
    void a(View view, View view2, int i2, int i3);

    void c(ViewGroup viewGroup, int i2, int i3, int i4, int i5, int i6);

    void d(View view, int i2);

    void e(ViewGroup viewGroup, int i2, int i3, int[] iArr, int i4);

    boolean f(View view, View view2, int i2, int i3);
}
