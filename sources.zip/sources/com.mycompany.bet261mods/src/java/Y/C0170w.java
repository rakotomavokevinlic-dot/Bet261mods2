package y;

import android.text.TextUtils;
import android.view.View;

/* JADX INFO: renamed from: y.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0170w extends F.c {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1220e;

    public C0170w(int i2, Class cls, int i3, int i4, int i5) {
        this.f1220e = i5;
        this.f53a = i2;
        this.f55d = cls;
        this.f54c = i3;
        this.b = i4;
    }

    @Override // F.c
    public final Object b(View view) {
        switch (this.f1220e) {
            case 0:
                return Boolean.valueOf(AbstractC0145D.d(view));
            case 1:
                return AbstractC0145D.b(view);
            default:
                return Boolean.valueOf(AbstractC0145D.c(view));
        }
    }

    @Override // F.c
    public final void c(View view, Object obj) {
        switch (this.f1220e) {
            case 0:
                AbstractC0145D.j(view, ((Boolean) obj).booleanValue());
                break;
            case 1:
                AbstractC0145D.h(view, (CharSequence) obj);
                break;
            default:
                AbstractC0145D.g(view, ((Boolean) obj).booleanValue());
                break;
        }
    }

    @Override // F.c
    public final boolean e(Object obj, Object obj2) {
        switch (this.f1220e) {
            case 0:
                Boolean bool = (Boolean) obj;
                Boolean bool2 = (Boolean) obj2;
                return !((bool != null && bool.booleanValue()) == (bool2 != null && bool2.booleanValue()));
            case 1:
                return !TextUtils.equals((CharSequence) obj, (CharSequence) obj2);
            default:
                Boolean bool3 = (Boolean) obj;
                Boolean bool4 = (Boolean) obj2;
                return !((bool3 != null && bool3.booleanValue()) == (bool4 != null && bool4.booleanValue()));
        }
    }
}
