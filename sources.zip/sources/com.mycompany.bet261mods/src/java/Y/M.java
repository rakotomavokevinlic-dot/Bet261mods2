package y;

import android.view.ViewConfiguration;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class M {
    public static int a(ViewConfiguration viewConfiguration, int i2, int i3, int i4) {
        return viewConfiguration.getScaledMaximumFlingVelocity(i2, i3, i4);
    }

    public static int b(ViewConfiguration viewConfiguration, int i2, int i3, int i4) {
        return viewConfiguration.getScaledMinimumFlingVelocity(i2, i3, i4);
    }
}
