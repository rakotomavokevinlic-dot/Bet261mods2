package y;

import android.net.Uri;
import android.os.Bundle;

/* JADX INFO: renamed from: y.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface InterfaceC0152d {
    void a(Bundle bundle);

    void e(Uri uri);

    C0155g k();

    void w(int i2);
}
