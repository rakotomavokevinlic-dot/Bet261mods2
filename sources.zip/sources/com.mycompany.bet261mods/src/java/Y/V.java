package y;

import android.view.WindowInsets;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public class V extends X {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final WindowInsets.Builder f1179a;

    public V() {
        this.f1179a = Q.a.d();
    }

    @Override // y.X
    public f0 b() {
        a();
        f0 f0VarC = f0.c(this.f1179a.build(), null);
        f0VarC.f1202a.o(null);
        return f0VarC;
    }

    @Override // y.X
    public void c(r.c cVar) {
        this.f1179a.setStableInsets(cVar.c());
    }

    @Override // y.X
    public void d(r.c cVar) {
        this.f1179a.setSystemWindowInsets(cVar.c());
    }

    public V(f0 f0Var) {
        WindowInsets.Builder builderD;
        super(f0Var);
        WindowInsets windowInsetsB = f0Var.b();
        if (windowInsetsB != null) {
            builderD = Q.a.e(windowInsetsB);
        } else {
            builderD = Q.a.d();
        }
        this.f1179a = builderD;
    }
}
