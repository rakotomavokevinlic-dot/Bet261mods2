package y;

import android.view.View;
import i.C0043c;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class Q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final WeakReference f1171a;

    public Q(View view) {
        this.f1171a = new WeakReference(view);
    }

    public final void a(float f) {
        View view = (View) this.f1171a.get();
        if (view != null) {
            view.animate().alpha(f);
        }
    }

    public final void b() {
        View view = (View) this.f1171a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public final void c(long j2) {
        View view = (View) this.f1171a.get();
        if (view != null) {
            view.animate().setDuration(j2);
        }
    }

    public final void d(S s2) {
        View view = (View) this.f1171a.get();
        if (view != null) {
            if (s2 != null) {
                view.animate().setListener(new C0043c(s2, view));
            } else {
                view.animate().setListener(null);
            }
        }
    }

    public final void e(float f) {
        View view = (View) this.f1171a.get();
        if (view != null) {
            view.animate().translationY(f);
        }
    }
}
