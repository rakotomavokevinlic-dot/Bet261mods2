package y;

import android.graphics.Rect;
import android.util.Log;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class U extends X {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Field f1175c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static boolean f1176d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Constructor f1177e;
    public static boolean f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public WindowInsets f1178a;
    public r.c b;

    public U() {
        this.f1178a = e();
    }

    private static WindowInsets e() {
        if (!f1176d) {
            try {
                f1175c = WindowInsets.class.getDeclaredField("CONSUMED");
            } catch (ReflectiveOperationException e2) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
            }
            f1176d = true;
        }
        Field field = f1175c;
        if (field != null) {
            try {
                WindowInsets windowInsets = (WindowInsets) field.get(null);
                if (windowInsets != null) {
                    return new WindowInsets(windowInsets);
                }
            } catch (ReflectiveOperationException e3) {
                Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
            }
        }
        if (!f) {
            try {
                f1177e = WindowInsets.class.getConstructor(Rect.class);
            } catch (ReflectiveOperationException e4) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
            }
            f = true;
        }
        Constructor constructor = f1177e;
        if (constructor != null) {
            try {
                return (WindowInsets) constructor.newInstance(new Rect());
            } catch (ReflectiveOperationException e5) {
                Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
            }
        }
        return null;
    }

    @Override // y.X
    public f0 b() {
        a();
        f0 f0VarC = f0.c(this.f1178a, null);
        d0 d0Var = f0VarC.f1202a;
        d0Var.o(null);
        d0Var.q(this.b);
        return f0VarC;
    }

    @Override // y.X
    public void c(r.c cVar) {
        this.b = cVar;
    }

    @Override // y.X
    public void d(r.c cVar) {
        WindowInsets windowInsets = this.f1178a;
        if (windowInsets != null) {
            this.f1178a = windowInsets.replaceSystemWindowInsets(cVar.f1118a, cVar.b, cVar.f1119c, cVar.f1120d);
        }
    }

    public U(f0 f0Var) {
        super(f0Var);
        this.f1178a = f0Var.b();
    }
}
