package y;

import android.content.ClipData;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContentInfo;
import java.util.Locale;

/* JADX INFO: renamed from: y.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0153e implements InterfaceC0152d, InterfaceC0154f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1198a = 0;
    public ClipData b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1199c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1200d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Uri f1201e;
    public Bundle f;

    public /* synthetic */ C0153e() {
    }

    @Override // y.InterfaceC0152d
    public void a(Bundle bundle) {
        this.f = bundle;
    }

    @Override // y.InterfaceC0152d
    public void e(Uri uri) {
        this.f1201e = uri;
    }

    @Override // y.InterfaceC0154f
    public int f() {
        return this.f1199c;
    }

    @Override // y.InterfaceC0154f
    public ClipData j() {
        return this.b;
    }

    @Override // y.InterfaceC0152d
    public C0155g k() {
        return new C0155g(new C0153e(this));
    }

    @Override // y.InterfaceC0154f
    public int n() {
        return this.f1200d;
    }

    @Override // y.InterfaceC0154f
    public ContentInfo s() {
        return null;
    }

    public String toString() {
        String str;
        switch (this.f1198a) {
            case 1:
                StringBuilder sb = new StringBuilder("ContentInfoCompat{clip=");
                sb.append(this.b.getDescription());
                sb.append(", source=");
                int i2 = this.f1199c;
                sb.append(i2 != 0 ? i2 != 1 ? i2 != 2 ? i2 != 3 ? i2 != 4 ? i2 != 5 ? String.valueOf(i2) : "SOURCE_PROCESS_TEXT" : "SOURCE_AUTOFILL" : "SOURCE_DRAG_AND_DROP" : "SOURCE_INPUT_METHOD" : "SOURCE_CLIPBOARD" : "SOURCE_APP");
                sb.append(", flags=");
                int i3 = this.f1200d;
                sb.append((i3 & 1) != 0 ? "FLAG_CONVERT_TO_PLAIN_TEXT" : String.valueOf(i3));
                Uri uri = this.f1201e;
                if (uri == null) {
                    str = "";
                } else {
                    str = ", hasLinkUri(" + uri.toString().length() + ")";
                }
                sb.append(str);
                sb.append(this.f != null ? ", hasExtras" : "");
                sb.append("}");
                return sb.toString();
            default:
                return super.toString();
        }
    }

    @Override // y.InterfaceC0152d
    public void w(int i2) {
        this.f1200d = i2;
    }

    public C0153e(C0153e c0153e) {
        ClipData clipData = c0153e.b;
        clipData.getClass();
        this.b = clipData;
        int i2 = c0153e.f1199c;
        if (i2 < 0) {
            Locale locale = Locale.US;
            throw new IllegalArgumentException("source is out of range of [0, 5] (too low)");
        }
        if (i2 > 5) {
            Locale locale2 = Locale.US;
            throw new IllegalArgumentException("source is out of range of [0, 5] (too high)");
        }
        this.f1199c = i2;
        int i3 = c0153e.f1200d;
        if ((i3 & 1) == i3) {
            this.f1200d = i3;
            this.f1201e = c0153e.f1201e;
            this.f = c0153e.f;
        } else {
            throw new IllegalArgumentException("Requested flags 0x" + Integer.toHexString(i3) + ", but only 0x" + Integer.toHexString(1) + " are allowed");
        }
    }
}
