package y;

/* JADX INFO: renamed from: y.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0155g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final InterfaceC0154f f1203a;

    public C0155g(InterfaceC0154f interfaceC0154f) {
        this.f1203a = interfaceC0154f;
    }

    public final String toString() {
        return this.f1203a.toString();
    }
}
