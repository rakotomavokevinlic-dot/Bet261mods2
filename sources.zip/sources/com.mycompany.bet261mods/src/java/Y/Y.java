package y;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class Y extends d0 {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static boolean f1180h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static Method f1181i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static Class f1182j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static Field f1183k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static Field f1184l;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final WindowInsets f1185c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public r.c[] f1186d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public r.c f1187e;
    public f0 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public r.c f1188g;

    public Y(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var);
        this.f1187e = null;
        this.f1185c = windowInsets;
    }

    private r.c r(int i2, boolean z2) {
        r.c cVarA = r.c.f1117e;
        for (int i3 = 1; i3 <= 256; i3 <<= 1) {
            if ((i2 & i3) != 0) {
                r.c cVarS = s(i3, z2);
                cVarA = r.c.a(Math.max(cVarA.f1118a, cVarS.f1118a), Math.max(cVarA.b, cVarS.b), Math.max(cVarA.f1119c, cVarS.f1119c), Math.max(cVarA.f1120d, cVarS.f1120d));
            }
        }
        return cVarA;
    }

    private r.c t() {
        f0 f0Var = this.f;
        return f0Var != null ? f0Var.f1202a.h() : r.c.f1117e;
    }

    private r.c u(View view) {
        if (Build.VERSION.SDK_INT >= 30) {
            throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
        }
        if (!f1180h) {
            v();
        }
        Method method = f1181i;
        if (method != null && f1182j != null && f1183k != null) {
            try {
                Object objInvoke = method.invoke(view, null);
                if (objInvoke == null) {
                    Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                    return null;
                }
                Rect rect = (Rect) f1183k.get(f1184l.get(objInvoke));
                if (rect != null) {
                    return r.c.a(rect.left, rect.top, rect.right, rect.bottom);
                }
            } catch (ReflectiveOperationException e2) {
                Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
            }
        }
        return null;
    }

    private static void v() {
        try {
            f1181i = View.class.getDeclaredMethod("getViewRootImpl", null);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            f1182j = cls;
            f1183k = cls.getDeclaredField("mVisibleInsets");
            f1184l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
            f1183k.setAccessible(true);
            f1184l.setAccessible(true);
        } catch (ReflectiveOperationException e2) {
            Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
        }
        f1180h = true;
    }

    @Override // y.d0
    public void d(View view) {
        r.c cVarU = u(view);
        if (cVarU == null) {
            cVarU = r.c.f1117e;
        }
        w(cVarU);
    }

    @Override // y.d0
    public boolean equals(Object obj) {
        if (super.equals(obj)) {
            return Objects.equals(this.f1188g, ((Y) obj).f1188g);
        }
        return false;
    }

    @Override // y.d0
    public r.c f(int i2) {
        return r(i2, false);
    }

    @Override // y.d0
    public final r.c j() {
        if (this.f1187e == null) {
            WindowInsets windowInsets = this.f1185c;
            this.f1187e = r.c.a(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
        return this.f1187e;
    }

    @Override // y.d0
    public f0 l(int i2, int i3, int i4, int i5) {
        f0 f0VarC = f0.c(this.f1185c, null);
        int i6 = Build.VERSION.SDK_INT;
        X w2 = i6 >= 30 ? new W(f0VarC) : i6 >= 29 ? new V(f0VarC) : new U(f0VarC);
        w2.d(f0.a(j(), i2, i3, i4, i5));
        w2.c(f0.a(h(), i2, i3, i4, i5));
        return w2.b();
    }

    @Override // y.d0
    public boolean n() {
        return this.f1185c.isRound();
    }

    @Override // y.d0
    public void o(r.c[] cVarArr) {
        this.f1186d = cVarArr;
    }

    @Override // y.d0
    public void p(f0 f0Var) {
        this.f = f0Var;
    }

    public r.c s(int i2, boolean z2) {
        r.c cVarH;
        int i3;
        if (i2 == 1) {
            return z2 ? r.c.a(0, Math.max(t().b, j().b), 0, 0) : r.c.a(0, j().b, 0, 0);
        }
        if (i2 == 2) {
            if (z2) {
                r.c cVarT = t();
                r.c cVarH2 = h();
                return r.c.a(Math.max(cVarT.f1118a, cVarH2.f1118a), 0, Math.max(cVarT.f1119c, cVarH2.f1119c), Math.max(cVarT.f1120d, cVarH2.f1120d));
            }
            r.c cVarJ = j();
            f0 f0Var = this.f;
            cVarH = f0Var != null ? f0Var.f1202a.h() : null;
            int iMin = cVarJ.f1120d;
            if (cVarH != null) {
                iMin = Math.min(iMin, cVarH.f1120d);
            }
            return r.c.a(cVarJ.f1118a, 0, cVarJ.f1119c, iMin);
        }
        r.c cVar = r.c.f1117e;
        if (i2 == 8) {
            r.c[] cVarArr = this.f1186d;
            cVarH = cVarArr != null ? cVarArr[3] : null;
            if (cVarH != null) {
                return cVarH;
            }
            r.c cVarJ2 = j();
            r.c cVarT2 = t();
            int i4 = cVarJ2.f1120d;
            if (i4 > cVarT2.f1120d) {
                return r.c.a(0, 0, 0, i4);
            }
            r.c cVar2 = this.f1188g;
            if (cVar2 != null && !cVar2.equals(cVar) && (i3 = this.f1188g.f1120d) > cVarT2.f1120d) {
                return r.c.a(0, 0, 0, i3);
            }
        } else {
            if (i2 == 16) {
                return i();
            }
            if (i2 == 32) {
                return g();
            }
            if (i2 == 64) {
                return k();
            }
            if (i2 == 128) {
                f0 f0Var2 = this.f;
                C0158j c0158jE = f0Var2 != null ? f0Var2.f1202a.e() : e();
                if (c0158jE != null) {
                    int i5 = Build.VERSION.SDK_INT;
                    return r.c.a(i5 >= 28 ? AbstractC0157i.d(c0158jE.f1210a) : 0, i5 >= 28 ? AbstractC0157i.f(c0158jE.f1210a) : 0, i5 >= 28 ? AbstractC0157i.e(c0158jE.f1210a) : 0, i5 >= 28 ? AbstractC0157i.c(c0158jE.f1210a) : 0);
                }
            }
        }
        return cVar;
    }

    public void w(r.c cVar) {
        this.f1188g = cVar;
    }
}
