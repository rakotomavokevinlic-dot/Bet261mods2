package y;

import android.view.DisplayCutout;
import android.view.WindowInsets;
import java.util.Objects;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public class a0 extends Z {
    public a0(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
    }

    @Override // y.d0
    public f0 a() {
        return f0.c(androidx.emoji2.text.b.j(this.f1185c), null);
    }

    @Override // y.d0
    public C0158j e() {
        DisplayCutout displayCutoutI = androidx.emoji2.text.b.i(this.f1185c);
        if (displayCutoutI == null) {
            return null;
        }
        return new C0158j(displayCutoutI);
    }

    @Override // y.Y, y.d0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a0)) {
            return false;
        }
        a0 a0Var = (a0) obj;
        return Objects.equals(this.f1185c, a0Var.f1185c) && Objects.equals(this.f1188g, a0Var.f1188g);
    }

    @Override // y.d0
    public int hashCode() {
        return this.f1185c.hashCode();
    }
}
