package y;

import android.content.ClipData;
import android.view.ContentInfo;

/* JADX INFO: renamed from: y.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract /* synthetic */ class AbstractC0151c {
    public static /* synthetic */ ContentInfo.Builder c(ClipData clipData, int i2) {
        return new ContentInfo.Builder(clipData, i2);
    }

    public static /* bridge */ /* synthetic */ ContentInfo e(Object obj) {
        return (ContentInfo) obj;
    }
}
