package y;

import android.content.Context;
import android.view.VelocityTracker;

/* JADX INFO: renamed from: y.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0156h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f1204a;
    public final C.j b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public VelocityTracker f1205c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f1206d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1207e = -1;
    public int f = -1;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1208g = -1;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int[] f1209h = {Integer.MAX_VALUE, 0};

    public C0156h(Context context, C.j jVar) {
        this.f1204a = context;
        this.b = jVar;
    }
}
