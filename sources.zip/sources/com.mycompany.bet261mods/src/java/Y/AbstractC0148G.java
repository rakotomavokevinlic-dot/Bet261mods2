package y;

import android.view.ContentInfo;
import android.view.View;
import java.util.Objects;

/* JADX INFO: renamed from: y.G, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class AbstractC0148G {
    public static String[] a(View view) {
        return view.getReceiveContentMimeTypes();
    }

    public static C0155g b(View view, C0155g c0155g) {
        ContentInfo contentInfoS = c0155g.f1203a.s();
        Objects.requireNonNull(contentInfoS);
        ContentInfo contentInfoE = AbstractC0151c.e(contentInfoS);
        ContentInfo contentInfoPerformReceiveContent = view.performReceiveContent(contentInfoE);
        if (contentInfoPerformReceiveContent == null) {
            return null;
        }
        return contentInfoPerformReceiveContent == contentInfoE ? c0155g : new C0155g(new C.j(contentInfoPerformReceiveContent));
    }

    public static void c(View view, String[] strArr, InterfaceC0165q interfaceC0165q) {
        if (interfaceC0165q == null) {
            view.setOnReceiveContentListener(strArr, null);
        } else {
            view.setOnReceiveContentListener(strArr, new H(interfaceC0165q));
        }
    }
}
