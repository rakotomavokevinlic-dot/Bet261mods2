package y;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class W extends V {
    public W() {
    }

    public W(f0 f0Var) {
        super(f0Var);
    }
}
