package y;

import android.view.KeyEvent;
import android.view.View;

/* JADX INFO: renamed from: y.C, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final /* synthetic */ class ViewOnUnhandledKeyEventListenerC0144C implements View.OnUnhandledKeyEventListener {
    @Override // android.view.View.OnUnhandledKeyEventListener
    public final boolean onUnhandledKeyEvent(View view, KeyEvent keyEvent) {
        throw null;
    }
}
