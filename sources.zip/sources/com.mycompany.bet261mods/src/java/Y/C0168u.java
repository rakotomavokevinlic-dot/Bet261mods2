package y;

/* JADX INFO: renamed from: y.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0168u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float[] f1216a = new float[20];
    public final long[] b = new long[20];

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f1217c = 0.0f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1218d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1219e = 0;
}
