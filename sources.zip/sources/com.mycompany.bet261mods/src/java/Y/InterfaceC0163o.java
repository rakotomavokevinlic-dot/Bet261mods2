package y;

import android.view.View;

/* JADX INFO: renamed from: y.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface InterfaceC0163o extends InterfaceC0162n {
    void b(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr);
}
