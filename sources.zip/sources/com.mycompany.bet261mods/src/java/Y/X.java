package y;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class X {
    public X() {
        this(new f0());
    }

    public abstract f0 b();

    public abstract void c(r.c cVar);

    public abstract void d(r.c cVar);

    public X(f0 f0Var) {
    }

    public final void a() {
    }
}
