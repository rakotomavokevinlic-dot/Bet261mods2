package y;

/* JADX INFO: renamed from: y.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final /* synthetic */ class C0169v implements r {
    @Override // y.r
    public final C0155g a(C0155g c0155g) {
        return c0155g;
    }
}
