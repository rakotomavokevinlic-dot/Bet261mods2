package y;

import android.view.WindowInsets;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public class Z extends Y {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public r.c f1189m;

    public Z(f0 f0Var, WindowInsets windowInsets) {
        super(f0Var, windowInsets);
        this.f1189m = null;
    }

    @Override // y.d0
    public f0 b() {
        return f0.c(this.f1185c.consumeStableInsets(), null);
    }

    @Override // y.d0
    public f0 c() {
        return f0.c(this.f1185c.consumeSystemWindowInsets(), null);
    }

    @Override // y.d0
    public final r.c h() {
        if (this.f1189m == null) {
            WindowInsets windowInsets = this.f1185c;
            this.f1189m = r.c.a(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.f1189m;
    }

    @Override // y.d0
    public boolean m() {
        return this.f1185c.isConsumed();
    }

    @Override // y.d0
    public void q(r.c cVar) {
        this.f1189m = cVar;
    }
}
