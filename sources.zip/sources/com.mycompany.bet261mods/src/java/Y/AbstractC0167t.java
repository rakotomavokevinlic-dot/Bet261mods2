package y;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: y.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class AbstractC0167t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Map f1215a = Collections.synchronizedMap(new WeakHashMap());
}
