package y;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: y.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class ViewOnApplyWindowInsetsListenerC0173z implements View.OnApplyWindowInsetsListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public f0 f1222a = null;
    public final /* synthetic */ View b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0164p f1223c;

    public ViewOnApplyWindowInsetsListenerC0173z(View view, InterfaceC0164p interfaceC0164p) {
        this.b = view;
        this.f1223c = interfaceC0164p;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        f0 f0VarC = f0.c(windowInsets, view);
        int i2 = Build.VERSION.SDK_INT;
        InterfaceC0164p interfaceC0164p = this.f1223c;
        if (i2 < 30) {
            AbstractC0142A.a(windowInsets, this.b);
            if (f0VarC.equals(this.f1222a)) {
                return interfaceC0164p.a(view, f0VarC).b();
            }
        }
        this.f1222a = f0VarC;
        f0 f0VarA = interfaceC0164p.a(view, f0VarC);
        if (i2 >= 30) {
            return f0VarA.b();
        }
        WeakHashMap weakHashMap = K.f1165a;
        AbstractC0172y.c(view);
        return f0VarA.b();
    }
}
