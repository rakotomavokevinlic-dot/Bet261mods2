package y;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.Objects;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class f0 {
    public static final f0 b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d0 f1202a;

    static {
        if (Build.VERSION.SDK_INT >= 30) {
            b = c0.f1196q;
        } else {
            b = d0.b;
        }
    }

    public f0(WindowInsets windowInsets) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30) {
            this.f1202a = new c0(this, windowInsets);
            return;
        }
        if (i2 >= 29) {
            this.f1202a = new b0(this, windowInsets);
        } else if (i2 >= 28) {
            this.f1202a = new a0(this, windowInsets);
        } else {
            this.f1202a = new Z(this, windowInsets);
        }
    }

    public static r.c a(r.c cVar, int i2, int i3, int i4, int i5) {
        int iMax = Math.max(0, cVar.f1118a - i2);
        int iMax2 = Math.max(0, cVar.b - i3);
        int iMax3 = Math.max(0, cVar.f1119c - i4);
        int iMax4 = Math.max(0, cVar.f1120d - i5);
        return (iMax == i2 && iMax2 == i3 && iMax3 == i4 && iMax4 == i5) ? cVar : r.c.a(iMax, iMax2, iMax3, iMax4);
    }

    public static f0 c(WindowInsets windowInsets, View view) {
        windowInsets.getClass();
        f0 f0Var = new f0(windowInsets);
        if (view != null && view.isAttachedToWindow()) {
            WeakHashMap weakHashMap = K.f1165a;
            f0 f0VarA = AbstractC0143B.a(view);
            d0 d0Var = f0Var.f1202a;
            d0Var.p(f0VarA);
            d0Var.d(view.getRootView());
        }
        return f0Var;
    }

    public final WindowInsets b() {
        d0 d0Var = this.f1202a;
        if (d0Var instanceof Y) {
            return ((Y) d0Var).f1185c;
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f0)) {
            return false;
        }
        return Objects.equals(this.f1202a, ((f0) obj).f1202a);
    }

    public final int hashCode() {
        d0 d0Var = this.f1202a;
        if (d0Var == null) {
            return 0;
        }
        return d0Var.hashCode();
    }

    public f0() {
        this.f1202a = new d0(this);
    }
}
