package a;

import androidx.activity.l;
import java.util.concurrent.CopyOnWriteArraySet;

/* JADX INFO: renamed from: a.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0000a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final CopyOnWriteArraySet f303a = new CopyOnWriteArraySet();
    public volatile l b;
}
