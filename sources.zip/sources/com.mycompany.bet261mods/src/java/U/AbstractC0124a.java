package u;

import java.util.Locale;
import w.AbstractC0138a;

/* JADX INFO: renamed from: u.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class AbstractC0124a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Locale[] f1139a = {new Locale("en", "XA"), new Locale("ar", "XB")};

    public static Locale a(String str) {
        return Locale.forLanguageTag(str);
    }

    public static boolean b(Locale locale, Locale locale2) {
        if (locale.equals(locale2)) {
            return true;
        }
        if (locale.getLanguage().equals(locale2.getLanguage())) {
            Locale[] localeArr = f1139a;
            for (Locale locale3 : localeArr) {
                if (locale3.equals(locale)) {
                    return false;
                }
            }
            for (Locale locale4 : localeArr) {
                if (locale4.equals(locale2)) {
                    return false;
                }
            }
            String strC = AbstractC0138a.c(AbstractC0138a.a(AbstractC0138a.b(locale)));
            if (!strC.isEmpty()) {
                return strC.equals(AbstractC0138a.c(AbstractC0138a.a(AbstractC0138a.b(locale2))));
            }
            String country = locale.getCountry();
            if (country.isEmpty() || country.equals(locale2.getCountry())) {
                return true;
            }
        }
        return false;
    }
}
