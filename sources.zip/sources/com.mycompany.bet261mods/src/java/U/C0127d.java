package u;

import android.os.LocaleList;

/* JADX INFO: renamed from: u.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0127d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LocaleList f1141a;

    public C0127d(LocaleList localeList) {
        this.f1141a = localeList;
    }

    public final boolean equals(Object obj) {
        return this.f1141a.equals(((C0127d) obj).f1141a);
    }

    public final int hashCode() {
        return this.f1141a.hashCode();
    }

    public final String toString() {
        return this.f1141a.toString();
    }
}
