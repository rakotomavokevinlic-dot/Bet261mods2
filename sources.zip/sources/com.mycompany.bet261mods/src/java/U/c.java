package U;

import T.i;
import T.s;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f218a;
    public final String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f219c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f220d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f221e;
    public final long f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final long f222g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final List f223h;

    public c(String str, String str2, long j2, long j3, long j4, long j5, List list) {
        this.b = str;
        this.f219c = "".equals(str2) ? null : str2;
        this.f220d = j2;
        this.f221e = j3;
        this.f = j4;
        this.f222g = j5;
        this.f223h = list;
    }

    public static c a(d dVar) throws IOException {
        if (e.i(dVar) != 538247942) {
            throw new IOException();
        }
        String strK = e.k(dVar);
        String strK2 = e.k(dVar);
        long j2 = e.j(dVar);
        long j3 = e.j(dVar);
        long j4 = e.j(dVar);
        long j5 = e.j(dVar);
        int i2 = e.i(dVar);
        if (i2 < 0) {
            throw new IOException("readHeaderList size=" + i2);
        }
        List arrayList = i2 == 0 ? Collections.EMPTY_LIST : new ArrayList();
        for (int i3 = 0; i3 < i2; i3++) {
            arrayList.add(new i(e.k(dVar).intern(), e.k(dVar).intern()));
        }
        return new c(strK, strK2, j2, j3, j4, j5, arrayList);
    }

    public final T.b b(byte[] bArr) {
        T.b bVar = new T.b();
        bVar.f169a = bArr;
        bVar.b = this.f219c;
        bVar.f170c = this.f220d;
        bVar.f171d = this.f221e;
        bVar.f172e = this.f;
        bVar.f = this.f222g;
        TreeMap treeMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        List<i> list = this.f223h;
        for (i iVar : list) {
            treeMap.put(iVar.f187a, iVar.b);
        }
        bVar.f173g = treeMap;
        bVar.f174h = Collections.unmodifiableList(list);
        return bVar;
    }

    public final boolean c(BufferedOutputStream bufferedOutputStream) {
        try {
            e.m(bufferedOutputStream, 538247942);
            e.o(bufferedOutputStream, this.b);
            String str = this.f219c;
            if (str == null) {
                str = "";
            }
            e.o(bufferedOutputStream, str);
            e.n(bufferedOutputStream, this.f220d);
            e.n(bufferedOutputStream, this.f221e);
            e.n(bufferedOutputStream, this.f);
            e.n(bufferedOutputStream, this.f222g);
            List<i> list = this.f223h;
            if (list != null) {
                e.m(bufferedOutputStream, list.size());
                for (i iVar : list) {
                    e.o(bufferedOutputStream, iVar.f187a);
                    e.o(bufferedOutputStream, iVar.b);
                }
            } else {
                e.m(bufferedOutputStream, 0);
            }
            bufferedOutputStream.flush();
            return true;
        } catch (IOException e2) {
            s.b("%s", e2.toString());
            return false;
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r11v1, types: [java.util.List] */
    public c(String str, T.b bVar) {
        String str2 = bVar.b;
        long j2 = bVar.f170c;
        long j3 = bVar.f171d;
        long j4 = bVar.f172e;
        long j5 = bVar.f;
        ?? arrayList = bVar.f174h;
        if (arrayList == 0) {
            Map map = bVar.f173g;
            arrayList = new ArrayList(map.size());
            for (Map.Entry entry : map.entrySet()) {
                arrayList.add(new i((String) entry.getKey(), (String) entry.getValue()));
            }
        }
        this(str, str2, j2, j3, j4, j5, arrayList);
    }
}
