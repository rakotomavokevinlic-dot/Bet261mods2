package u;

import java.util.Locale;

/* JADX INFO: renamed from: u.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0126c {
    public static final C0126c b = new C0126c(new C0127d(AbstractC0125b.a(new Locale[0])));

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0127d f1140a;

    public C0126c(C0127d c0127d) {
        this.f1140a = c0127d;
    }

    public static C0126c a(String str) {
        if (str == null || str.isEmpty()) {
            return b;
        }
        String[] strArrSplit = str.split(",", -1);
        int length = strArrSplit.length;
        Locale[] localeArr = new Locale[length];
        for (int i2 = 0; i2 < length; i2++) {
            localeArr[i2] = AbstractC0124a.a(strArrSplit[i2]);
        }
        return new C0126c(new C0127d(AbstractC0125b.a(localeArr)));
    }

    public final boolean equals(Object obj) {
        if (obj instanceof C0126c) {
            return this.f1140a.equals(((C0126c) obj).f1140a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f1140a.f1141a.hashCode();
    }

    public final String toString() {
        return this.f1140a.f1141a.toString();
    }
}
