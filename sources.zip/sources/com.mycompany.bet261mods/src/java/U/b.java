package U;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class b {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a f214e = new a();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f215a;
    public final ArrayList b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f216c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f217d;

    public b(int i2, ArrayList arrayList, int i3, InputStream inputStream) {
        this.f215a = i2;
        this.b = arrayList;
        this.f216c = i3;
        this.f217d = inputStream;
    }

    public synchronized byte[] a(int i2) {
        for (int i3 = 0; i3 < ((ArrayList) this.f217d).size(); i3++) {
            byte[] bArr = (byte[]) ((ArrayList) this.f217d).get(i3);
            if (bArr.length >= i2) {
                this.f215a -= bArr.length;
                ((ArrayList) this.f217d).remove(i3);
                this.b.remove(bArr);
                return bArr;
            }
        }
        return new byte[i2];
    }

    public synchronized void b(byte[] bArr) {
        if (bArr != null) {
            if (bArr.length <= this.f216c) {
                this.b.add(bArr);
                int iBinarySearch = Collections.binarySearch((ArrayList) this.f217d, bArr, f214e);
                if (iBinarySearch < 0) {
                    iBinarySearch = (-iBinarySearch) - 1;
                }
                ((ArrayList) this.f217d).add(iBinarySearch, bArr);
                this.f215a += bArr.length;
                synchronized (this) {
                    while (this.f215a > this.f216c) {
                        byte[] bArr2 = (byte[]) this.b.remove(0);
                        ((ArrayList) this.f217d).remove(bArr2);
                        this.f215a -= bArr2.length;
                    }
                }
            }
        }
    }

    public b() {
        this.b = new ArrayList();
        this.f217d = new ArrayList(64);
        this.f215a = 0;
        this.f216c = 4096;
    }
}
