package U;

import C.j;
import T.k;
import T.m;
import T.n;
import T.o;
import T.r;
import T.s;
import T.t;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public class h implements Comparable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final r f230a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f231c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f232d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f233e;
    public final F.d f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Integer f234g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public n f235h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f236i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f237j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final T.f f238k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public T.b f239l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public t f240m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Object f241n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final o f242o;

    public h(int i2, String str, o oVar, F.d dVar) {
        Uri uri;
        String host;
        this.f230a = r.f208c ? new r() : null;
        this.f233e = new Object();
        this.f236i = true;
        int iHashCode = 0;
        this.f237j = false;
        this.f239l = null;
        this.b = i2;
        this.f231c = str;
        this.f = dVar;
        T.f fVar = new T.f();
        fVar.f182a = 2500;
        this.f238k = fVar;
        if (!TextUtils.isEmpty(str) && (uri = Uri.parse(str)) != null && (host = uri.getHost()) != null) {
            iHashCode = host.hashCode();
        }
        this.f232d = iHashCode;
        this.f241n = new Object();
        this.f242o = oVar;
    }

    public static k i(k kVar) {
        String str;
        long j2;
        boolean z2;
        long j3;
        long j4;
        long j5;
        long j6;
        T.b bVar;
        Map map = (Map) kVar.f193c;
        byte[] bArr = (byte[]) kVar.b;
        try {
            str = new String(bArr, D.g.S(map));
        } catch (UnsupportedEncodingException unused) {
            str = new String(bArr);
        }
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (map == null) {
            bVar = null;
            break;
        }
        String str2 = (String) map.get("Date");
        long jT = str2 != null ? D.g.T(str2) : 0L;
        String str3 = (String) map.get("Cache-Control");
        int i2 = 0;
        if (str3 != null) {
            String[] strArrSplit = str3.split(",", 0);
            z2 = false;
            j3 = 0;
            j4 = 0;
            while (i2 < strArrSplit.length) {
                String strTrim = strArrSplit[i2].trim();
                if (strTrim.equals("no-cache") || strTrim.equals("no-store")) {
                    bVar = null;
                    break;
                }
                if (strTrim.startsWith("max-age=")) {
                    try {
                        j3 = Long.parseLong(strTrim.substring(8));
                    } catch (Exception unused2) {
                    }
                } else if (strTrim.startsWith("stale-while-revalidate=")) {
                    j4 = Long.parseLong(strTrim.substring(23));
                } else if (strTrim.equals("must-revalidate") || strTrim.equals("proxy-revalidate")) {
                    z2 = true;
                }
                i2++;
            }
            j2 = 0;
            i2 = 1;
        } else {
            j2 = 0;
            z2 = false;
            j3 = 0;
            j4 = 0;
        }
        String str4 = (String) map.get("Expires");
        long jT2 = str4 != null ? D.g.T(str4) : j2;
        String str5 = (String) map.get("Last-Modified");
        long jT3 = str5 != null ? D.g.T(str5) : j2;
        String str6 = (String) map.get("ETag");
        if (i2 != 0) {
            long j7 = (j3 * 1000) + jCurrentTimeMillis;
            j5 = j7;
            j6 = z2 ? j7 : (j4 * 1000) + j7;
        } else {
            j5 = (jT <= j2 || jT2 < jT) ? j2 : (jT2 - jT) + jCurrentTimeMillis;
            j6 = j5;
        }
        T.b bVar2 = new T.b();
        bVar2.f169a = bArr;
        bVar2.b = str6;
        bVar2.f = j5;
        bVar2.f172e = j6;
        bVar2.f170c = jT;
        bVar2.f171d = jT3;
        bVar2.f173g = map;
        bVar2.f174h = (List) kVar.f194d;
        bVar = bVar2;
        return new k(str, bVar);
    }

    public final void a(String str) {
        if (r.f208c) {
            this.f230a.a(str, Thread.currentThread().getId());
        }
    }

    public final void b(String str) {
        n nVar = this.f235h;
        if (nVar != null) {
            synchronized (nVar.b) {
                nVar.b.remove(this);
            }
            synchronized (nVar.f204j) {
                Iterator it = nVar.f204j.iterator();
                if (it.hasNext()) {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            }
            nVar.b();
        }
        if (r.f208c) {
            long id = Thread.currentThread().getId();
            if (Looper.myLooper() != Looper.getMainLooper()) {
                new Handler(Looper.getMainLooper()).post(new m(this, str, id));
            } else {
                this.f230a.a(str, id);
                this.f230a.b(toString());
            }
        }
    }

    public final byte[] c() {
        Map mapE = e();
        if (mapE == null || ((HashMap) mapE).size() <= 0) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        try {
            for (Map.Entry entry : mapE.entrySet()) {
                if (entry.getKey() == null || entry.getValue() == null) {
                    throw new IllegalArgumentException(String.format("Request#getParams() or Request#getPostParams() returned a map containing a null key or value: (%s, %s). All keys and values must be non-null.", entry.getKey(), entry.getValue()));
                }
                sb.append(URLEncoder.encode((String) entry.getKey(), "UTF-8"));
                sb.append('=');
                sb.append(URLEncoder.encode((String) entry.getValue(), "UTF-8"));
                sb.append('&');
            }
            return sb.toString().getBytes("UTF-8");
        } catch (UnsupportedEncodingException e2) {
            throw new RuntimeException("Encoding not supported: UTF-8", e2);
        }
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        h hVar = (h) obj;
        hVar.getClass();
        return this.f234g.intValue() - hVar.f234g.intValue();
    }

    public final String d() {
        String str = this.f231c;
        int i2 = this.b;
        if (i2 == 0 || i2 == -1) {
            return str;
        }
        return Integer.toString(i2) + '-' + str;
    }

    public Map e() {
        return null;
    }

    public final boolean f() {
        boolean z2;
        synchronized (this.f233e) {
            z2 = this.f237j;
        }
        return z2;
    }

    public final void g() {
        t tVar;
        synchronized (this.f233e) {
            tVar = this.f240m;
        }
        if (tVar != null) {
            tVar.h(this);
        }
    }

    public final void h(k kVar) {
        t tVar;
        List list;
        synchronized (this.f233e) {
            tVar = this.f240m;
        }
        if (tVar != null) {
            T.b bVar = (T.b) kVar.f193c;
            if (bVar != null) {
                if (bVar.f172e >= System.currentTimeMillis()) {
                    String strD = d();
                    synchronized (tVar) {
                        list = (List) ((HashMap) tVar.f211a).remove(strD);
                    }
                    if (list != null) {
                        if (s.f210a) {
                            s.d("Releasing %d waiting requests for cacheKey=%s.", Integer.valueOf(list.size()), strD);
                        }
                        Iterator it = list.iterator();
                        while (it.hasNext()) {
                            ((j) tVar.b).y((h) it.next(), kVar, null);
                        }
                        return;
                    }
                    return;
                }
            }
            tVar.h(this);
        }
    }

    public final void j() {
        n nVar = this.f235h;
        if (nVar != null) {
            nVar.b();
        }
    }

    public final String toString() {
        String str = "0x" + Integer.toHexString(this.f232d);
        StringBuilder sb = new StringBuilder("[ ] ");
        synchronized (this.f233e) {
        }
        sb.append(this.f231c);
        sb.append(" ");
        sb.append(str);
        sb.append(" ");
        sb.append("NORMAL");
        sb.append(" ");
        sb.append(this.f234g);
        return sb.toString();
    }
}
