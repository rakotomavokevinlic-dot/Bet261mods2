package U;

import T.s;
import android.os.SystemClock;
import android.text.TextUtils;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class e {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final G.a f226c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f225a = new LinkedHashMap(16, 0.75f, true);
    public long b = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f227d = 5242880;

    public e(G.a aVar) {
        this.f226c = aVar;
    }

    public static String c(String str) {
        int length = str.length() / 2;
        return String.valueOf(str.substring(0, length).hashCode()) + String.valueOf(str.substring(length).hashCode());
    }

    public static int h(d dVar) throws IOException {
        int i2 = dVar.read();
        if (i2 != -1) {
            return i2;
        }
        throw new EOFException();
    }

    public static int i(d dVar) {
        return (h(dVar) << 24) | h(dVar) | (h(dVar) << 8) | (h(dVar) << 16);
    }

    public static long j(d dVar) {
        return (((long) h(dVar)) & 255) | ((((long) h(dVar)) & 255) << 8) | ((((long) h(dVar)) & 255) << 16) | ((((long) h(dVar)) & 255) << 24) | ((((long) h(dVar)) & 255) << 32) | ((((long) h(dVar)) & 255) << 40) | ((((long) h(dVar)) & 255) << 48) | ((255 & ((long) h(dVar))) << 56);
    }

    public static String k(d dVar) {
        return new String(l(dVar, j(dVar)), "UTF-8");
    }

    public static byte[] l(d dVar, long j2) throws IOException {
        long j3 = dVar.f224a - dVar.b;
        if (j2 >= 0 && j2 <= j3) {
            int i2 = (int) j2;
            if (i2 == j2) {
                byte[] bArr = new byte[i2];
                new DataInputStream(dVar).readFully(bArr);
                return bArr;
            }
        }
        throw new IOException("streamToBytes length=" + j2 + ", maxLength=" + j3);
    }

    public static void m(BufferedOutputStream bufferedOutputStream, int i2) {
        bufferedOutputStream.write(i2 & 255);
        bufferedOutputStream.write((i2 >> 8) & 255);
        bufferedOutputStream.write((i2 >> 16) & 255);
        bufferedOutputStream.write((i2 >> 24) & 255);
    }

    public static void n(BufferedOutputStream bufferedOutputStream, long j2) {
        bufferedOutputStream.write((byte) j2);
        bufferedOutputStream.write((byte) (j2 >>> 8));
        bufferedOutputStream.write((byte) (j2 >>> 16));
        bufferedOutputStream.write((byte) (j2 >>> 24));
        bufferedOutputStream.write((byte) (j2 >>> 32));
        bufferedOutputStream.write((byte) (j2 >>> 40));
        bufferedOutputStream.write((byte) (j2 >>> 48));
        bufferedOutputStream.write((byte) (j2 >>> 56));
    }

    public static void o(BufferedOutputStream bufferedOutputStream, String str) {
        byte[] bytes = str.getBytes("UTF-8");
        n(bufferedOutputStream, bytes.length);
        bufferedOutputStream.write(bytes, 0, bytes.length);
    }

    public final synchronized T.b a(String str) {
        c cVar = (c) this.f225a.get(str);
        if (cVar == null) {
            return null;
        }
        File fileB = b(str);
        try {
            d dVar = new d(new BufferedInputStream(new FileInputStream(fileB)), fileB.length());
            try {
                c cVarA = c.a(dVar);
                if (TextUtils.equals(str, cVarA.b)) {
                    return cVar.b(l(dVar, dVar.f224a - dVar.b));
                }
                s.b("%s: key=%s, found=%s", fileB.getAbsolutePath(), str, cVarA.b);
                c cVar2 = (c) this.f225a.remove(str);
                if (cVar2 != null) {
                    this.b -= cVar2.f218a;
                }
                return null;
            } finally {
                dVar.close();
            }
        } catch (IOException e2) {
            s.b("%s: %s", fileB.getAbsolutePath(), e2.toString());
            synchronized (this) {
                boolean zDelete = b(str).delete();
                c cVar3 = (c) this.f225a.remove(str);
                if (cVar3 != null) {
                    this.b -= cVar3.f218a;
                }
                if (!zDelete) {
                    s.b("Could not delete cache entry for key=%s, filename=%s", str, c(str));
                }
                return null;
            }
        }
    }

    public final File b(String str) {
        return new File(this.f226c.a(), c(str));
    }

    public final synchronized void d() {
        long length;
        d dVar;
        File fileA = this.f226c.a();
        if (!fileA.exists()) {
            if (!fileA.mkdirs()) {
                s.c("Unable to create cache dir %s", fileA.getAbsolutePath());
            }
            return;
        }
        File[] fileArrListFiles = fileA.listFiles();
        if (fileArrListFiles == null) {
            return;
        }
        for (File file : fileArrListFiles) {
            try {
                length = file.length();
                dVar = new d(new BufferedInputStream(new FileInputStream(file)), length);
            } catch (IOException unused) {
                file.delete();
            }
            try {
                c cVarA = c.a(dVar);
                cVarA.f218a = length;
                g(cVarA.b, cVarA);
                dVar.close();
            } catch (Throwable th) {
                dVar.close();
                throw th;
            }
        }
    }

    public final void e() {
        long j2 = this.b;
        int i2 = this.f227d;
        if (j2 < i2) {
            return;
        }
        int i3 = 0;
        if (s.f210a) {
            s.d("Pruning old cache entries.", new Object[0]);
        }
        long j3 = this.b;
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        Iterator it = this.f225a.entrySet().iterator();
        while (it.hasNext()) {
            c cVar = (c) ((Map.Entry) it.next()).getValue();
            if (b(cVar.b).delete()) {
                this.b -= cVar.f218a;
            } else {
                String str = cVar.b;
                s.b("Could not delete cache entry for key=%s, filename=%s", str, c(str));
            }
            it.remove();
            i3++;
            if (this.b < i2 * 0.9f) {
                break;
            }
        }
        if (s.f210a) {
            s.d("pruned %d files, %d bytes, %d ms", Integer.valueOf(i3), Long.valueOf(this.b - j3), Long.valueOf(SystemClock.elapsedRealtime() - jElapsedRealtime));
        }
    }

    public final synchronized void f(String str, T.b bVar) {
        BufferedOutputStream bufferedOutputStream;
        c cVar;
        long length = this.b + ((long) bVar.f169a.length);
        int i2 = this.f227d;
        if (length <= i2 || r2.length <= i2 * 0.9f) {
            File fileB = b(str);
            try {
                bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(fileB));
                cVar = new c(str, bVar);
            } catch (IOException unused) {
                if (!fileB.delete()) {
                    s.b("Could not clean up file %s", fileB.getAbsolutePath());
                }
                if (!this.f226c.a().exists()) {
                    s.b("Re-initializing cache after external clearing.", new Object[0]);
                    this.f225a.clear();
                    this.b = 0L;
                    d();
                }
            }
            if (!cVar.c(bufferedOutputStream)) {
                bufferedOutputStream.close();
                s.b("Failed to write header for %s", fileB.getAbsolutePath());
                throw new IOException();
            }
            bufferedOutputStream.write(bVar.f169a);
            bufferedOutputStream.close();
            cVar.f218a = fileB.length();
            g(str, cVar);
            e();
        }
    }

    public final void g(String str, c cVar) {
        LinkedHashMap linkedHashMap = this.f225a;
        if (linkedHashMap.containsKey(str)) {
            this.b = (cVar.f218a - ((c) linkedHashMap.get(str)).f218a) + this.b;
        } else {
            this.b += cVar.f218a;
        }
        linkedHashMap.put(str, cVar);
    }
}
