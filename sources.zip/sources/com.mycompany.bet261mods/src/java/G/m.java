package g;

import android.view.Window;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class m {
    public static void a(Window.Callback callback, boolean z2) {
        callback.onPointerCaptureChanged(z2);
    }
}
