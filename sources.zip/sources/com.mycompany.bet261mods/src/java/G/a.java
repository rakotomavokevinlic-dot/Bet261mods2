package G;

import T.o;
import T.t;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Handler;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.ActionMode;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.l;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.emoji2.text.p;
import androidx.emoji2.text.w;
import androidx.emoji2.text.x;
import androidx.emoji2.text.z;
import com.mycompany.bet261mods.MainActivity;
import e.LayoutInflaterFactory2C0004B;
import e.r;
import g.AbstractC0020a;
import g.C0024e;
import h.C;
import h.n;
import java.io.File;
import java.util.WeakHashMap;
import l.C0103k;
import org.json.JSONException;
import org.json.JSONObject;
import v.C0133e;
import y.AbstractC0172y;
import y.K;
import y.Q;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class a implements o, p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f57a;
    public final Object b;

    public /* synthetic */ a(Object obj, Object obj2) {
        this.f57a = obj;
        this.b = obj2;
    }

    public File a() {
        if (((File) this.f57a) == null) {
            this.f57a = new File(((Context) this.b).getCacheDir(), "volley");
        }
        return (File) this.f57a;
    }

    public void b(AbstractC0020a abstractC0020a) {
        t tVar = (t) this.f57a;
        ((ActionMode.Callback) tVar.f211a).onDestroyActionMode(tVar.b(abstractC0020a));
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) this.b;
        if (layoutInflaterFactory2C0004B.f403w != null) {
            layoutInflaterFactory2C0004B.f392l.getDecorView().removeCallbacks(layoutInflaterFactory2C0004B.f404x);
        }
        if (layoutInflaterFactory2C0004B.f402v != null) {
            Q q2 = layoutInflaterFactory2C0004B.f405y;
            if (q2 != null) {
                q2.b();
            }
            Q qA = K.a(layoutInflaterFactory2C0004B.f402v);
            qA.a(0.0f);
            layoutInflaterFactory2C0004B.f405y = qA;
            qA.d(new r(2, this));
        }
        layoutInflaterFactory2C0004B.f401u = null;
        ViewGroup viewGroup = layoutInflaterFactory2C0004B.f358A;
        WeakHashMap weakHashMap = K.f1165a;
        AbstractC0172y.c(viewGroup);
        layoutInflaterFactory2C0004B.I();
    }

    public boolean c(CharSequence charSequence, int i2, int i3, w wVar) {
        if ((wVar.c & 4) > 0) {
            return true;
        }
        if (((z) this.f57a) == null) {
            this.f57a = new z(charSequence instanceof Spannable ? (Spannable) charSequence : new SpannableString(charSequence));
        }
        ((F.d) this.b).getClass();
        ((z) this.f57a).setSpan(new x(wVar), i2, i3, 33);
        return true;
    }

    public boolean d(AbstractC0020a abstractC0020a, n nVar) {
        ViewGroup viewGroup = ((LayoutInflaterFactory2C0004B) this.b).f358A;
        WeakHashMap weakHashMap = K.f1165a;
        AbstractC0172y.c(viewGroup);
        t tVar = (t) this.f57a;
        C0024e c0024eB = tVar.b(abstractC0020a);
        C0103k c0103k = (C0103k) tVar.f213d;
        Menu c2 = (Menu) c0103k.getOrDefault(nVar, null);
        if (c2 == null) {
            c2 = new C((Context) tVar.b, nVar);
            c0103k.put(nVar, c2);
        }
        return ((ActionMode.Callback) tVar.f211a).onPrepareActionMode(c0024eB, c2);
    }

    public void e(C0133e c0133e) {
        int i2 = c0133e.b;
        Handler handler = (Handler) this.b;
        C.j jVar = (C.j) this.f57a;
        if (i2 == 0) {
            handler.post(new T.c(jVar, 4, c0133e.f1149a));
        } else {
            handler.post(new D.b(jVar, i2));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:114:0x01a5 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00d3  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x00e1  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x0189 A[LOOP:0: B:3:0x0004->B:93:0x0189, LOOP_END] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public T.k f(U.h r14) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 476
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: G.a.f(U.h):T.k");
    }

    public Object i() {
        return (z) this.f57a;
    }

    @Override // T.o
    public void u(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            String string = "WebIntoApp";
            String string2 = "Convert your Website / HTML files into your own mobile App for Android and iOS, online & within a minute!";
            String string3 = "";
            String string4 = "https://www.webintoapp.com";
            String string5 = "5";
            String string6 = "#fdcc0d";
            String string7 = "FREE | DEDICATED";
            String string8 = "#ffffff";
            String string9 = "Click Here";
            boolean zEquals = ((!jSONObject.has("ad_display") || jSONObject.isNull("ad_display")) ? "true" : jSONObject.getString("ad_display")).equals("true");
            l lVar = (MainActivity) this.f57a;
            if (!zEquals) {
                lVar.finish();
                return;
            }
            String string10 = (!jSONObject.has("request_id") || jSONObject.isNull("request_id")) ? "0" : jSONObject.getString("request_id");
            if (jSONObject.has("ad_title") && !jSONObject.isNull("ad_title")) {
                string = jSONObject.getString("ad_title");
            }
            String str2 = string;
            if (jSONObject.has("ad_desc") && !jSONObject.isNull("ad_desc")) {
                string2 = jSONObject.getString("ad_desc");
            }
            String str3 = string2;
            if (jSONObject.has("ad_icon") && !jSONObject.isNull("ad_icon")) {
                string3 = jSONObject.getString("ad_icon");
            }
            if (jSONObject.has("ad_url") && !jSONObject.isNull("ad_url")) {
                string4 = jSONObject.getString("ad_url");
            }
            String str4 = string4;
            if (jSONObject.has("ad_rating") && !jSONObject.isNull("ad_rating")) {
                string5 = jSONObject.getString("ad_rating");
            }
            if (jSONObject.has("ad_rating_color") && !jSONObject.isNull("ad_rating_color")) {
                string6 = jSONObject.getString("ad_rating_color");
            }
            if (jSONObject.has("ad_price") && !jSONObject.isNull("ad_price")) {
                string7 = jSONObject.getString("ad_price");
            }
            String str5 = string7;
            if (jSONObject.has("ad_button_text") && !jSONObject.isNull("ad_button_text")) {
                string9 = jSONObject.getString("ad_button_text");
            }
            String str6 = string9;
            String string11 = "#000000";
            String string12 = (!jSONObject.has("ad_text_color") || jSONObject.isNull("ad_text_color")) ? "#000000" : jSONObject.getString("ad_text_color");
            if (jSONObject.has("ad_button_text_color") && !jSONObject.isNull("ad_button_text_color")) {
                string11 = jSONObject.getString("ad_button_text_color");
            }
            if (jSONObject.has("ad_button_background_color") && !jSONObject.isNull("ad_button_background_color")) {
                string8 = jSONObject.getString("ad_button_background_color");
            }
            if (jSONObject.has("ad_button_background_color") && !jSONObject.isNull("ad_button_background_color")) {
                string8 = jSONObject.getString("ad_button_background_color");
            }
            Dialog dialog = new Dialog(lVar);
            dialog.setContentView(2131427359);
            dialog.setTitle(str2);
            TextView textView = (TextView) dialog.findViewById(2131230790);
            textView.setText(str2);
            textView.setTextColor(Color.parseColor(string12));
            TextView textView2 = (TextView) dialog.findViewById(2131230786);
            textView2.setText(str3);
            textView2.setTextColor(Color.parseColor(string12));
            TextView textView3 = (TextView) dialog.findViewById(2131230788);
            textView3.setText(str5);
            textView3.setTextColor(Color.parseColor(string12));
            Button button = (Button) dialog.findViewById(2131230785);
            button.setText(str6);
            button.setTextColor(Color.parseColor(string11));
            button.setBackgroundResource(2131165274);
            ((GradientDrawable) button.getBackground()).setColor(Color.parseColor(string8));
            AppCompatRatingBar appCompatRatingBarFindViewById = dialog.findViewById(2131230789);
            appCompatRatingBarFindViewById.setRating(Float.parseFloat(string5));
            LayerDrawable layerDrawable = (LayerDrawable) appCompatRatingBarFindViewById.getProgressDrawable();
            Drawable drawable = layerDrawable.getDrawable(2);
            int color = Color.parseColor(string6);
            PorterDuff.Mode mode = PorterDuff.Mode.SRC_ATOP;
            drawable.setColorFilter(color, mode);
            layerDrawable.getDrawable(0).setColorFilter(-7829368, mode);
            layerDrawable.getDrawable(1).setColorFilter(Color.parseColor(string6), mode);
            ImageView imageView = (ImageView) dialog.findViewById(2131230784);
            W.l lVar2 = new W.l();
            lVar2.f289a = imageView;
            lVar2.execute(string3);
            button.setOnClickListener(new W.h(this, str4, string10, dialog));
            dialog.setOnShowListener(new W.i(this));
            dialog.setOnDismissListener(new W.j(this));
            dialog.getWindow().setLayout(-1, -2);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            ((ImageButton) dialog.findViewById(2131230798)).setOnClickListener(new W.k(this, dialog));
            dialog.show();
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }

    public /* synthetic */ a(Object obj, Object obj2, boolean z2) {
        this.b = obj;
        this.f57a = obj2;
    }

    public a(F.d dVar) {
        U.b bVar = new U.b();
        this.f57a = dVar;
        this.b = bVar;
    }

    public a(Context context) {
        this.b = context;
        this.f57a = null;
    }

    public a(EditText editText) {
        this.f57a = editText;
        j jVar = new j(editText);
        this.b = jVar;
        editText.addTextChangedListener(jVar);
        if (b.b == null) {
            synchronized (b.f58a) {
                try {
                    if (b.b == null) {
                        b bVar = new b();
                        try {
                            b.f59c = Class.forName("android.text.DynamicLayout$ChangeWatcher", false, b.class.getClassLoader());
                        } catch (Throwable unused) {
                        }
                        b.b = bVar;
                    }
                } finally {
                }
            }
        }
        editText.setEditableFactory(b.b);
    }
}
