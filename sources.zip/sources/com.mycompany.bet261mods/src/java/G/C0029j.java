package g;

import android.view.View;
import android.view.animation.BaseInterpolator;
import java.util.ArrayList;
import y.Q;

/* JADX INFO: renamed from: g.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0029j {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public BaseInterpolator f580c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public z.i f581d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f582e;
    public long b = -1;
    public final C0028i f = new C0028i(this);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f579a = new ArrayList();

    public final void a() {
        if (this.f582e) {
            ArrayList arrayList = this.f579a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                ((Q) obj).b();
            }
            this.f582e = false;
        }
    }

    public final void b() {
        View view;
        if (this.f582e) {
            return;
        }
        ArrayList arrayList = this.f579a;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            Q q2 = (Q) obj;
            long j2 = this.b;
            if (j2 >= 0) {
                q2.c(j2);
            }
            BaseInterpolator baseInterpolator = this.f580c;
            if (baseInterpolator != null && (view = (View) q2.f1171a.get()) != null) {
                view.animate().setInterpolator(baseInterpolator);
            }
            if (this.f581d != null) {
                q2.d(this.f);
            }
            View view2 = (View) q2.f1171a.get();
            if (view2 != null) {
                view2.animate().start();
            }
        }
        this.f582e = true;
    }
}
