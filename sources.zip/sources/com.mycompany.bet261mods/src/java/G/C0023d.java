package g;

import T.t;
import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import h.n;
import i.C0061l;
import java.lang.ref.WeakReference;

/* JADX INFO: renamed from: g.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0023d extends AbstractC0020a implements h.l {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Context f535c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ActionBarContextView f536d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public G.a f537e;
    public WeakReference f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f538g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public n f539h;

    @Override // g.AbstractC0020a
    public final void a() {
        if (this.f538g) {
            return;
        }
        this.f538g = true;
        this.f537e.b(this);
    }

    @Override // g.AbstractC0020a
    public final View b() {
        WeakReference weakReference = this.f;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // g.AbstractC0020a
    public final n c() {
        return this.f539h;
    }

    @Override // g.AbstractC0020a
    public final MenuInflater d() {
        return new C0027h(this.f536d.getContext());
    }

    @Override // g.AbstractC0020a
    public final CharSequence e() {
        return this.f536d.getSubtitle();
    }

    @Override // g.AbstractC0020a
    public final CharSequence f() {
        return this.f536d.getTitle();
    }

    @Override // h.l
    public final void g(n nVar) {
        i();
        C0061l c0061l = this.f536d.d;
        if (c0061l != null) {
            c0061l.l();
        }
    }

    @Override // h.l
    public final boolean h(n nVar, MenuItem menuItem) {
        return ((t) this.f537e.f57a).f(this, menuItem);
    }

    @Override // g.AbstractC0020a
    public final void i() {
        this.f537e.d(this, this.f539h);
    }

    @Override // g.AbstractC0020a
    public final boolean j() {
        return this.f536d.s;
    }

    @Override // g.AbstractC0020a
    public final void k(View view) {
        this.f536d.setCustomView(view);
        this.f = view != null ? new WeakReference(view) : null;
    }

    @Override // g.AbstractC0020a
    public final void l(int i2) {
        m(this.f535c.getString(i2));
    }

    @Override // g.AbstractC0020a
    public final void m(CharSequence charSequence) {
        this.f536d.setSubtitle(charSequence);
    }

    @Override // g.AbstractC0020a
    public final void n(int i2) {
        o(this.f535c.getString(i2));
    }

    @Override // g.AbstractC0020a
    public final void o(CharSequence charSequence) {
        this.f536d.setTitle(charSequence);
    }

    @Override // g.AbstractC0020a
    public final void p(boolean z2) {
        this.b = z2;
        this.f536d.setTitleOptional(z2);
    }
}
