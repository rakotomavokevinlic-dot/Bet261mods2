package G;

import android.widget.EditText;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class i extends androidx.emoji2.text.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final WeakReference f68a;

    public i(EditText editText) {
        this.f68a = new WeakReference(editText);
    }

    public final void a() {
        j.a((EditText) this.f68a.get(), 1);
    }
}
