package g;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import h.p;
import h.q;
import h.u;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import t.InterfaceMenuItemC0123a;
import y.AbstractC0160l;

/* JADX INFO: renamed from: g.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0026g {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public CharSequence f543A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public CharSequence f544B;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final /* synthetic */ C0027h f547E;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Menu f548a;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f553h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f554i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f555j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public CharSequence f556k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public CharSequence f557l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f558m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public char f559n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f560o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public char f561p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f562q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f563r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f564s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f565t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f566u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f567v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f568w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public String f569x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public String f570y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public q f571z;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public ColorStateList f545C = null;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public PorterDuff.Mode f546D = null;
    public int b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f549c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f550d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f551e = 0;
    public boolean f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f552g = true;

    public C0026g(C0027h c0027h, Menu menu) {
        this.f547E = c0027h;
        this.f548a = menu;
    }

    public final Object a(String str, Class[] clsArr, Object[] objArr) {
        try {
            Constructor<?> constructor = Class.forName(str, false, this.f547E.f574c.getClassLoader()).getConstructor(clsArr);
            constructor.setAccessible(true);
            return constructor.newInstance(objArr);
        } catch (Exception e2) {
            Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e2);
            return null;
        }
    }

    public final void b(MenuItem menuItem) {
        boolean z2 = false;
        menuItem.setChecked(this.f564s).setVisible(this.f565t).setEnabled(this.f566u).setCheckable(this.f563r >= 1).setTitleCondensed(this.f557l).setIcon(this.f558m);
        int i2 = this.f567v;
        if (i2 >= 0) {
            menuItem.setShowAsAction(i2);
        }
        String str = this.f570y;
        C0027h c0027h = this.f547E;
        if (str != null) {
            if (c0027h.f574c.isRestricted()) {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
            if (c0027h.f575d == null) {
                c0027h.f575d = C0027h.a(c0027h.f574c);
            }
            Object obj = c0027h.f575d;
            String str2 = this.f570y;
            MenuItemOnMenuItemClickListenerC0025f menuItemOnMenuItemClickListenerC0025f = new MenuItemOnMenuItemClickListenerC0025f();
            menuItemOnMenuItemClickListenerC0025f.f542a = obj;
            Class<?> cls = obj.getClass();
            try {
                menuItemOnMenuItemClickListenerC0025f.b = cls.getMethod(str2, MenuItemOnMenuItemClickListenerC0025f.f541c);
                menuItem.setOnMenuItemClickListener(menuItemOnMenuItemClickListenerC0025f);
            } catch (Exception e2) {
                InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str2 + " in class " + cls.getName());
                inflateException.initCause(e2);
                throw inflateException;
            }
        }
        if (this.f563r >= 2) {
            if (menuItem instanceof p) {
                p pVar = (p) menuItem;
                pVar.f707x = (pVar.f707x & (-5)) | 4;
            } else if (menuItem instanceof u) {
                u uVar = (u) menuItem;
                try {
                    Method method = uVar.f716d;
                    InterfaceMenuItemC0123a interfaceMenuItemC0123a = uVar.f715c;
                    if (method == null) {
                        uVar.f716d = interfaceMenuItemC0123a.getClass().getDeclaredMethod("setExclusiveCheckable", Boolean.TYPE);
                    }
                    uVar.f716d.invoke(interfaceMenuItemC0123a, Boolean.TRUE);
                } catch (Exception e3) {
                    Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e3);
                }
            }
        }
        String str3 = this.f569x;
        if (str3 != null) {
            menuItem.setActionView((View) a(str3, C0027h.f572e, c0027h.f573a));
            z2 = true;
        }
        int i3 = this.f568w;
        if (i3 > 0) {
            if (z2) {
                Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            } else {
                menuItem.setActionView(i3);
            }
        }
        q qVar = this.f571z;
        if (qVar != null) {
            if (menuItem instanceof InterfaceMenuItemC0123a) {
                ((InterfaceMenuItemC0123a) menuItem).b(qVar);
            } else {
                Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
            }
        }
        CharSequence charSequence = this.f543A;
        boolean z3 = menuItem instanceof InterfaceMenuItemC0123a;
        if (z3) {
            ((InterfaceMenuItemC0123a) menuItem).setContentDescription(charSequence);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0160l.h(menuItem, charSequence);
        }
        CharSequence charSequence2 = this.f544B;
        if (z3) {
            ((InterfaceMenuItemC0123a) menuItem).setTooltipText(charSequence2);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0160l.m(menuItem, charSequence2);
        }
        char c2 = this.f559n;
        int i4 = this.f560o;
        if (z3) {
            ((InterfaceMenuItemC0123a) menuItem).setAlphabeticShortcut(c2, i4);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0160l.g(menuItem, c2, i4);
        }
        char c3 = this.f561p;
        int i5 = this.f562q;
        if (z3) {
            ((InterfaceMenuItemC0123a) menuItem).setNumericShortcut(c3, i5);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0160l.k(menuItem, c3, i5);
        }
        PorterDuff.Mode mode = this.f546D;
        if (mode != null) {
            if (z3) {
                ((InterfaceMenuItemC0123a) menuItem).setIconTintMode(mode);
            } else if (Build.VERSION.SDK_INT >= 26) {
                AbstractC0160l.j(menuItem, mode);
            }
        }
        ColorStateList colorStateList = this.f545C;
        if (colorStateList != null) {
            if (z3) {
                ((InterfaceMenuItemC0123a) menuItem).setIconTintList(colorStateList);
            } else if (Build.VERSION.SDK_INT >= 26) {
                AbstractC0160l.i(menuItem, colorStateList);
            }
        }
    }
}
