package g;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.LayoutInflater;

/* JADX INFO: renamed from: g.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0022c extends ContextWrapper {
    public static Configuration f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f531a;
    public Resources.Theme b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public LayoutInflater f532c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Configuration f533d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Resources f534e;

    public C0022c(Context context, int i2) {
        super(context);
        this.f531a = i2;
    }

    public final void a(Configuration configuration) {
        if (this.f534e != null) {
            throw new IllegalStateException("getResources() or getAssets() has already been called");
        }
        if (this.f533d != null) {
            throw new IllegalStateException("Override configuration has already been set");
        }
        this.f533d = new Configuration(configuration);
    }

    @Override // android.content.ContextWrapper
    public final void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    public final void b() {
        if (this.b == null) {
            this.b = getResources().newTheme();
            Resources.Theme theme = getBaseContext().getTheme();
            if (theme != null) {
                this.b.setTo(theme);
            }
        }
        this.b.applyStyle(this.f531a, true);
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public final AssetManager getAssets() {
        return getResources().getAssets();
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0032  */
    @Override // android.content.ContextWrapper, android.content.Context
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.content.res.Resources getResources() {
        /*
            r3 = this;
            android.content.res.Resources r0 = r3.f534e
            if (r0 != 0) goto L38
            android.content.res.Configuration r0 = r3.f533d
            if (r0 == 0) goto L32
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 26
            if (r1 < r2) goto L25
            android.content.res.Configuration r1 = g.C0022c.f
            if (r1 != 0) goto L1c
            android.content.res.Configuration r1 = new android.content.res.Configuration
            r1.<init>()
            r2 = 0
            r1.fontScale = r2
            g.C0022c.f = r1
        L1c:
            android.content.res.Configuration r1 = g.C0022c.f
            boolean r0 = r0.equals(r1)
            if (r0 == 0) goto L25
            goto L32
        L25:
            android.content.res.Configuration r0 = r3.f533d
            android.content.Context r0 = r3.createConfigurationContext(r0)
            android.content.res.Resources r0 = r0.getResources()
            r3.f534e = r0
            goto L38
        L32:
            android.content.res.Resources r0 = super.getResources()
            r3.f534e = r0
        L38:
            android.content.res.Resources r0 = r3.f534e
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: g.C0022c.getResources():android.content.res.Resources");
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public final Object getSystemService(String str) {
        if (!"layout_inflater".equals(str)) {
            return getBaseContext().getSystemService(str);
        }
        if (this.f532c == null) {
            this.f532c = LayoutInflater.from(getBaseContext()).cloneInContext(this);
        }
        return this.f532c;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public final Resources.Theme getTheme() {
        Resources.Theme theme = this.b;
        if (theme != null) {
            return theme;
        }
        if (this.f531a == 0) {
            this.f531a = 2131689735;
        }
        b();
        return this.b;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public final void setTheme(int i2) {
        if (this.f531a != i2) {
            this.f531a = i2;
            b();
        }
    }
}
