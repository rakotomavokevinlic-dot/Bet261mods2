package g;

import i.e1;

/* JADX INFO: renamed from: g.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0028i extends z.i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f576a;
    public boolean b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f577c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f578d;

    public C0028i(C0029j c0029j) {
        this.f576a = 0;
        this.f578d = c0029j;
        this.b = false;
        this.f577c = 0;
    }

    @Override // y.S
    public final void a() {
        switch (this.f576a) {
            case 0:
                int i2 = this.f577c + 1;
                this.f577c = i2;
                C0029j c0029j = (C0029j) this.f578d;
                if (i2 == c0029j.f579a.size()) {
                    z.i iVar = c0029j.f581d;
                    if (iVar != null) {
                        iVar.a();
                    }
                    this.f577c = 0;
                    this.b = false;
                    c0029j.f582e = false;
                }
                break;
            default:
                if (!this.b) {
                    ((e1) this.f578d).f857a.setVisibility(this.f577c);
                }
                break;
        }
    }

    @Override // z.i, y.S
    public void b() {
        switch (this.f576a) {
            case 1:
                this.b = true;
                break;
        }
    }

    @Override // z.i, y.S
    public final void c() {
        switch (this.f576a) {
            case 0:
                if (!this.b) {
                    this.b = true;
                    z.i iVar = ((C0029j) this.f578d).f581d;
                    if (iVar != null) {
                        iVar.c();
                    }
                    break;
                }
                break;
            default:
                ((e1) this.f578d).f857a.setVisibility(0);
                break;
        }
    }

    public C0028i(e1 e1Var, int i2) {
        this.f576a = 1;
        this.f578d = e1Var;
        this.f577c = i2;
        this.b = false;
    }
}
