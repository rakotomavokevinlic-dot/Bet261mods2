package D;

import android.content.res.Resources;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.widget.ListView;
import i.C0077t0;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class i implements View.OnTouchListener {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final int f29r = ViewConfiguration.getTapTimeout();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f30a;
    public final AccelerateInterpolator b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ListView f31c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public b f32d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final float[] f33e;
    public final float[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f34g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f35h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final float[] f36i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final float[] f37j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final float[] f38k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f39l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f40m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f41n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f42o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f43p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final C0077t0 f44q;

    public i(C0077t0 c0077t0) {
        a aVar = new a();
        aVar.f12e = Long.MIN_VALUE;
        aVar.f13g = -1L;
        aVar.f = 0L;
        this.f30a = aVar;
        this.b = new AccelerateInterpolator();
        float[] fArr = {0.0f, 0.0f};
        this.f33e = fArr;
        float[] fArr2 = {Float.MAX_VALUE, Float.MAX_VALUE};
        this.f = fArr2;
        float[] fArr3 = {0.0f, 0.0f};
        this.f36i = fArr3;
        float[] fArr4 = {0.0f, 0.0f};
        this.f37j = fArr4;
        float[] fArr5 = {Float.MAX_VALUE, Float.MAX_VALUE};
        this.f38k = fArr5;
        this.f31c = c0077t0;
        float f = Resources.getSystem().getDisplayMetrics().density;
        float f2 = ((int) ((1575.0f * f) + 0.5f)) / 1000.0f;
        fArr5[0] = f2;
        fArr5[1] = f2;
        float f3 = ((int) ((f * 315.0f) + 0.5f)) / 1000.0f;
        fArr4[0] = f3;
        fArr4[1] = f3;
        this.f34g = 1;
        fArr2[0] = Float.MAX_VALUE;
        fArr2[1] = Float.MAX_VALUE;
        fArr[0] = 0.2f;
        fArr[1] = 0.2f;
        fArr3[0] = 0.001f;
        fArr3[1] = 0.001f;
        this.f35h = f29r;
        aVar.f9a = 500;
        aVar.b = 500;
        this.f44q = c0077t0;
    }

    public static float b(float f, float f2, float f3) {
        return f > f3 ? f3 : f < f2 ? f2 : f;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x003b A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:13:0x003c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final float a(int r4, float r5, float r6, float r7) {
        /*
            r3 = this;
            float[] r0 = r3.f33e
            r0 = r0[r4]
            float[] r1 = r3.f
            r1 = r1[r4]
            float r0 = r0 * r6
            r2 = 0
            float r0 = b(r0, r2, r1)
            float r1 = r3.c(r5, r0)
            float r6 = r6 - r5
            float r5 = r3.c(r6, r0)
            float r5 = r5 - r1
            int r6 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            android.view.animation.AccelerateInterpolator r0 = r3.b
            if (r6 >= 0) goto L25
            float r5 = -r5
            float r5 = r0.getInterpolation(r5)
            float r5 = -r5
            goto L2d
        L25:
            int r6 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r6 <= 0) goto L36
            float r5 = r0.getInterpolation(r5)
        L2d:
            r6 = -1082130432(0xffffffffbf800000, float:-1.0)
            r0 = 1065353216(0x3f800000, float:1.0)
            float r5 = b(r5, r6, r0)
            goto L37
        L36:
            r5 = r2
        L37:
            int r6 = (r5 > r2 ? 1 : (r5 == r2 ? 0 : -1))
            if (r6 != 0) goto L3c
            return r2
        L3c:
            float[] r0 = r3.f36i
            r0 = r0[r4]
            float[] r1 = r3.f37j
            r1 = r1[r4]
            float[] r2 = r3.f38k
            r4 = r2[r4]
            float r0 = r0 * r7
            if (r6 <= 0) goto L51
            float r5 = r5 * r0
            float r4 = b(r5, r1, r4)
            return r4
        L51:
            float r5 = -r5
            float r5 = r5 * r0
            float r4 = b(r5, r1, r4)
            float r4 = -r4
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: D.i.a(int, float, float, float):float");
    }

    public final float c(float f, float f2) {
        if (f2 != 0.0f) {
            int i2 = this.f34g;
            if (i2 == 0 || i2 == 1) {
                if (f < f2) {
                    if (f >= 0.0f) {
                        return 1.0f - (f / f2);
                    }
                    if (this.f42o && i2 == 1) {
                        return 1.0f;
                    }
                }
            } else if (i2 == 2 && f < 0.0f) {
                return f / (-f2);
            }
        }
        return 0.0f;
    }

    public final void d() {
        int i2 = 0;
        if (this.f40m) {
            this.f42o = false;
            return;
        }
        a aVar = this.f30a;
        long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
        int i3 = (int) (jCurrentAnimationTimeMillis - aVar.f12e);
        int i4 = aVar.b;
        if (i3 > i4) {
            i2 = i4;
        } else if (i3 >= 0) {
            i2 = i3;
        }
        aVar.f15i = i2;
        aVar.f14h = aVar.a(jCurrentAnimationTimeMillis);
        aVar.f13g = jCurrentAnimationTimeMillis;
    }

    public final boolean e() {
        C0077t0 c0077t0;
        int count;
        a aVar = this.f30a;
        float f = aVar.f11d;
        int iAbs = (int) (f / Math.abs(f));
        Math.abs(aVar.f10c);
        if (iAbs != 0 && (count = (c0077t0 = this.f44q).getCount()) != 0) {
            int childCount = c0077t0.getChildCount();
            int firstVisiblePosition = c0077t0.getFirstVisiblePosition();
            int i2 = firstVisiblePosition + childCount;
            if (iAbs <= 0 ? !(iAbs >= 0 || (firstVisiblePosition <= 0 && c0077t0.getChildAt(0).getTop() >= 0)) : !(i2 >= count && c0077t0.getChildAt(childCount - 1).getBottom() <= c0077t0.getHeight())) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0014, code lost:
    
        if (r0 != 3) goto L30;
     */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onTouch(android.view.View r8, android.view.MotionEvent r9) {
        /*
            r7 = this;
            boolean r0 = r7.f43p
            r1 = 0
            if (r0 != 0) goto L7
            goto L7c
        L7:
            int r0 = r9.getActionMasked()
            r2 = 1
            if (r0 == 0) goto L1b
            if (r0 == r2) goto L17
            r3 = 2
            if (r0 == r3) goto L1f
            r8 = 3
            if (r0 == r8) goto L17
            goto L7c
        L17:
            r7.d()
            return r1
        L1b:
            r7.f41n = r2
            r7.f39l = r1
        L1f:
            float r0 = r9.getX()
            int r3 = r8.getWidth()
            float r3 = (float) r3
            android.widget.ListView r4 = r7.f31c
            int r5 = r4.getWidth()
            float r5 = (float) r5
            float r0 = r7.a(r1, r0, r3, r5)
            float r9 = r9.getY()
            int r8 = r8.getHeight()
            float r8 = (float) r8
            int r3 = r4.getHeight()
            float r3 = (float) r3
            float r8 = r7.a(r2, r9, r8, r3)
            D.a r9 = r7.f30a
            r9.f10c = r0
            r9.f11d = r8
            boolean r8 = r7.f42o
            if (r8 != 0) goto L7c
            boolean r8 = r7.e()
            if (r8 == 0) goto L7c
            D.b r8 = r7.f32d
            if (r8 != 0) goto L60
            D.b r8 = new D.b
            r8.<init>(r1, r7)
            r7.f32d = r8
        L60:
            r7.f42o = r2
            r7.f40m = r2
            boolean r8 = r7.f39l
            if (r8 != 0) goto L75
            int r8 = r7.f35h
            if (r8 <= 0) goto L75
            D.b r9 = r7.f32d
            long r5 = (long) r8
            java.util.WeakHashMap r8 = y.K.f1165a
            r4.postOnAnimationDelayed(r9, r5)
            goto L7a
        L75:
            D.b r8 = r7.f32d
            r8.run()
        L7a:
            r7.f39l = r2
        L7c:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: D.i.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }
}
