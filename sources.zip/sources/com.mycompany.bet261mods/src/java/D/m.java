package D;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.versionedparcelable.ParcelImpl;
import i.P;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class m implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f45a;

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f45a) {
            case 0:
                n nVar = new n(parcel);
                nVar.f46a = parcel.readInt();
                return nVar;
            case 1:
                return new P.k(parcel);
            case 2:
                return new ParcelImpl(parcel);
            case 3:
                return new androidx.activity.result.a(parcel);
            case 4:
                return new androidx.fragment.app.b(parcel);
            case 5:
                return new androidx.fragment.app.c(parcel);
            case 6:
                androidx.fragment.app.o oVar = new androidx.fragment.app.o();
                oVar.a = parcel.readString();
                oVar.b = parcel.readInt();
                return oVar;
            case 7:
                androidx.fragment.app.q qVar = new androidx.fragment.app.q();
                qVar.e = null;
                qVar.f = new ArrayList();
                qVar.g = new ArrayList();
                qVar.a = parcel.createStringArrayList();
                qVar.b = parcel.createStringArrayList();
                qVar.c = (androidx.fragment.app.b[]) parcel.createTypedArray(androidx.fragment.app.b.CREATOR);
                qVar.d = parcel.readInt();
                qVar.e = parcel.readString();
                qVar.f = parcel.createStringArrayList();
                qVar.g = parcel.createTypedArrayList(androidx.fragment.app.c.CREATOR);
                qVar.h = parcel.createTypedArrayList(androidx.fragment.app.o.CREATOR);
                return qVar;
            case 8:
                return new androidx.fragment.app.s(parcel);
            default:
                P p2 = new P(parcel);
                p2.f798a = parcel.readByte() != 0;
                return p2;
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i2) {
        switch (this.f45a) {
            case 0:
                return new n[i2];
            case 1:
                return new P.k[i2];
            case 2:
                return new ParcelImpl[i2];
            case 3:
                return new androidx.activity.result.a[i2];
            case 4:
                return new androidx.fragment.app.b[i2];
            case 5:
                return new androidx.fragment.app.c[i2];
            case 6:
                return new androidx.fragment.app.o[i2];
            case 7:
                return new androidx.fragment.app.q[i2];
            case 8:
                return new androidx.fragment.app.s[i2];
            default:
                return new P[i2];
        }
    }
}
