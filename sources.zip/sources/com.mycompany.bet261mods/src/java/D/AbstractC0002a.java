package d;

import android.R;

/* JADX INFO: renamed from: d.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class AbstractC0002a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f318a = {2130903091, 2130903092, 2130903093, 2130903140, 2130903141, 2130903142, 2130903143, 2130903144, 2130903145, 2130903152, 2130903157, 2130903158, 2130903177, 2130903195, 2130903196, 2130903197, 2130903198, 2130903199, 2130903204, 2130903207, 2130903227, 2130903235, 2130903247, 2130903250, 2130903251, 2130903279, 2130903282, 2130903311, 2130903320};
    public static final int[] b = {R.attr.layout_gravity};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int[] f319c = {R.attr.minWidth};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int[] f320d = {2130903091, 2130903092, 2130903124, 2130903195, 2130903282, 2130903320};

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final int[] f321e = {R.attr.layout, 2130903105, 2130903106, 2130903216, 2130903217, 2130903232, 2130903269, 2130903270};
    public static final int[] f = {R.attr.src, 2130903275, 2130903309, 2130903310};

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final int[] f322g = {R.attr.thumb, 2130903306, 2130903307, 2130903308};

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final int[] f323h = {R.attr.textAppearance, R.attr.drawableTop, R.attr.drawableBottom, R.attr.drawableLeft, R.attr.drawableRight, R.attr.drawableStart, R.attr.drawableEnd};

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final int[] f324i = {R.attr.textAppearance, 2130903086, 2130903087, 2130903088, 2130903089, 2130903090, 2130903162, 2130903163, 2130903164, 2130903165, 2130903167, 2130903168, 2130903169, 2130903170, 2130903178, 2130903180, 2130903182, 2130903191, 2130903209, 2130903211, 2130903289, 2130903300};

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final int[] f325j = {R.attr.windowIsFloating, R.attr.windowAnimationStyle, 2130903040, 2130903041, 2130903042, 2130903043, 2130903044, 2130903045, 2130903046, 2130903047, 2130903048, 2130903049, 2130903050, 2130903051, 2130903052, 2130903054, 2130903055, 2130903056, 2130903057, 2130903058, 2130903059, 2130903060, 2130903061, 2130903062, 2130903063, 2130903064, 2130903065, 2130903066, 2130903067, 2130903068, 2130903069, 2130903070, 2130903071, 2130903072, 2130903075, 2130903076, 2130903077, 2130903078, 2130903079, 2130903085, 2130903097, 2130903098, 2130903099, 2130903100, 2130903101, 2130903102, 2130903107, 2130903108, 2130903121, 2130903122, 2130903128, 2130903129, 2130903130, 2130903131, 2130903132, 2130903133, 2130903134, 2130903135, 2130903136, 2130903137, 2130903151, 2130903154, 2130903155, 2130903156, 2130903159, 2130903161, 2130903172, 2130903173, 2130903174, 2130903175, 2130903176, 2130903197, 2130903203, 2130903212, 2130903213, 2130903214, 2130903215, 2130903218, 2130903219, 2130903220, 2130903221, 2130903222, 2130903223, 2130903224, 2130903225, 2130903226, 2130903243, 2130903244, 2130903245, 2130903246, 2130903248, 2130903255, 2130903256, 2130903257, 2130903258, 2130903261, 2130903262, 2130903263, 2130903264, 2130903272, 2130903273, 2130903287, 2130903290, 2130903291, 2130903292, 2130903293, 2130903294, 2130903295, 2130903296, 2130903297, 2130903298, 2130903299, 2130903321, 2130903322, 2130903323, 2130903324, 2130903330, 2130903332, 2130903333, 2130903334, 2130903335, 2130903336, 2130903337, 2130903338, 2130903339, 2130903340, 2130903341};

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final int[] f326k = {2130903080};

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final int[] f327l = {R.attr.checkMark, 2130903118, 2130903119, 2130903120};

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final int[] f328m = {R.attr.button, 2130903103, 2130903109, 2130903110};

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final int[] f329n = {R.attr.gravity, R.attr.orientation, R.attr.baselineAligned, R.attr.baselineAlignedChildIndex, R.attr.weightSum, 2130903158, 2130903160, 2130903230, 2130903267};

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final int[] f330o = {R.attr.dropDownHorizontalOffset, R.attr.dropDownVerticalOffset};

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final int[] f331p = {R.attr.enabled, R.attr.id, R.attr.visible, R.attr.menuCategory, R.attr.orderInCategory, R.attr.checkableBehavior};

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final int[] f332q = {R.attr.icon, R.attr.enabled, R.attr.id, R.attr.checked, R.attr.visible, R.attr.menuCategory, R.attr.orderInCategory, R.attr.title, R.attr.titleCondensed, R.attr.alphabeticShortcut, R.attr.numericShortcut, R.attr.checkable, R.attr.onClick, 2130903053, 2130903073, 2130903074, 2130903082, 2130903139, 2130903200, 2130903201, 2130903237, 2130903266, 2130903325};

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final int[] f333r = {R.attr.windowAnimationStyle, R.attr.itemTextAppearance, R.attr.horizontalDivider, R.attr.verticalDivider, R.attr.headerBackground, R.attr.itemBackground, R.attr.itemIconDisabledAlpha, 2130903249, 2130903277};

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final int[] f334s = {R.attr.popupBackground, R.attr.popupAnimationStyle, 2130903238};

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final int[] f335t = {2130903239, 2130903242};

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final int[] f336u = {R.attr.entries, R.attr.popupBackground, R.attr.prompt, R.attr.dropDownWidth, 2130903247};

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final int[] f337v = {R.attr.textSize, R.attr.typeface, R.attr.textStyle, R.attr.textColor, R.attr.textColorHint, R.attr.textColorLink, R.attr.shadowColor, R.attr.shadowDx, R.attr.shadowDy, R.attr.shadowRadius, R.attr.fontFamily, R.attr.textFontWeight, 2130903182, 2130903191, 2130903289, 2130903300};

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final int[] f338w = {R.attr.gravity, R.attr.minHeight, 2130903104, 2130903125, 2130903126, 2130903140, 2130903141, 2130903142, 2130903143, 2130903144, 2130903145, 2130903227, 2130903228, 2130903229, 2130903231, 2130903233, 2130903234, 2130903247, 2130903279, 2130903280, 2130903281, 2130903311, 2130903312, 2130903313, 2130903314, 2130903315, 2130903316, 2130903317, 2130903318, 2130903319};

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final int[] f339x = {R.attr.theme, R.attr.focusable, 2130903240, 2130903241, 2130903301};

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final int[] f340y = {R.attr.background, 2130903094, 2130903095};

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final int[] f341z = {R.attr.id, R.attr.layout, R.attr.inflatedId};
}
