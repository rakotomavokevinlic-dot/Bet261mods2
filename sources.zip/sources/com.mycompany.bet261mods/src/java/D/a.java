package D;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f9a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f10c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f11d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f12e;
    public long f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public long f13g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public float f14h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f15i;

    public final float a(long j2) {
        if (j2 < this.f12e) {
            return 0.0f;
        }
        long j3 = this.f13g;
        if (j3 < 0 || j2 < j3) {
            return i.b((j2 - r0) / this.f9a, 0.0f, 1.0f) * 0.5f;
        }
        float f = this.f14h;
        return (i.b((j2 - j3) / this.f15i, 0.0f, 1.0f) * f) + (1.0f - f);
    }
}
