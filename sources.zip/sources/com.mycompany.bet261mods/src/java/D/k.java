package D;

import android.view.ViewGroup;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class k {
    public static boolean a(ViewGroup viewGroup) {
        return viewGroup.getClipToPadding();
    }
}
