package D;

import android.widget.TextView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class s {
    public static void a(TextView textView, int i2, float f) {
        textView.setLineHeight(i2, f);
    }
}
