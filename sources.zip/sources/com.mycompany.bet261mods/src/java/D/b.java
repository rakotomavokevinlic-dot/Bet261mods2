package D;

import android.app.NotificationManager;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.ListView;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import com.mycompany.bet261mods.MainActivity;
import e.I;
import e.v;
import i.C0077t0;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.WeakHashMap;
import y.K;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class b implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16a;
    public final /* synthetic */ Object b;

    public /* synthetic */ b(int i2, Object obj) {
        this.f16a = i2;
        this.b = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj = this.b;
        switch (this.f16a) {
            case 0:
                i iVar = (i) obj;
                if (iVar.f42o) {
                    boolean z2 = iVar.f40m;
                    a aVar = iVar.f30a;
                    if (z2) {
                        iVar.f40m = false;
                        long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                        aVar.f12e = jCurrentAnimationTimeMillis;
                        aVar.f13g = -1L;
                        aVar.f = jCurrentAnimationTimeMillis;
                        aVar.f14h = 0.5f;
                    }
                    if ((aVar.f13g > 0 && AnimationUtils.currentAnimationTimeMillis() > aVar.f13g + ((long) aVar.f15i)) || !iVar.e()) {
                        iVar.f42o = false;
                        return;
                    }
                    boolean z3 = iVar.f41n;
                    ListView listView = iVar.f31c;
                    if (z3) {
                        iVar.f41n = false;
                        long jUptimeMillis = SystemClock.uptimeMillis();
                        MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                        listView.onTouchEvent(motionEventObtain);
                        motionEventObtain.recycle();
                    }
                    if (aVar.f == 0) {
                        throw new RuntimeException("Cannot compute scroll delta before calling start()");
                    }
                    long jCurrentAnimationTimeMillis2 = AnimationUtils.currentAnimationTimeMillis();
                    float fA = aVar.a(jCurrentAnimationTimeMillis2);
                    long j2 = jCurrentAnimationTimeMillis2 - aVar.f;
                    aVar.f = jCurrentAnimationTimeMillis2;
                    iVar.f44q.scrollListBy((int) (j2 * ((fA * 4.0f) + ((-4.0f) * fA * fA)) * aVar.f11d));
                    WeakHashMap weakHashMap = K.f1165a;
                    listView.postOnAnimation(this);
                    return;
                }
                return;
            case 1:
                ((NotificationManager) obj).cancel(1);
                return;
            case 2:
                MainActivity mainActivity = (MainActivity) obj;
                try {
                    HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("https://install.webintoapp.com/install/").openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                    String str = "key=" + URLEncoder.encode("ElTzsRnXXmyEfdMynZSnGxJFeAdCWGHM", "UTF-8") + "&app_version=" + URLEncoder.encode("1.0", "UTF-8") + "&device=" + URLEncoder.encode("Android", "UTF-8") + "&device_version=" + URLEncoder.encode(System.getProperty("os.version"), "UTF-8") + "&resolution=" + URLEncoder.encode(MainActivity.p(mainActivity), "UTF-8");
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    bufferedWriter.write(str);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    int responseCode = httpURLConnection.getResponseCode();
                    Log.d("MainActivity", "POST Response Code: " + responseCode);
                    if (responseCode == 200) {
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                        StringBuilder sb = new StringBuilder();
                        while (true) {
                            String line = bufferedReader.readLine();
                            if (line != null) {
                                sb.append(line);
                            } else {
                                bufferedReader.close();
                                Log.d("MainActivity", "Response: " + ((Object) sb));
                                mainActivity.f306A.edit().putBoolean("firstrun", false).apply();
                            }
                        }
                    } else {
                        Log.d("MainActivity", "POST request did not work");
                    }
                    httpURLConnection.disconnect();
                    return;
                } catch (Exception e2) {
                    Log.e("MainActivity", "Error sending first run notification", e2);
                    return;
                }
            case 3:
                try {
                    androidx.activity.l.e((androidx.activity.l) obj);
                    return;
                } catch (IllegalStateException e3) {
                    if (!TextUtils.equals(e3.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                        throw e3;
                    }
                    return;
                } catch (NullPointerException e4) {
                    if (!TextUtils.equals(e4.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference")) {
                        throw e4;
                    }
                    return;
                }
            case 4:
                ((androidx.fragment.app.p) obj).e(true);
                return;
            case 5:
                I i2 = (I) obj;
                v vVar = i2.f418p;
                Menu menuK0 = i2.k0();
                h.n nVar = menuK0 instanceof h.n ? (h.n) menuK0 : null;
                if (nVar != null) {
                    nVar.w();
                }
                try {
                    menuK0.clear();
                    if (!vVar.onCreatePanelMenu(0, menuK0) || !vVar.onPreparePanel(0, null, menuK0)) {
                        menuK0.clear();
                        break;
                    }
                    if (nVar != null) {
                        nVar.v();
                        return;
                    }
                    return;
                } finally {
                    if (nVar != null) {
                        nVar.v();
                    }
                }
            case 6:
                C0077t0 c0077t0 = (C0077t0) obj;
                c0077t0.f962l = null;
                c0077t0.drawableStateChanged();
                return;
            case 7:
                View view = (SearchView.SearchAutoComplete) obj;
                if (((SearchView.SearchAutoComplete) view).f) {
                    ((InputMethodManager) view.getContext().getSystemService("input_method")).showSoftInput(view, 0);
                    ((SearchView.SearchAutoComplete) view).f = false;
                    return;
                }
                return;
            case 8:
                ((Toolbar) obj).u();
                return;
            default:
                Object obj2 = ((C.j) obj).b;
                return;
        }
    }

    public b(C.j jVar, int i2) {
        this.f16a = 9;
        this.b = jVar;
    }
}
