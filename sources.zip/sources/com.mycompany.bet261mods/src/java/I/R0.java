package i;

import g.InterfaceC0021b;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class R0 extends AbstractC0087y0 implements InterfaceC0021b {
}
