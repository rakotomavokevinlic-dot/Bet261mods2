package i;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class U {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f818a;
    public final /* synthetic */ int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ WeakReference f819c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Z f820d;

    public U(Z z2, int i2, int i3, WeakReference weakReference) {
        this.f820d = z2;
        this.f818a = i2;
        this.b = i3;
        this.f819c = weakReference;
    }

    public final void a() {
        new Handler(Looper.getMainLooper()).post(new androidx.activity.d(6, this));
    }

    public final void b(Typeface typeface) {
        int i2;
        if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f818a) != -1) {
            typeface = Y.a(typeface, i2, (this.b & 2) != 0);
        }
        Z z2 = this.f820d;
        if (z2.f838m) {
            z2.f837l = typeface;
            TextView textView = (TextView) this.f819c.get();
            if (textView != null) {
                if (textView.isAttachedToWindow()) {
                    textView.post(new V(textView, typeface, z2.f835j));
                } else {
                    textView.setTypeface(typeface, z2.f835j);
                }
            }
        }
    }
}
