package i;

/* JADX INFO: renamed from: i.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface InterfaceC0063m {
    boolean a();

    boolean b();
}
