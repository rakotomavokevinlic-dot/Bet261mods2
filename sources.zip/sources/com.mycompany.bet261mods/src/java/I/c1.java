package i;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class c1 extends E.c {
    public static final Parcelable.Creator<c1> CREATOR = new E.b(1);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f848c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f849d;

    public c1(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f848c = parcel.readInt();
        this.f849d = parcel.readInt() != 0;
    }

    @Override // E.c, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        super.writeToParcel(parcel, i2);
        parcel.writeInt(this.f848c);
        parcel.writeInt(this.f849d ? 1 : 0);
    }
}
