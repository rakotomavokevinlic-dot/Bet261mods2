package i;

import androidx.appcompat.widget.Toolbar;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final /* synthetic */ class W0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f826a;
    public final /* synthetic */ Toolbar b;

    public /* synthetic */ W0(Toolbar toolbar, int i2) {
        this.f826a = i2;
        this.b = toolbar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f826a) {
            case 0:
                Z0 z0 = this.b.M;
                h.p pVar = z0 == null ? null : z0.b;
                if (pVar != null) {
                    pVar.collapseActionView();
                }
                break;
            default:
                this.b.m();
                break;
        }
    }
}
