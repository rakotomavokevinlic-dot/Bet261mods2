package i;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface H0 {
    void r(h.n nVar, h.p pVar);

    void t(h.n nVar, h.p pVar);
}
