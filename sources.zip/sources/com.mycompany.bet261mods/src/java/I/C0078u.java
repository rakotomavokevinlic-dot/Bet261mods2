package i;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import r.AbstractC0119a;

/* JADX INFO: renamed from: i.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0078u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int[] f963a = {2131165261, 2131165259, 2131165185};
    public final int[] b = {2131165209, 2131165244, 2131165216, 2131165211, 2131165212, 2131165215, 2131165214};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int[] f964c = {2131165258, 2131165260, 2131165202, 2131165254, 2131165255, 2131165256, 2131165257};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f965d = {2131165234, 2131165200, 2131165233};

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int[] f966e = {2131165252, 2131165262};
    public final int[] f = {2131165188, 2131165194, 2131165189, 2131165195};

    public static boolean a(int[] iArr, int i2) {
        for (int i3 : iArr) {
            if (i3 == i2) {
                return true;
            }
        }
        return false;
    }

    public static ColorStateList b(Context context, int i2) {
        int iC = S0.c(context, 2130903132);
        int iB = S0.b(context, 2130903130);
        int[] iArr = S0.b;
        int[] iArr2 = S0.f814d;
        int iB2 = AbstractC0119a.b(iC, i2);
        return new ColorStateList(new int[][]{iArr, iArr2, S0.f813c, S0.f}, new int[]{iB, iB2, AbstractC0119a.b(iC, i2), i2});
    }

    public static LayerDrawable c(N0 n0, Context context, int i2) {
        BitmapDrawable bitmapDrawable;
        BitmapDrawable bitmapDrawable2;
        BitmapDrawable bitmapDrawable3;
        int dimensionPixelSize = context.getResources().getDimensionPixelSize(i2);
        Drawable drawableC = n0.c(context, 2131165248);
        Drawable drawableC2 = n0.c(context, 2131165249);
        if ((drawableC instanceof BitmapDrawable) && drawableC.getIntrinsicWidth() == dimensionPixelSize && drawableC.getIntrinsicHeight() == dimensionPixelSize) {
            bitmapDrawable = (BitmapDrawable) drawableC;
            bitmapDrawable2 = new BitmapDrawable(bitmapDrawable.getBitmap());
        } else {
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmapCreateBitmap);
            drawableC.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
            drawableC.draw(canvas);
            bitmapDrawable = new BitmapDrawable(bitmapCreateBitmap);
            bitmapDrawable2 = new BitmapDrawable(bitmapCreateBitmap);
        }
        bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
        if ((drawableC2 instanceof BitmapDrawable) && drawableC2.getIntrinsicWidth() == dimensionPixelSize && drawableC2.getIntrinsicHeight() == dimensionPixelSize) {
            bitmapDrawable3 = (BitmapDrawable) drawableC2;
        } else {
            Bitmap bitmapCreateBitmap2 = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
            Canvas canvas2 = new Canvas(bitmapCreateBitmap2);
            drawableC2.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
            drawableC2.draw(canvas2);
            bitmapDrawable3 = new BitmapDrawable(bitmapCreateBitmap2);
        }
        LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{bitmapDrawable, bitmapDrawable3, bitmapDrawable2});
        layerDrawable.setId(0, R.id.background);
        layerDrawable.setId(1, R.id.secondaryProgress);
        layerDrawable.setId(2, R.id.progress);
        return layerDrawable;
    }

    public static void e(Drawable drawable, int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter porterDuffColorFilterE;
        Drawable drawableMutate = drawable.mutate();
        if (mode == null) {
            mode = C0080v.b;
        }
        PorterDuff.Mode mode2 = C0080v.b;
        synchronized (C0080v.class) {
            porterDuffColorFilterE = N0.e(i2, mode);
        }
        drawableMutate.setColorFilter(porterDuffColorFilterE);
    }

    public final ColorStateList d(Context context, int i2) {
        if (i2 == 2131165205) {
            return D.g.t(context, 2131034133);
        }
        if (i2 == 2131165251) {
            return D.g.t(context, 2131034136);
        }
        if (i2 != 2131165250) {
            if (i2 == 2131165193) {
                return b(context, S0.c(context, 2130903130));
            }
            if (i2 == 2131165187) {
                return b(context, 0);
            }
            if (i2 == 2131165192) {
                return b(context, S0.c(context, 2130903128));
            }
            if (i2 == 2131165246 || i2 == 2131165247) {
                return D.g.t(context, 2131034135);
            }
            if (a(this.b, i2)) {
                return S0.d(context, 2130903133);
            }
            if (a(this.f966e, i2)) {
                return D.g.t(context, 2131034132);
            }
            if (a(this.f, i2)) {
                return D.g.t(context, 2131034131);
            }
            if (i2 == 2131165243) {
                return D.g.t(context, 2131034134);
            }
            return null;
        }
        int[][] iArr = new int[3][];
        int[] iArr2 = new int[3];
        ColorStateList colorStateListD = S0.d(context, 2130903137);
        if (colorStateListD == null || !colorStateListD.isStateful()) {
            iArr[0] = S0.b;
            iArr2[0] = S0.b(context, 2130903137);
            iArr[1] = S0.f815e;
            iArr2[1] = S0.c(context, 2130903131);
            iArr[2] = S0.f;
            iArr2[2] = S0.c(context, 2130903137);
        } else {
            int[] iArr3 = S0.b;
            iArr[0] = iArr3;
            iArr2[0] = colorStateListD.getColorForState(iArr3, 0);
            iArr[1] = S0.f815e;
            iArr2[1] = S0.c(context, 2130903131);
            iArr[2] = S0.f;
            iArr2[2] = colorStateListD.getDefaultColor();
        }
        return new ColorStateList(iArr, iArr2);
    }
}
