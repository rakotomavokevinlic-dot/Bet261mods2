package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class r extends Button {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0071q f943a;
    public final Z b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C0086y f944c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130903107);
        T0.a(context);
        S0.a(this, getContext());
        C0071q c0071q = new C0071q(this);
        this.f943a = c0071q;
        c0071q.d(attributeSet, 2130903107);
        Z z2 = new Z(this);
        this.b = z2;
        z2.f(attributeSet, 2130903107);
        z2.b();
        getEmojiTextViewHelper().a(attributeSet, 2130903107);
    }

    private C0086y getEmojiTextViewHelper() {
        if (this.f944c == null) {
            this.f944c = new C0086y(this);
        }
        return this.f944c;
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0071q c0071q = this.f943a;
        if (c0071q != null) {
            c0071q.a();
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (m1.f927c) {
            return super.getAutoSizeMaxTextSize();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f834i.f889e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (m1.f927c) {
            return super.getAutoSizeMinTextSize();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f834i.f888d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (m1.f927c) {
            return super.getAutoSizeStepGranularity();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f834i.f887c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (m1.f927c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        Z z2 = this.b;
        return z2 != null ? z2.f834i.f : new int[0];
    }

    @Override // android.widget.TextView
    public int getAutoSizeTextType() {
        if (m1.f927c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        Z z2 = this.b;
        if (z2 != null) {
            return z2.f834i.f886a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return D.g.i0(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0071q c0071q = this.f943a;
        if (c0071q != null) {
            return c0071q.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0071q c0071q = this.f943a;
        if (c0071q != null) {
            return c0071q.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        Z z3 = this.b;
        if (z3 == null || m1.f927c) {
            return;
        }
        z3.f834i.a();
    }

    @Override // android.widget.TextView
    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        Z z2 = this.b;
        if (z2 == null || m1.f927c) {
            return;
        }
        C0056i0 c0056i0 = z2.f834i;
        if (c0056i0.f()) {
            c0056i0.a();
        }
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (m1.f927c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.i(i2, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (m1.f927c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.j(iArr, i2);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (m1.f927c) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.k(i2);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0071q c0071q = this.f943a;
        if (c0071q != null) {
            c0071q.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0071q c0071q = this.f943a;
        if (c0071q != null) {
            c0071q.f(i2);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(D.g.j0(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((D.g) getEmojiTextViewHelper().b.b).y(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z2) {
        Z z3 = this.b;
        if (z3 != null) {
            z3.f828a.setAllCaps(z2);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0071q c0071q = this.f943a;
        if (c0071q != null) {
            c0071q.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0071q c0071q = this.f943a;
        if (c0071q != null) {
            c0071q.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Z z2 = this.b;
        z2.l(colorStateList);
        z2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Z z2 = this.b;
        z2.m(mode);
        z2.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        Z z2 = this.b;
        if (z2 != null) {
            z2.g(context, i2);
        }
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i2, float f) {
        boolean z2 = m1.f927c;
        if (z2) {
            super.setTextSize(i2, f);
            return;
        }
        Z z3 = this.b;
        if (z3 == null || z2) {
            return;
        }
        C0056i0 c0056i0 = z3.f834i;
        if (c0056i0.f()) {
            return;
        }
        c0056i0.g(i2, f);
    }
}
