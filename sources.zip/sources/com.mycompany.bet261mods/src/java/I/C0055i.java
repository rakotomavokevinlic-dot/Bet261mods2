package i;

import h.AbstractC0034c;

/* JADX INFO: renamed from: i.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0055i extends AbstractC0034c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0061l f883a;

    public C0055i(C0061l c0061l) {
        this.f883a = c0061l;
    }
}
