package i;

import android.text.StaticLayout;
import android.widget.TextView;

/* JADX INFO: renamed from: i.h0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class AbstractC0054h0 {
    public abstract void a(StaticLayout.Builder builder, TextView textView);

    public boolean b(TextView textView) {
        return ((Boolean) C0056i0.e(textView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
    }
}
