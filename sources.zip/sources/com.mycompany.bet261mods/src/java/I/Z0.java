package i;

import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import g.InterfaceC0021b;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class Z0 implements h.z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public h.n f839a;
    public h.p b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Toolbar f840c;

    public Z0(Toolbar toolbar) {
        this.f840c = toolbar;
    }

    @Override // h.z
    public final void c() {
        if (this.b != null) {
            h.n nVar = this.f839a;
            if (nVar != null) {
                int size = nVar.f.size();
                for (int i2 = 0; i2 < size; i2++) {
                    if (this.f839a.getItem(i2) == this.b) {
                        return;
                    }
                }
            }
            d(this.b);
        }
    }

    @Override // h.z
    public final boolean d(h.p pVar) {
        Toolbar toolbar = this.f840c;
        KeyEvent.Callback callback = toolbar.i;
        if (callback instanceof InterfaceC0021b) {
            ((h.r) ((InterfaceC0021b) callback)).f712a.onActionViewCollapsed();
        }
        toolbar.removeView(toolbar.i);
        toolbar.removeView(toolbar.h);
        toolbar.i = null;
        ArrayList arrayList = toolbar.E;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.b = null;
        toolbar.requestLayout();
        pVar.f685C = false;
        pVar.f697n.p(false);
        toolbar.v();
        return true;
    }

    @Override // h.z
    public final void g(Context context, h.n nVar) {
        h.p pVar;
        h.n nVar2 = this.f839a;
        if (nVar2 != null && (pVar = this.b) != null) {
            nVar2.d(pVar);
        }
        this.f839a = nVar;
    }

    @Override // h.z
    public final boolean i() {
        return false;
    }

    @Override // h.z
    public final boolean j(h.F f) {
        return false;
    }

    @Override // h.z
    public final boolean k(h.p pVar) {
        Toolbar toolbar = this.f840c;
        toolbar.c();
        ViewParent parent = toolbar.h.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.h);
            }
            toolbar.addView(toolbar.h);
        }
        View actionView = pVar.getActionView();
        toolbar.i = actionView;
        this.b = pVar;
        ViewParent parent2 = actionView.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.i);
            }
            a1 a1VarH = Toolbar.h();
            a1VarH.f843a = (toolbar.n & 112) | 8388611;
            a1VarH.b = 2;
            toolbar.i.setLayoutParams(a1VarH);
            toolbar.addView(toolbar.i);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            ActionMenuView childAt = toolbar.getChildAt(childCount);
            if (((a1) childAt.getLayoutParams()).b != 2 && childAt != toolbar.a) {
                toolbar.removeViewAt(childCount);
                toolbar.E.add(childAt);
            }
        }
        toolbar.requestLayout();
        pVar.f685C = true;
        pVar.f697n.p(false);
        KeyEvent.Callback callback = toolbar.i;
        if (callback instanceof InterfaceC0021b) {
            ((h.r) ((InterfaceC0021b) callback)).f712a.onActionViewExpanded();
        }
        toolbar.v();
        return true;
    }

    @Override // h.z
    public final void b(h.n nVar, boolean z2) {
    }
}
