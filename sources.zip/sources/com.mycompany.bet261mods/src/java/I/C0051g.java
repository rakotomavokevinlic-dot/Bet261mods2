package i;

import android.view.View;

/* JADX INFO: renamed from: i.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0051g extends View {
    @Override // android.view.View
    public final int getWindowSystemUiVisibility() {
        return 0;
    }
}
