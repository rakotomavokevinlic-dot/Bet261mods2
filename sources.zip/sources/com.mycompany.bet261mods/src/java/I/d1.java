package i;

import android.content.Context;
import android.view.View;
import android.view.Window;
import h.C0032a;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class d1 implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0032a f856a;
    public final /* synthetic */ e1 b;

    public d1(e1 e1Var) {
        this.b = e1Var;
        Context context = e1Var.f857a.getContext();
        CharSequence charSequence = e1Var.f862h;
        C0032a c0032a = new C0032a();
        c0032a.f606e = 4096;
        c0032a.f607g = 4096;
        c0032a.f612l = null;
        c0032a.f613m = null;
        c0032a.f614n = false;
        c0032a.f615o = false;
        c0032a.f616p = 16;
        c0032a.f609i = context;
        c0032a.f603a = charSequence;
        this.f856a = c0032a;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        e1 e1Var = this.b;
        Window.Callback callback = e1Var.f865k;
        if (callback == null || !e1Var.f866l) {
            return;
        }
        callback.onMenuItemSelected(0, this.f856a);
    }
}
