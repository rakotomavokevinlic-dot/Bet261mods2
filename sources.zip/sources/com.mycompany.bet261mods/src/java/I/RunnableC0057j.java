package i;

import android.view.View;

/* JADX INFO: renamed from: i.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class RunnableC0057j implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0053h f900a;
    public final /* synthetic */ C0061l b;

    public RunnableC0057j(C0061l c0061l, C0053h c0053h) {
        this.b = c0061l;
        this.f900a = c0053h;
    }

    @Override // java.lang.Runnable
    public final void run() {
        h.l lVar;
        C0061l c0061l = this.b;
        h.n nVar = c0061l.f906c;
        if (nVar != null && (lVar = nVar.f662e) != null) {
            lVar.g(nVar);
        }
        View view = (View) c0061l.f910h;
        if (view != null && view.getWindowToken() != null) {
            C0053h c0053h = this.f900a;
            if (c0053h.b()) {
                c0061l.f921s = c0053h;
            } else if (c0053h.f722e != null) {
                c0053h.d(0, 0, false, false);
                c0061l.f921s = c0053h;
            }
        }
        c0061l.f923u = null;
    }
}
