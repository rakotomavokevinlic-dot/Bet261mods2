package i;

import android.os.Build;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class m1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static boolean f926a;
    public static Method b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final boolean f927c;

    static {
        f927c = Build.VERSION.SDK_INT >= 27;
    }
}
