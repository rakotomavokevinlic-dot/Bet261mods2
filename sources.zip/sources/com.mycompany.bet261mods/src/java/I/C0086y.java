package i;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.TextView;
import d.AbstractC0002a;

/* JADX INFO: renamed from: i.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0086y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextView f982a;
    public final C.j b;

    public C0086y(TextView textView) {
        this.f982a = textView;
        this.b = new C.j(textView);
    }

    public final void a(AttributeSet attributeSet, int i2) {
        TypedArray typedArrayObtainStyledAttributes = this.f982a.getContext().obtainStyledAttributes(attributeSet, AbstractC0002a.f324i, i2, 0);
        try {
            boolean z2 = typedArrayObtainStyledAttributes.hasValue(14) ? typedArrayObtainStyledAttributes.getBoolean(14, true) : true;
            typedArrayObtainStyledAttributes.recycle();
            c(z2);
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final void b(boolean z2) {
        ((D.g) this.b.b).Y(z2);
    }

    public final void c(boolean z2) {
        ((D.g) this.b.b).a0(z2);
    }
}
