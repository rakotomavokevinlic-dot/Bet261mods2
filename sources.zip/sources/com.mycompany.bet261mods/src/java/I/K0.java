package i;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class K0 extends C0077t0 {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f778m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f779n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public H0 f780o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public h.p f781p;

    public K0(Context context, boolean z2) {
        super(context, z2);
        if (1 == context.getResources().getConfiguration().getLayoutDirection()) {
            this.f778m = 21;
            this.f779n = 22;
        } else {
            this.f778m = 22;
            this.f779n = 21;
        }
    }

    @Override // i.C0077t0, android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        h.k kVar;
        int headersCount;
        int iPointToPosition;
        int i2;
        if (this.f780o != null) {
            ListAdapter adapter = getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                headersCount = headerViewListAdapter.getHeadersCount();
                kVar = (h.k) headerViewListAdapter.getWrappedAdapter();
            } else {
                kVar = (h.k) adapter;
                headersCount = 0;
            }
            h.p item = (motionEvent.getAction() == 10 || (iPointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY())) == -1 || (i2 = iPointToPosition - headersCount) < 0 || i2 >= kVar.getCount()) ? null : kVar.getItem(i2);
            h.p pVar = this.f781p;
            if (pVar != item) {
                h.n nVar = kVar.f654a;
                if (pVar != null) {
                    this.f780o.t(nVar, pVar);
                }
                this.f781p = item;
                if (item != null) {
                    this.f780o.r(nVar, item);
                }
            }
        }
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        ListMenuItemView selectedView = getSelectedView();
        if (selectedView != null && i2 == this.f778m) {
            if (selectedView.isEnabled() && selectedView.getItemData().hasSubMenu()) {
                performItemClick(selectedView, getSelectedItemPosition(), getSelectedItemId());
            }
            return true;
        }
        if (selectedView == null || i2 != this.f779n) {
            return super.onKeyDown(i2, keyEvent);
        }
        setSelection(-1);
        ListAdapter adapter = getAdapter();
        (adapter instanceof HeaderViewListAdapter ? (h.k) ((HeaderViewListAdapter) adapter).getWrappedAdapter() : (h.k) adapter).f654a.c(false);
        return true;
    }

    public void setHoverListener(H0 h02) {
        this.f780o = h02;
    }

    @Override // i.C0077t0, android.widget.AbsListView
    public /* bridge */ /* synthetic */ void setSelector(Drawable drawable) {
        super.setSelector(drawable);
    }
}
