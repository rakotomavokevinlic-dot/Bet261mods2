package i;

import androidx.appcompat.widget.ActionBarContextView;

/* JADX INFO: renamed from: i.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0039a implements y.S {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f841a = false;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ ActionBarContextView f842c;

    public C0039a(ActionBarContextView actionBarContextView) {
        this.f842c = actionBarContextView;
    }

    @Override // y.S
    public final void a() {
        if (this.f841a) {
            return;
        }
        ActionBarContextView actionBarContextView = this.f842c;
        actionBarContextView.f = null;
        ActionBarContextView.b(actionBarContextView, this.b);
    }

    @Override // y.S
    public final void b() {
        this.f841a = true;
    }

    @Override // y.S
    public final void c() {
        ActionBarContextView.a(this.f842c);
        this.f841a = false;
    }
}
