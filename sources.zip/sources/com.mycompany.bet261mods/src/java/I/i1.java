package i;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class i1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f895a;
    public final View b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final TextView f896c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final WindowManager.LayoutParams f897d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Rect f898e;
    public final int[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int[] f899g;

    public i1(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f897d = layoutParams;
        this.f898e = new Rect();
        this.f = new int[2];
        this.f899g = new int[2];
        this.f895a = context;
        View viewInflate = LayoutInflater.from(context).inflate(2131427355, (ViewGroup) null);
        this.b = viewInflate;
        this.f896c = (TextView) viewInflate.findViewById(2131230834);
        layoutParams.setTitle(i1.class.getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = 2131689476;
        layoutParams.flags = 24;
    }
}
