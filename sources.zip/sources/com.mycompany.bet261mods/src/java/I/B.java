package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public class B extends ImageView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0071q f730a;
    public final C0038A b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f731c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public B(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        T0.a(context);
        this.f731c = false;
        S0.a(this, getContext());
        C0071q c0071q = new C0071q(this);
        this.f730a = c0071q;
        c0071q.d(attributeSet, i2);
        C0038A c0038a = new C0038A(this);
        this.b = c0038a;
        c0038a.b(attributeSet, i2);
    }

    @Override // android.widget.ImageView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0071q c0071q = this.f730a;
        if (c0071q != null) {
            c0071q.a();
        }
        C0038A c0038a = this.b;
        if (c0038a != null) {
            c0038a.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0071q c0071q = this.f730a;
        if (c0071q != null) {
            return c0071q.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0071q c0071q = this.f730a;
        if (c0071q != null) {
            return c0071q.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        U0 u0;
        C0038A c0038a = this.b;
        if (c0038a == null || (u0 = c0038a.b) == null) {
            return null;
        }
        return u0.f821a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        U0 u0;
        C0038A c0038a = this.b;
        if (c0038a == null || (u0 = c0038a.b) == null) {
            return null;
        }
        return u0.b;
    }

    @Override // android.widget.ImageView, android.view.View
    public final boolean hasOverlappingRendering() {
        return !(this.b.f728a.getBackground() instanceof RippleDrawable) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0071q c0071q = this.f730a;
        if (c0071q != null) {
            c0071q.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0071q c0071q = this.f730a;
        if (c0071q != null) {
            c0071q.f(i2);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0038A c0038a = this.b;
        if (c0038a != null) {
            c0038a.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        C0038A c0038a = this.b;
        if (c0038a != null && drawable != null && !this.f731c) {
            c0038a.f729c = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (c0038a != null) {
            c0038a.a();
            if (this.f731c) {
                return;
            }
            ImageView imageView = c0038a.f728a;
            if (imageView.getDrawable() != null) {
                imageView.getDrawable().setLevel(c0038a.f729c);
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i2) {
        super.setImageLevel(i2);
        this.f731c = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i2) {
        C0038A c0038a = this.b;
        if (c0038a != null) {
            ImageView imageView = c0038a.f728a;
            if (i2 != 0) {
                Drawable drawableW = D.g.w(imageView.getContext(), i2);
                if (drawableW != null) {
                    AbstractC0066n0.a(drawableW);
                }
                imageView.setImageDrawable(drawableW);
            } else {
                imageView.setImageDrawable(null);
            }
            c0038a.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C0038A c0038a = this.b;
        if (c0038a != null) {
            c0038a.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0071q c0071q = this.f730a;
        if (c0071q != null) {
            c0071q.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0071q c0071q = this.f730a;
        if (c0071q != null) {
            c0071q.i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        C0038A c0038a = this.b;
        if (c0038a != null) {
            if (c0038a.b == null) {
                c0038a.b = new U0();
            }
            U0 u0 = c0038a.b;
            u0.f821a = colorStateList;
            u0.f823d = true;
            c0038a.a();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C0038A c0038a = this.b;
        if (c0038a != null) {
            if (c0038a.b == null) {
                c0038a.b = new U0();
            }
            U0 u0 = c0038a.b;
            u0.b = mode;
            u0.f822c = true;
            c0038a.a();
        }
    }
}
