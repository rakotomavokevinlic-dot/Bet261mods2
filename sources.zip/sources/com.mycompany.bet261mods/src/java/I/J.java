package i;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class J extends AbstractViewOnTouchListenerC0083w0 {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ O f776j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ S f777k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public J(S s2, S s3, O o2) {
        super(s3);
        this.f777k = s2;
        this.f776j = o2;
    }

    @Override // i.AbstractViewOnTouchListenerC0083w0
    public final h.D b() {
        return this.f776j;
    }

    @Override // i.AbstractViewOnTouchListenerC0083w0
    public final boolean c() {
        S s2 = this.f777k;
        if (s2.getInternalPopup().a()) {
            return true;
        }
        s2.f.e(s2.getTextDirection(), s2.getTextAlignment());
        return true;
    }
}
