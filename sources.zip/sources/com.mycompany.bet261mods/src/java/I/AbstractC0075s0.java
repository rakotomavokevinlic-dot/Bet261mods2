package i;

import android.widget.AbsListView;
import java.lang.reflect.Field;

/* JADX INFO: renamed from: i.s0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class AbstractC0075s0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Field f949a;

    static {
        Field declaredField = null;
        try {
            declaredField = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
            declaredField.setAccessible(true);
        } catch (NoSuchFieldException e2) {
            e2.printStackTrace();
        }
        f949a = declaredField;
    }
}
