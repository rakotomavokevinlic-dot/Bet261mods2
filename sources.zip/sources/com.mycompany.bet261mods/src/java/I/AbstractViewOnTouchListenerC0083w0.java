package i;

import android.view.View;
import android.view.ViewConfiguration;

/* JADX INFO: renamed from: i.w0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class AbstractViewOnTouchListenerC0083w0 implements View.OnTouchListener, View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f971a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f972c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final View f973d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public RunnableC0081v0 f974e;
    public RunnableC0081v0 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f975g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f976h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int[] f977i = new int[2];

    public AbstractViewOnTouchListenerC0083w0(View view) {
        this.f973d = view;
        view.setLongClickable(true);
        view.addOnAttachStateChangeListener(this);
        this.f971a = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
        int tapTimeout = ViewConfiguration.getTapTimeout();
        this.b = tapTimeout;
        this.f972c = (ViewConfiguration.getLongPressTimeout() + tapTimeout) / 2;
    }

    public final void a() {
        RunnableC0081v0 runnableC0081v0 = this.f;
        View view = this.f973d;
        if (runnableC0081v0 != null) {
            view.removeCallbacks(runnableC0081v0);
        }
        RunnableC0081v0 runnableC0081v02 = this.f974e;
        if (runnableC0081v02 != null) {
            view.removeCallbacks(runnableC0081v02);
        }
    }

    public abstract h.D b();

    public abstract boolean c();

    public boolean d() {
        h.D dB = b();
        if (dB == null || !dB.a()) {
            return true;
        }
        dB.dismiss();
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0100  */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onTouch(android.view.View r13, android.view.MotionEvent r14) {
        /*
            Method dump skipped, instruction units count: 284
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: i.AbstractViewOnTouchListenerC0083w0.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        this.f975g = false;
        this.f976h = -1;
        RunnableC0081v0 runnableC0081v0 = this.f974e;
        if (runnableC0081v0 != null) {
            this.f973d.removeCallbacks(runnableC0081v0);
        }
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
    }
}
