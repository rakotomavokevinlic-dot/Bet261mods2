package i;

import android.database.DataSetObserver;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class D0 extends DataSetObserver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ G0 f736a;

    public D0(G0 g02) {
        this.f736a = g02;
    }

    @Override // android.database.DataSetObserver
    public final void onChanged() {
        G0 g02 = this.f736a;
        if (g02.f769y.isShowing()) {
            g02.h();
        }
    }

    @Override // android.database.DataSetObserver
    public final void onInvalidated() {
        this.f736a.dismiss();
    }
}
