package i;

import android.view.View;
import android.widget.AdapterView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class M implements AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ O f785a;

    public M(O o2) {
        this.f785a = o2;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        O o2 = this.f785a;
        o2.f797F.setSelection(i2);
        S s2 = o2.f797F;
        if (s2.getOnItemClickListener() != null) {
            s2.performItemClick(view, i2, o2.f794C.getItemId(i2));
        }
        o2.dismiss();
    }
}
