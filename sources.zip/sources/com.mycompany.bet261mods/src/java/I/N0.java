package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.TypedValue;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import l.AbstractC0096d;
import l.C0097e;
import l.C0104l;
import p.AbstractC0114a;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class N0 {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static N0 f787g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public WeakHashMap f789a;
    public final WeakHashMap b = new WeakHashMap(0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TypedValue f790c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f791d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public C0078u f792e;
    public static final PorterDuff.Mode f = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final M0 f788h = new M0(6);

    public static synchronized N0 b() {
        try {
            if (f787g == null) {
                f787g = new N0();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f787g;
    }

    public static synchronized PorterDuffColorFilter e(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter;
        M0 m0 = f788h;
        m0.getClass();
        int i3 = (31 + i2) * 31;
        porterDuffColorFilter = (PorterDuffColorFilter) m0.a(Integer.valueOf(mode.hashCode() + i3));
        if (porterDuffColorFilter == null) {
            porterDuffColorFilter = new PorterDuffColorFilter(i2, mode);
        }
        return porterDuffColorFilter;
    }

    public final Drawable a(Context context, int i2) {
        Drawable drawableNewDrawable;
        Object obj;
        int i3;
        if (this.f790c == null) {
            this.f790c = new TypedValue();
        }
        TypedValue typedValue = this.f790c;
        context.getResources().getValue(i2, typedValue, true);
        long j2 = (((long) typedValue.assetCookie) << 32) | ((long) typedValue.data);
        synchronized (this) {
            C0097e c0097e = (C0097e) this.b.get(context);
            drawableNewDrawable = null;
            if (c0097e != null) {
                int iB = AbstractC0096d.b(c0097e.b, c0097e.f1030d, j2);
                if (iB < 0 || (obj = c0097e.f1029c[iB]) == C0097e.f1027e) {
                    obj = null;
                }
                WeakReference weakReference = (WeakReference) obj;
                if (weakReference != null) {
                    Drawable.ConstantState constantState = (Drawable.ConstantState) weakReference.get();
                    if (constantState != null) {
                        drawableNewDrawable = constantState.newDrawable(context.getResources());
                    } else {
                        int iB2 = AbstractC0096d.b(c0097e.b, c0097e.f1030d, j2);
                        if (iB2 >= 0) {
                            Object[] objArr = c0097e.f1029c;
                            Object obj2 = objArr[iB2];
                            Object obj3 = C0097e.f1027e;
                            if (obj2 != obj3) {
                                objArr[iB2] = obj3;
                                c0097e.f1028a = true;
                            }
                        }
                    }
                }
            }
        }
        if (drawableNewDrawable != null) {
            return drawableNewDrawable;
        }
        LayerDrawable layerDrawableC = null;
        if (this.f792e != null) {
            if (i2 == 2131165201) {
                layerDrawableC = new LayerDrawable(new Drawable[]{c(context, 2131165200), c(context, 2131165202)});
            } else if (i2 == 2131165236) {
                layerDrawableC = C0078u.c(this, context, 2131099707);
            } else if (i2 == 2131165235) {
                layerDrawableC = C0078u.c(this, context, 2131099708);
            } else if (i2 == 2131165237) {
                layerDrawableC = C0078u.c(this, context, 2131099709);
            }
        }
        if (layerDrawableC == null) {
            return layerDrawableC;
        }
        layerDrawableC.setChangingConfigurations(typedValue.changingConfigurations);
        synchronized (this) {
            try {
                Drawable.ConstantState constantState2 = layerDrawableC.getConstantState();
                if (constantState2 != null) {
                    C0097e c0097e2 = (C0097e) this.b.get(context);
                    if (c0097e2 == null) {
                        c0097e2 = new C0097e();
                        c0097e2.f1028a = false;
                        int i4 = 4;
                        while (true) {
                            i3 = 80;
                            if (i4 >= 32) {
                                break;
                            }
                            int i5 = (1 << i4) - 12;
                            if (80 <= i5) {
                                i3 = i5;
                                break;
                            }
                            i4++;
                        }
                        int i6 = i3 / 8;
                        c0097e2.b = new long[i6];
                        c0097e2.f1029c = new Object[i6];
                        this.b.put(context, c0097e2);
                    }
                    c0097e2.b(j2, new WeakReference(constantState2));
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return layerDrawableC;
    }

    public final synchronized Drawable c(Context context, int i2) {
        return d(context, i2, false);
    }

    public final synchronized Drawable d(Context context, int i2, boolean z2) {
        Drawable drawableA;
        try {
            if (!this.f791d) {
                this.f791d = true;
                Drawable drawableC = c(context, 2131165263);
                if (drawableC == null || (!(drawableC instanceof R.a) && !"android.graphics.drawable.VectorDrawable".equals(drawableC.getClass().getName()))) {
                    this.f791d = false;
                    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
                }
            }
            drawableA = a(context, i2);
            if (drawableA == null) {
                drawableA = AbstractC0114a.b(context, i2);
            }
            if (drawableA != null) {
                drawableA = g(context, i2, z2, drawableA);
            }
            if (drawableA != null) {
                AbstractC0066n0.a(drawableA);
            }
        } catch (Throwable th) {
            throw th;
        }
        return drawableA;
    }

    public final synchronized ColorStateList f(Context context, int i2) {
        ColorStateList colorStateList;
        C0104l c0104l;
        Object obj;
        WeakHashMap weakHashMap = this.f789a;
        ColorStateList colorStateListD = null;
        if (weakHashMap == null || (c0104l = (C0104l) weakHashMap.get(context)) == null) {
            colorStateList = null;
        } else {
            int iA = AbstractC0096d.a(c0104l.f1051c, i2, c0104l.f1050a);
            if (iA < 0 || (obj = c0104l.b[iA]) == C0104l.f1049d) {
                obj = null;
            }
            colorStateList = (ColorStateList) obj;
        }
        if (colorStateList == null) {
            C0078u c0078u = this.f792e;
            if (c0078u != null) {
                colorStateListD = c0078u.d(context, i2);
            }
            if (colorStateListD != null) {
                if (this.f789a == null) {
                    this.f789a = new WeakHashMap();
                }
                C0104l c0104l2 = (C0104l) this.f789a.get(context);
                if (c0104l2 == null) {
                    c0104l2 = new C0104l();
                    this.f789a.put(context, c0104l2);
                }
                c0104l2.a(i2, colorStateListD);
            }
            colorStateList = colorStateListD;
        }
        return colorStateList;
    }

    /* JADX WARN: Removed duplicated region for block: B:49:0x00e5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.graphics.drawable.Drawable g(android.content.Context r8, int r9, boolean r10, android.graphics.drawable.Drawable r11) {
        /*
            Method dump skipped, instruction units count: 264
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: i.N0.g(android.content.Context, int, boolean, android.graphics.drawable.Drawable):android.graphics.drawable.Drawable");
    }
}
