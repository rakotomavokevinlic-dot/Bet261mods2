package i;

import android.graphics.Typeface;
import android.widget.TextView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class V implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ TextView f824a;
    public final /* synthetic */ Typeface b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f825c;

    public V(TextView textView, Typeface typeface, int i2) {
        this.f824a = textView;
        this.b = typeface;
        this.f825c = i2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f824a.setTypeface(this.b, this.f825c);
    }
}
