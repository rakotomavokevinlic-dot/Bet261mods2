package i;

import android.app.Activity;
import android.content.ClipData;
import android.os.Build;
import android.text.Selection;
import android.text.Spannable;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;
import y.C0153e;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class G {
    public static boolean a(DragEvent dragEvent, TextView textView, Activity activity) {
        androidx.emoji2.text.j c0153e;
        activity.requestDragAndDropPermissions(dragEvent);
        int offsetForPosition = textView.getOffsetForPosition(dragEvent.getX(), dragEvent.getY());
        textView.beginBatchEdit();
        try {
            Selection.setSelection((Spannable) textView.getText(), offsetForPosition);
            ClipData clipData = dragEvent.getClipData();
            if (Build.VERSION.SDK_INT >= 31) {
                c0153e = new C.j(clipData, 3);
            } else {
                c0153e = new C0153e();
                c0153e.b = clipData;
                c0153e.f1199c = 3;
            }
            y.K.f(textView, c0153e.k());
            textView.endBatchEdit();
            return true;
        } catch (Throwable th) {
            textView.endBatchEdit();
            throw th;
        }
    }

    public static boolean b(DragEvent dragEvent, View view, Activity activity) {
        androidx.emoji2.text.j c0153e;
        activity.requestDragAndDropPermissions(dragEvent);
        ClipData clipData = dragEvent.getClipData();
        if (Build.VERSION.SDK_INT >= 31) {
            c0153e = new C.j(clipData, 3);
        } else {
            c0153e = new C0153e();
            c0153e.b = clipData;
            c0153e.f1199c = 3;
        }
        y.K.f(view, c0153e.k());
        return true;
    }
}
