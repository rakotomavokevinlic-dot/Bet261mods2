package i;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import h.ViewTreeObserverOnGlobalLayoutListenerC0035d;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class O extends G0 implements Q {

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public CharSequence f793B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public L f794C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final Rect f795D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public int f796E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final /* synthetic */ S f797F;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public O(S s2, Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130903273);
        this.f797F = s2;
        this.f795D = new Rect();
        this.f759o = s2;
        this.f768x = true;
        this.f769y.setFocusable(true);
        this.f760p = new M(this);
    }

    @Override // i.Q
    public final CharSequence b() {
        return this.f793B;
    }

    @Override // i.Q
    public final void e(int i2, int i3) {
        ViewTreeObserver viewTreeObserver;
        D d2 = this.f769y;
        boolean zIsShowing = d2.isShowing();
        q();
        this.f769y.setInputMethodMode(2);
        h();
        C0077t0 c0077t0 = this.f748c;
        c0077t0.setChoiceMode(1);
        c0077t0.setTextDirection(i2);
        c0077t0.setTextAlignment(i3);
        S s2 = this.f797F;
        int selectedItemPosition = s2.getSelectedItemPosition();
        C0077t0 c0077t02 = this.f748c;
        if (d2.isShowing() && c0077t02 != null) {
            c0077t02.setListSelectionHidden(false);
            c0077t02.setSelection(selectedItemPosition);
            if (c0077t02.getChoiceMode() != 0) {
                c0077t02.setItemChecked(selectedItemPosition, true);
            }
        }
        if (zIsShowing || (viewTreeObserver = s2.getViewTreeObserver()) == null) {
            return;
        }
        ViewTreeObserverOnGlobalLayoutListenerC0035d viewTreeObserverOnGlobalLayoutListenerC0035d = new ViewTreeObserverOnGlobalLayoutListenerC0035d(3, this);
        viewTreeObserver.addOnGlobalLayoutListener(viewTreeObserverOnGlobalLayoutListenerC0035d);
        this.f769y.setOnDismissListener(new N(this, viewTreeObserverOnGlobalLayoutListenerC0035d));
    }

    @Override // i.Q
    public final void g(CharSequence charSequence) {
        this.f793B = charSequence;
    }

    @Override // i.G0, i.Q
    public final void m(ListAdapter listAdapter) {
        super.m(listAdapter);
        this.f794C = (L) listAdapter;
    }

    @Override // i.Q
    public final void n(int i2) {
        this.f796E = i2;
    }

    public final void q() {
        int i2;
        D d2 = this.f769y;
        Drawable background = d2.getBackground();
        S s2 = this.f797F;
        if (background != null) {
            background.getPadding(s2.f811h);
            boolean z2 = m1.f926a;
            int layoutDirection = s2.getLayoutDirection();
            Rect rect = s2.f811h;
            i2 = layoutDirection == 1 ? rect.right : -rect.left;
        } else {
            Rect rect2 = s2.f811h;
            rect2.right = 0;
            rect2.left = 0;
            i2 = 0;
        }
        int paddingLeft = s2.getPaddingLeft();
        int paddingRight = s2.getPaddingRight();
        int width = s2.getWidth();
        int i3 = s2.f810g;
        if (i3 == -2) {
            int iA = s2.a(this.f794C, d2.getBackground());
            int i4 = s2.getContext().getResources().getDisplayMetrics().widthPixels;
            Rect rect3 = s2.f811h;
            int i5 = (i4 - rect3.left) - rect3.right;
            if (iA > i5) {
                iA = i5;
            }
            p(Math.max(iA, (width - paddingLeft) - paddingRight));
        } else if (i3 == -1) {
            p((width - paddingLeft) - paddingRight);
        } else {
            p(i3);
        }
        boolean z3 = m1.f926a;
        this.f = s2.getLayoutDirection() == 1 ? (((width - paddingRight) - this.f750e) - this.f796E) + i2 : paddingLeft + this.f796E + i2;
    }
}
