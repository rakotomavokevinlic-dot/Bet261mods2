package i;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import h.InterfaceC0031A;
import java.util.ArrayList;

/* JADX INFO: renamed from: i.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0061l implements h.z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f905a;
    public Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public h.n f906c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LayoutInflater f907d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public h.y f908e;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public h.B f910h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public C0059k f911i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Drawable f912j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f913k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f914l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f915m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f916n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f917o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f918p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f919q;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public C0053h f921s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public C0053h f922t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public RunnableC0057j f923u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public C0055i f924v;
    public final int f = 2131427331;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f909g = 2131427330;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final SparseBooleanArray f920r = new SparseBooleanArray();

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final C.j f925w = new C.j(17, this);

    public C0061l(Context context) {
        this.f905a = context;
        this.f907d = LayoutInflater.from(context);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final View a(h.p pVar, View view, ViewGroup viewGroup) {
        View actionView = pVar.getActionView();
        if (actionView == null || pVar.e()) {
            ActionMenuItemView actionMenuItemView = view instanceof InterfaceC0031A ? (InterfaceC0031A) view : (InterfaceC0031A) this.f907d.inflate(this.f909g, viewGroup, false);
            actionMenuItemView.c(pVar);
            ActionMenuItemView actionMenuItemView2 = actionMenuItemView;
            actionMenuItemView2.setItemInvoker(this.f910h);
            if (this.f924v == null) {
                this.f924v = new C0055i(this);
            }
            actionMenuItemView2.setPopupCallback(this.f924v);
            actionView = (View) actionMenuItemView;
        }
        actionView.setVisibility(pVar.f685C ? 8 : 0);
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        ((ActionMenuView) viewGroup).getClass();
        if (!(layoutParams instanceof C0065n)) {
            actionView.setLayoutParams(ActionMenuView.j(layoutParams));
        }
        return actionView;
    }

    @Override // h.z
    public final void b(h.n nVar, boolean z2) {
        f();
        C0053h c0053h = this.f922t;
        if (c0053h != null && c0053h.b()) {
            c0053h.f725i.dismiss();
        }
        h.y yVar = this.f908e;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // h.z
    public final void c() {
        int i2;
        ViewGroup viewGroup = (ViewGroup) this.f910h;
        ArrayList arrayList = null;
        boolean z2 = false;
        if (viewGroup != null) {
            h.n nVar = this.f906c;
            if (nVar != null) {
                nVar.i();
                ArrayList arrayListL = this.f906c.l();
                int size = arrayListL.size();
                i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    h.p pVar = (h.p) arrayListL.get(i3);
                    if ((pVar.f707x & 32) == 32) {
                        View childAt = viewGroup.getChildAt(i2);
                        h.p itemData = childAt instanceof InterfaceC0031A ? ((InterfaceC0031A) childAt).getItemData() : null;
                        View viewA = a(pVar, childAt, viewGroup);
                        if (pVar != itemData) {
                            viewA.setPressed(false);
                            viewA.jumpDrawablesToCurrentState();
                        }
                        if (viewA != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) viewA.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(viewA);
                            }
                            ((ViewGroup) this.f910h).addView(viewA, i2);
                        }
                        i2++;
                    }
                }
            } else {
                i2 = 0;
            }
            while (i2 < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i2) == this.f911i) {
                    i2++;
                } else {
                    viewGroup.removeViewAt(i2);
                }
            }
        }
        ((View) this.f910h).requestLayout();
        h.n nVar2 = this.f906c;
        if (nVar2 != null) {
            nVar2.i();
            ArrayList arrayList2 = nVar2.f665i;
            int size2 = arrayList2.size();
            for (int i4 = 0; i4 < size2; i4++) {
                h.q qVar = ((h.p) arrayList2.get(i4)).f683A;
            }
        }
        h.n nVar3 = this.f906c;
        if (nVar3 != null) {
            nVar3.i();
            arrayList = nVar3.f666j;
        }
        if (this.f914l && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z2 = !((h.p) arrayList.get(0)).f685C;
            } else if (size3 > 0) {
                z2 = true;
            }
        }
        if (z2) {
            if (this.f911i == null) {
                this.f911i = new C0059k(this, this.f905a);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.f911i.getParent();
            if (viewGroup3 != this.f910h) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.f911i);
                }
                ActionMenuView actionMenuView = this.f910h;
                C0059k c0059k = this.f911i;
                actionMenuView.getClass();
                C0065n c0065nI = ActionMenuView.i();
                c0065nI.f928a = true;
                actionMenuView.addView(c0059k, c0065nI);
            }
        } else {
            C0059k c0059k2 = this.f911i;
            if (c0059k2 != null) {
                Object parent = c0059k2.getParent();
                Object obj = this.f910h;
                if (parent == obj) {
                    ((ViewGroup) obj).removeView(this.f911i);
                }
            }
        }
        this.f910h.setOverflowReserved(this.f914l);
    }

    @Override // h.z
    public final boolean d(h.p pVar) {
        return false;
    }

    @Override // h.z
    public final void e(h.y yVar) {
        throw null;
    }

    public final boolean f() {
        Object obj;
        RunnableC0057j runnableC0057j = this.f923u;
        if (runnableC0057j != null && (obj = this.f910h) != null) {
            ((View) obj).removeCallbacks(runnableC0057j);
            this.f923u = null;
            return true;
        }
        C0053h c0053h = this.f921s;
        if (c0053h == null) {
            return false;
        }
        if (c0053h.b()) {
            c0053h.f725i.dismiss();
        }
        return true;
    }

    @Override // h.z
    public final void g(Context context, h.n nVar) {
        this.b = context;
        LayoutInflater.from(context);
        this.f906c = nVar;
        Resources resources = context.getResources();
        if (!this.f915m) {
            this.f914l = true;
        }
        int i2 = 2;
        this.f916n = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i3 = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
            i2 = 5;
        } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
            i2 = 4;
        } else if (i3 >= 360) {
            i2 = 3;
        }
        this.f918p = i2;
        int measuredWidth = this.f916n;
        if (this.f914l) {
            if (this.f911i == null) {
                C0059k c0059k = new C0059k(this, this.f905a);
                this.f911i = c0059k;
                if (this.f913k) {
                    c0059k.setImageDrawable(this.f912j);
                    this.f912j = null;
                    this.f913k = false;
                }
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f911i.measure(iMakeMeasureSpec, iMakeMeasureSpec);
            }
            measuredWidth -= this.f911i.getMeasuredWidth();
        } else {
            this.f911i = null;
        }
        this.f917o = measuredWidth;
        float f = resources.getDisplayMetrics().density;
    }

    public final boolean h() {
        C0053h c0053h = this.f921s;
        return c0053h != null && c0053h.b();
    }

    @Override // h.z
    public final boolean i() {
        int size;
        ArrayList arrayListL;
        int i2;
        boolean z2;
        C0061l c0061l = this;
        h.n nVar = c0061l.f906c;
        if (nVar != null) {
            arrayListL = nVar.l();
            size = arrayListL.size();
        } else {
            size = 0;
            arrayListL = null;
        }
        int i3 = c0061l.f918p;
        int i4 = c0061l.f917o;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) c0061l.f910h;
        int i5 = 0;
        boolean z3 = false;
        int i6 = 0;
        int i7 = 0;
        while (true) {
            i2 = 2;
            z2 = true;
            if (i5 >= size) {
                break;
            }
            h.p pVar = (h.p) arrayListL.get(i5);
            int i8 = pVar.f708y;
            if ((i8 & 2) == 2) {
                i6++;
            } else if ((i8 & 1) == 1) {
                i7++;
            } else {
                z3 = true;
            }
            if (c0061l.f919q && pVar.f685C) {
                i3 = 0;
            }
            i5++;
        }
        if (c0061l.f914l && (z3 || i7 + i6 > i3)) {
            i3--;
        }
        int i9 = i3 - i6;
        SparseBooleanArray sparseBooleanArray = c0061l.f920r;
        sparseBooleanArray.clear();
        int i10 = 0;
        int i11 = 0;
        while (i10 < size) {
            h.p pVar2 = (h.p) arrayListL.get(i10);
            int i12 = pVar2.f708y;
            boolean z4 = (i12 & 2) == i2 ? z2 : false;
            int i13 = pVar2.b;
            if (z4) {
                View viewA = c0061l.a(pVar2, null, viewGroup);
                viewA.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                int measuredWidth = viewA.getMeasuredWidth();
                i4 -= measuredWidth;
                if (i11 == 0) {
                    i11 = measuredWidth;
                }
                if (i13 != 0) {
                    sparseBooleanArray.put(i13, z2);
                }
                pVar2.f(z2);
            } else if ((i12 & 1) == z2) {
                boolean z5 = sparseBooleanArray.get(i13);
                boolean z6 = ((i9 > 0 || z5) && i4 > 0) ? z2 : false;
                if (z6) {
                    View viewA2 = c0061l.a(pVar2, null, viewGroup);
                    viewA2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                    int measuredWidth2 = viewA2.getMeasuredWidth();
                    i4 -= measuredWidth2;
                    if (i11 == 0) {
                        i11 = measuredWidth2;
                    }
                    z6 &= i4 + i11 > 0;
                }
                if (z6 && i13 != 0) {
                    sparseBooleanArray.put(i13, true);
                } else if (z5) {
                    sparseBooleanArray.put(i13, false);
                    for (int i14 = 0; i14 < i10; i14++) {
                        h.p pVar3 = (h.p) arrayListL.get(i14);
                        if (pVar3.b == i13) {
                            if ((pVar3.f707x & 32) == 32) {
                                i9++;
                            }
                            pVar3.f(false);
                        }
                    }
                }
                if (z6) {
                    i9--;
                }
                pVar2.f(z6);
            } else {
                pVar2.f(false);
                i10++;
                i2 = 2;
                c0061l = this;
                z2 = true;
            }
            i10++;
            i2 = 2;
            c0061l = this;
            z2 = true;
        }
        return z2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // h.z
    public final boolean j(h.F f) {
        boolean z2;
        if (f.hasVisibleItems()) {
            h.F f2 = f;
            while (true) {
                h.n nVar = f2.f602z;
                if (nVar == this.f906c) {
                    break;
                }
                f2 = (h.F) nVar;
            }
            ViewGroup viewGroup = (ViewGroup) this.f910h;
            View view = null;
            view = null;
            if (viewGroup != null) {
                int childCount = viewGroup.getChildCount();
                int i2 = 0;
                while (true) {
                    if (i2 >= childCount) {
                        break;
                    }
                    View childAt = viewGroup.getChildAt(i2);
                    if ((childAt instanceof InterfaceC0031A) && ((InterfaceC0031A) childAt).getItemData() == f2.f601A) {
                        view = childAt;
                        break;
                    }
                    i2++;
                }
            }
            if (view != null) {
                f.f601A.getClass();
                int size = f.f.size();
                int i3 = 0;
                while (true) {
                    if (i3 >= size) {
                        z2 = false;
                        break;
                    }
                    MenuItem item = f.getItem(i3);
                    if (item.isVisible() && item.getIcon() != null) {
                        z2 = true;
                        break;
                    }
                    i3++;
                }
                C0053h c0053h = new C0053h(this, this.b, f, view);
                this.f922t = c0053h;
                c0053h.f723g = z2;
                h.v vVar = c0053h.f725i;
                if (vVar != null) {
                    vVar.o(z2);
                }
                C0053h c0053h2 = this.f922t;
                if (!c0053h2.b()) {
                    if (c0053h2.f722e == null) {
                        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
                    }
                    c0053h2.d(0, 0, false, false);
                }
                h.y yVar = this.f908e;
                if (yVar != null) {
                    yVar.m(f);
                }
                return true;
            }
        }
        return false;
    }

    @Override // h.z
    public final boolean k(h.p pVar) {
        return false;
    }

    public final boolean l() {
        h.n nVar;
        if (!this.f914l || h() || (nVar = this.f906c) == null || this.f910h == null || this.f923u != null) {
            return false;
        }
        nVar.i();
        if (nVar.f666j.isEmpty()) {
            return false;
        }
        RunnableC0057j runnableC0057j = new RunnableC0057j(this, new C0053h(this, this.b, this.f906c, this.f911i));
        this.f923u = runnableC0057j;
        ((View) this.f910h).post(runnableC0057j);
        return true;
    }
}
