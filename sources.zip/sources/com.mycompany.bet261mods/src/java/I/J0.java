package i;

import android.widget.PopupWindow;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class J0 {
    public static void a(PopupWindow popupWindow, boolean z2) {
        popupWindow.setTouchModal(z2);
    }
}
