package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import d.AbstractC0002a;
import java.util.WeakHashMap;
import y.AbstractC0142A;

/* JADX INFO: renamed from: i.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0071q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final View f939a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public U0 f941d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public U0 f942e;
    public U0 f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f940c = -1;
    public final C0080v b = C0080v.a();

    public C0071q(View view) {
        this.f939a = view;
    }

    public final void a() {
        View view = this.f939a;
        Drawable background = view.getBackground();
        if (background != null) {
            if (this.f941d != null) {
                if (this.f == null) {
                    this.f = new U0();
                }
                U0 u0 = this.f;
                u0.f821a = null;
                u0.f823d = false;
                u0.b = null;
                u0.f822c = false;
                WeakHashMap weakHashMap = y.K.f1165a;
                ColorStateList colorStateListG = AbstractC0142A.g(view);
                if (colorStateListG != null) {
                    u0.f823d = true;
                    u0.f821a = colorStateListG;
                }
                PorterDuff.Mode modeH = AbstractC0142A.h(view);
                if (modeH != null) {
                    u0.f822c = true;
                    u0.b = modeH;
                }
                if (u0.f823d || u0.f822c) {
                    C0080v.d(background, u0, view.getDrawableState());
                    return;
                }
            }
            U0 u02 = this.f942e;
            if (u02 != null) {
                C0080v.d(background, u02, view.getDrawableState());
                return;
            }
            U0 u03 = this.f941d;
            if (u03 != null) {
                C0080v.d(background, u03, view.getDrawableState());
            }
        }
    }

    public final ColorStateList b() {
        U0 u0 = this.f942e;
        if (u0 != null) {
            return u0.f821a;
        }
        return null;
    }

    public final PorterDuff.Mode c() {
        U0 u0 = this.f942e;
        if (u0 != null) {
            return u0.b;
        }
        return null;
    }

    public final void d(AttributeSet attributeSet, int i2) {
        ColorStateList colorStateListF;
        View view = this.f939a;
        Context context = view.getContext();
        int[] iArr = AbstractC0002a.f340y;
        C.h hVarM = C.h.m(context, attributeSet, iArr, i2);
        TypedArray typedArray = (TypedArray) hVarM.b;
        View view2 = this.f939a;
        y.K.g(view2, view2.getContext(), iArr, attributeSet, (TypedArray) hVarM.b, i2);
        try {
            if (typedArray.hasValue(0)) {
                this.f940c = typedArray.getResourceId(0, -1);
                C0080v c0080v = this.b;
                Context context2 = view.getContext();
                int i3 = this.f940c;
                synchronized (c0080v) {
                    colorStateListF = c0080v.f968a.f(context2, i3);
                }
                if (colorStateListF != null) {
                    g(colorStateListF);
                }
            }
            if (typedArray.hasValue(1)) {
                AbstractC0142A.q(view, hVarM.h(1));
            }
            if (typedArray.hasValue(2)) {
                AbstractC0142A.r(view, AbstractC0066n0.b(typedArray.getInt(2, -1), null));
            }
            hVarM.r();
        } catch (Throwable th) {
            hVarM.r();
            throw th;
        }
    }

    public final void e() {
        this.f940c = -1;
        g(null);
        a();
    }

    public final void f(int i2) {
        ColorStateList colorStateListF;
        this.f940c = i2;
        C0080v c0080v = this.b;
        if (c0080v != null) {
            Context context = this.f939a.getContext();
            synchronized (c0080v) {
                colorStateListF = c0080v.f968a.f(context, i2);
            }
        } else {
            colorStateListF = null;
        }
        g(colorStateListF);
        a();
    }

    public final void g(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f941d == null) {
                this.f941d = new U0();
            }
            U0 u0 = this.f941d;
            u0.f821a = colorStateList;
            u0.f823d = true;
        } else {
            this.f941d = null;
        }
        a();
    }

    public final void h(ColorStateList colorStateList) {
        if (this.f942e == null) {
            this.f942e = new U0();
        }
        U0 u0 = this.f942e;
        u0.f821a = colorStateList;
        u0.f823d = true;
        a();
    }

    public final void i(PorterDuff.Mode mode) {
        if (this.f942e == null) {
            this.f942e = new U0();
        }
        U0 u0 = this.f942e;
        u0.b = mode;
        u0.f822c = true;
        a();
    }
}
