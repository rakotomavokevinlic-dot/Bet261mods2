package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.RadioButton;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class F extends RadioButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final M.e f741a;
    public final C0071q b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Z f742c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C0086y f743d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public F(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130903255);
        T0.a(context);
        S0.a(this, getContext());
        M.e eVar = new M.e(this);
        this.f741a = eVar;
        eVar.d(attributeSet, 2130903255);
        C0071q c0071q = new C0071q(this);
        this.b = c0071q;
        c0071q.d(attributeSet, 2130903255);
        Z z2 = new Z(this);
        this.f742c = z2;
        z2.f(attributeSet, 2130903255);
        getEmojiTextViewHelper().a(attributeSet, 2130903255);
    }

    private C0086y getEmojiTextViewHelper() {
        if (this.f743d == null) {
            this.f743d = new C0086y(this);
        }
        return this.f743d;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0071q c0071q = this.b;
        if (c0071q != null) {
            c0071q.a();
        }
        Z z2 = this.f742c;
        if (z2 != null) {
            z2.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0071q c0071q = this.b;
        if (c0071q != null) {
            return c0071q.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0071q c0071q = this.b;
        if (c0071q != null) {
            return c0071q.c();
        }
        return null;
    }

    public ColorStateList getSupportButtonTintList() {
        M.e eVar = this.f741a;
        if (eVar != null) {
            return (ColorStateList) eVar.f118e;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        M.e eVar = this.f741a;
        if (eVar != null) {
            return (PorterDuff.Mode) eVar.f;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f742c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f742c.e();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0071q c0071q = this.b;
        if (c0071q != null) {
            c0071q.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0071q c0071q = this.b;
        if (c0071q != null) {
            c0071q.f(i2);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        M.e eVar = this.f741a;
        if (eVar != null) {
            if (eVar.f116c) {
                eVar.f116c = false;
            } else {
                eVar.f116c = true;
                eVar.a();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.f742c;
        if (z2 != null) {
            z2.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.f742c;
        if (z2 != null) {
            z2.b();
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((D.g) getEmojiTextViewHelper().b.b).y(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0071q c0071q = this.b;
        if (c0071q != null) {
            c0071q.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0071q c0071q = this.b;
        if (c0071q != null) {
            c0071q.i(mode);
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        M.e eVar = this.f741a;
        if (eVar != null) {
            eVar.f118e = colorStateList;
            eVar.f115a = true;
            eVar.a();
        }
    }

    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        M.e eVar = this.f741a;
        if (eVar != null) {
            eVar.f = mode;
            eVar.b = true;
            eVar.a();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Z z2 = this.f742c;
        z2.l(colorStateList);
        z2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Z z2 = this.f742c;
        z2.m(mode);
        z2.b();
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i2) {
        setButtonDrawable(D.g.w(getContext(), i2));
    }
}
