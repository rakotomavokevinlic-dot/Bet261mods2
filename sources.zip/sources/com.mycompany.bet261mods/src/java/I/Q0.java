package i;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class Q0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}
