package i;

import android.content.Context;
import android.content.ContextWrapper;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class T0 extends ContextWrapper {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Object f817a = null;

    public static void a(Context context) {
        if (context.getResources() instanceof V0) {
            return;
        }
        context.getResources();
        int i2 = j1.f903a;
    }
}
