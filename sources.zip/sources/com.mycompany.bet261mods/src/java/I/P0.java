package i;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class P0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f799a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f800c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f801d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f802e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f803g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f804h;

    public final void a(int i2, int i3) {
        this.f800c = i2;
        this.f801d = i3;
        this.f804h = true;
        if (this.f803g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f799a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f799a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.b = i3;
        }
    }
}
