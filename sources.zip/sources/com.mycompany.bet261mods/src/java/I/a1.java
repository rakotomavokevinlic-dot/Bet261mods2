package i;

import android.view.ViewGroup;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class a1 extends ViewGroup.MarginLayoutParams {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f843a;
    public int b;

    public a1(a1 a1Var) {
        super((ViewGroup.MarginLayoutParams) a1Var);
        this.f843a = 0;
        this.f843a = a1Var.f843a;
    }

    public a1(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f843a = 0;
    }
}
