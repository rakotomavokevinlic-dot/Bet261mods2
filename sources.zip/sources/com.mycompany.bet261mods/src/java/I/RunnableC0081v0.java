package i;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

/* JADX INFO: renamed from: i.v0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class RunnableC0081v0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f969a;
    public final /* synthetic */ AbstractViewOnTouchListenerC0083w0 b;

    public /* synthetic */ RunnableC0081v0(AbstractViewOnTouchListenerC0083w0 abstractViewOnTouchListenerC0083w0, int i2) {
        this.f969a = i2;
        this.b = abstractViewOnTouchListenerC0083w0;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f969a) {
            case 0:
                ViewParent parent = this.b.f973d.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                }
                break;
            default:
                AbstractViewOnTouchListenerC0083w0 abstractViewOnTouchListenerC0083w0 = this.b;
                abstractViewOnTouchListenerC0083w0.a();
                View view = abstractViewOnTouchListenerC0083w0.f973d;
                if (view.isEnabled() && !view.isLongClickable() && abstractViewOnTouchListenerC0083w0.c()) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    long jUptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                    view.onTouchEvent(motionEventObtain);
                    motionEventObtain.recycle();
                    abstractViewOnTouchListenerC0083w0.f975g = true;
                    break;
                }
                break;
        }
    }
}
