package i;

import android.graphics.Typeface;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class Y {
    public static Typeface a(Typeface typeface, int i2, boolean z2) {
        return Typeface.create(typeface, i2, z2);
    }
}
