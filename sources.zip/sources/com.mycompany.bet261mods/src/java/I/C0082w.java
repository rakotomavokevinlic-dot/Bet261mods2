package i;

/* JADX INFO: renamed from: i.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0082w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0084x f970a;

    public C0082w(C0084x c0084x) {
        this.f970a = c0084x;
    }
}
