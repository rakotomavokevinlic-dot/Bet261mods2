package i;

/* JADX INFO: renamed from: i.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0065n extends C0085x0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f928a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f929c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f930d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f931e;
    public boolean f;
}
