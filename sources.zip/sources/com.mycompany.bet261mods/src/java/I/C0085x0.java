package i;

import android.widget.LinearLayout;

/* JADX INFO: renamed from: i.x0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public class C0085x0 extends LinearLayout.LayoutParams {
}
