package i;

/* JADX INFO: renamed from: i.a0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface InterfaceC0040a0 {
    void d(int i2);

    void o(int i2, float f);

    void v(int i2);
}
