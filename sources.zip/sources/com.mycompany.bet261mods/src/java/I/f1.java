package i;

import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class f1 {
    public static void a(View view, CharSequence charSequence) {
        view.setTooltipText(charSequence);
    }
}
