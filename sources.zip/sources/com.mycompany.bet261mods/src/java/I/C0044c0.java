package i;

/* JADX INFO: renamed from: i.c0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0044c0 extends C0042b0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C0046d0 f847d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0044c0(C0046d0 c0046d0) {
        super(c0046d0);
        this.f847d = c0046d0;
    }

    @Override // C.j, i.InterfaceC0040a0
    public final void o(int i2, float f) {
        super/*android.widget.TextView*/.setLineHeight(i2, f);
    }
}
