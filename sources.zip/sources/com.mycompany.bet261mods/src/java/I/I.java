package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import d.AbstractC0002a;
import s.AbstractC0120a;
import s.AbstractC0121b;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class I extends E {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final H f771e;
    public Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f772g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f773h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f774i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f775j;

    public I(H h2) {
        super(h2);
        this.f772g = null;
        this.f773h = null;
        this.f774i = false;
        this.f775j = false;
        this.f771e = h2;
    }

    @Override // i.E
    public final void b(AttributeSet attributeSet, int i2) {
        super.b(attributeSet, 2130903262);
        H h2 = this.f771e;
        Context context = h2.getContext();
        int[] iArr = AbstractC0002a.f322g;
        C.h hVarM = C.h.m(context, attributeSet, iArr, 2130903262);
        y.K.g(h2, h2.getContext(), iArr, attributeSet, (TypedArray) hVarM.b, 2130903262);
        Drawable drawableJ = hVarM.j(0);
        if (drawableJ != null) {
            h2.setThumb(drawableJ);
        }
        Drawable drawableI = hVarM.i(1);
        Drawable drawable = this.f;
        if (drawable != null) {
            drawable.setCallback(null);
        }
        this.f = drawableI;
        if (drawableI != null) {
            drawableI.setCallback(h2);
            AbstractC0121b.b(drawableI, h2.getLayoutDirection());
            if (drawableI.isStateful()) {
                drawableI.setState(h2.getDrawableState());
            }
            f();
        }
        h2.invalidate();
        TypedArray typedArray = (TypedArray) hVarM.b;
        if (typedArray.hasValue(3)) {
            this.f773h = AbstractC0066n0.b(typedArray.getInt(3, -1), this.f773h);
            this.f775j = true;
        }
        if (typedArray.hasValue(2)) {
            this.f772g = hVarM.h(2);
            this.f774i = true;
        }
        hVarM.r();
        f();
    }

    public final void f() {
        Drawable drawable = this.f;
        if (drawable != null) {
            if (this.f774i || this.f775j) {
                Drawable drawableMutate = drawable.mutate();
                this.f = drawableMutate;
                if (this.f774i) {
                    AbstractC0120a.h(drawableMutate, this.f772g);
                }
                if (this.f775j) {
                    AbstractC0120a.i(this.f, this.f773h);
                }
                if (this.f.isStateful()) {
                    this.f.setState(this.f771e.getDrawableState());
                }
            }
        }
    }

    public final void g(Canvas canvas) {
        if (this.f != null) {
            int max = this.f771e.getMax();
            if (max > 1) {
                int intrinsicWidth = this.f.getIntrinsicWidth();
                int intrinsicHeight = this.f.getIntrinsicHeight();
                int i2 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                int i3 = intrinsicHeight >= 0 ? intrinsicHeight / 2 : 1;
                this.f.setBounds(-i2, -i3, i2, i3);
                float width = ((r0.getWidth() - r0.getPaddingLeft()) - r0.getPaddingRight()) / max;
                int iSave = canvas.save();
                canvas.translate(r0.getPaddingLeft(), r0.getHeight() / 2);
                for (int i4 = 0; i4 <= max; i4++) {
                    this.f.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(iSave);
            }
        }
    }
}
