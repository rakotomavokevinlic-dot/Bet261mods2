package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import d.AbstractC0002a;
import java.lang.ref.WeakReference;
import java.util.Arrays;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class Z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextView f828a;
    public U0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public U0 f829c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public U0 f830d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public U0 f831e;
    public U0 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public U0 f832g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public U0 f833h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final C0056i0 f834i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f835j = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f836k = -1;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Typeface f837l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f838m;

    public Z(TextView textView) {
        this.f828a = textView;
        this.f834i = new C0056i0(textView);
    }

    public static U0 c(Context context, C0080v c0080v, int i2) {
        ColorStateList colorStateListF;
        synchronized (c0080v) {
            colorStateListF = c0080v.f968a.f(context, i2);
        }
        if (colorStateListF == null) {
            return null;
        }
        U0 u0 = new U0();
        u0.f823d = true;
        u0.f821a = colorStateListF;
        return u0;
    }

    public static void h(EditorInfo editorInfo, InputConnection inputConnection, TextView textView) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 30 || inputConnection == null) {
            return;
        }
        CharSequence text = textView.getText();
        if (i2 >= 30) {
            C.b.a(editorInfo, text);
            return;
        }
        text.getClass();
        if (i2 >= 30) {
            C.b.a(editorInfo, text);
            return;
        }
        int i3 = editorInfo.initialSelStart;
        int i4 = editorInfo.initialSelEnd;
        int i5 = i3 > i4 ? i4 : i3;
        if (i3 <= i4) {
            i3 = i4;
        }
        int length = text.length();
        if (i5 < 0 || i3 > length) {
            C.c.a(editorInfo, null, 0, 0);
            return;
        }
        int i6 = editorInfo.inputType & 4095;
        if (i6 == 129 || i6 == 225 || i6 == 18) {
            C.c.a(editorInfo, null, 0, 0);
            return;
        }
        if (length <= 2048) {
            C.c.a(editorInfo, text, i5, i3);
            return;
        }
        int i7 = i3 - i5;
        int i8 = i7 > 1024 ? 0 : i7;
        int i9 = 2048 - i8;
        int iMin = Math.min(text.length() - i3, i9 - Math.min(i5, (int) (((double) i9) * 0.8d)));
        int iMin2 = Math.min(i5, i9 - iMin);
        int i10 = i5 - iMin2;
        if (Character.isLowSurrogate(text.charAt(i10))) {
            i10++;
            iMin2--;
        }
        if (Character.isHighSurrogate(text.charAt((i3 + iMin) - 1))) {
            iMin--;
        }
        int i11 = iMin2 + i8;
        C.c.a(editorInfo, i8 != i7 ? TextUtils.concat(text.subSequence(i10, i10 + iMin2), text.subSequence(i3, iMin + i3)) : text.subSequence(i10, i11 + iMin + i10), iMin2, i11);
    }

    public final void a(Drawable drawable, U0 u0) {
        if (drawable == null || u0 == null) {
            return;
        }
        C0080v.d(drawable, u0, this.f828a.getDrawableState());
    }

    public final void b() {
        U0 u0 = this.b;
        TextView textView = this.f828a;
        if (u0 != null || this.f829c != null || this.f830d != null || this.f831e != null) {
            Drawable[] compoundDrawables = textView.getCompoundDrawables();
            a(compoundDrawables[0], this.b);
            a(compoundDrawables[1], this.f829c);
            a(compoundDrawables[2], this.f830d);
            a(compoundDrawables[3], this.f831e);
        }
        if (this.f == null && this.f832g == null) {
            return;
        }
        Drawable[] compoundDrawablesRelative = textView.getCompoundDrawablesRelative();
        a(compoundDrawablesRelative[0], this.f);
        a(compoundDrawablesRelative[2], this.f832g);
    }

    public final ColorStateList d() {
        U0 u0 = this.f833h;
        if (u0 != null) {
            return u0.f821a;
        }
        return null;
    }

    public final PorterDuff.Mode e() {
        U0 u0 = this.f833h;
        if (u0 != null) {
            return u0.b;
        }
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:227:0x03a0  */
    /* JADX WARN: Removed duplicated region for block: B:229:0x03a5  */
    /* JADX WARN: Removed duplicated region for block: B:232:0x03ac  */
    /* JADX WARN: Removed duplicated region for block: B:242:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void f(android.util.AttributeSet r24, int r25) {
        /*
            Method dump skipped, instruction units count: 977
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: i.Z.f(android.util.AttributeSet, int):void");
    }

    public final void g(Context context, int i2) {
        String string;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i2, AbstractC0002a.f337v);
        C.h hVar = new C.h(context, typedArrayObtainStyledAttributes);
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(14);
        TextView textView = this.f828a;
        if (zHasValue) {
            textView.setAllCaps(typedArrayObtainStyledAttributes.getBoolean(14, false));
        }
        int i3 = Build.VERSION.SDK_INT;
        if (typedArrayObtainStyledAttributes.hasValue(0) && typedArrayObtainStyledAttributes.getDimensionPixelSize(0, -1) == 0) {
            textView.setTextSize(0, 0.0f);
        }
        n(context, hVar);
        if (i3 >= 26 && typedArrayObtainStyledAttributes.hasValue(13) && (string = typedArrayObtainStyledAttributes.getString(13)) != null) {
            X.d(textView, string);
        }
        hVar.r();
        Typeface typeface = this.f837l;
        if (typeface != null) {
            textView.setTypeface(typeface, this.f835j);
        }
    }

    public final void i(int i2, int i3, int i4, int i5) {
        C0056i0 c0056i0 = this.f834i;
        if (c0056i0.j()) {
            DisplayMetrics displayMetrics = c0056i0.f893j.getResources().getDisplayMetrics();
            c0056i0.k(TypedValue.applyDimension(i5, i2, displayMetrics), TypedValue.applyDimension(i5, i3, displayMetrics), TypedValue.applyDimension(i5, i4, displayMetrics));
            if (c0056i0.h()) {
                c0056i0.a();
            }
        }
    }

    public final void j(int[] iArr, int i2) {
        C0056i0 c0056i0 = this.f834i;
        if (c0056i0.j()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArrCopyOf = new int[length];
                if (i2 == 0) {
                    iArrCopyOf = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = c0056i0.f893j.getResources().getDisplayMetrics();
                    for (int i3 = 0; i3 < length; i3++) {
                        iArrCopyOf[i3] = Math.round(TypedValue.applyDimension(i2, iArr[i3], displayMetrics));
                    }
                }
                c0056i0.f = C0056i0.b(iArrCopyOf);
                if (!c0056i0.i()) {
                    throw new IllegalArgumentException("None of the preset sizes is valid: " + Arrays.toString(iArr));
                }
            } else {
                c0056i0.f890g = false;
            }
            if (c0056i0.h()) {
                c0056i0.a();
            }
        }
    }

    public final void k(int i2) {
        C0056i0 c0056i0 = this.f834i;
        if (c0056i0.j()) {
            if (i2 == 0) {
                c0056i0.f886a = 0;
                c0056i0.f888d = -1.0f;
                c0056i0.f889e = -1.0f;
                c0056i0.f887c = -1.0f;
                c0056i0.f = new int[0];
                c0056i0.b = false;
                return;
            }
            if (i2 != 1) {
                throw new IllegalArgumentException("Unknown auto-size text type: " + i2);
            }
            DisplayMetrics displayMetrics = c0056i0.f893j.getResources().getDisplayMetrics();
            c0056i0.k(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (c0056i0.h()) {
                c0056i0.a();
            }
        }
    }

    public final void l(ColorStateList colorStateList) {
        if (this.f833h == null) {
            this.f833h = new U0();
        }
        U0 u0 = this.f833h;
        u0.f821a = colorStateList;
        u0.f823d = colorStateList != null;
        this.b = u0;
        this.f829c = u0;
        this.f830d = u0;
        this.f831e = u0;
        this.f = u0;
        this.f832g = u0;
    }

    public final void m(PorterDuff.Mode mode) {
        if (this.f833h == null) {
            this.f833h = new U0();
        }
        U0 u0 = this.f833h;
        u0.b = mode;
        u0.f822c = mode != null;
        this.b = u0;
        this.f829c = u0;
        this.f830d = u0;
        this.f831e = u0;
        this.f = u0;
        this.f832g = u0;
    }

    public final void n(Context context, C.h hVar) {
        String string;
        int i2 = this.f835j;
        TypedArray typedArray = (TypedArray) hVar.b;
        this.f835j = typedArray.getInt(2, i2);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 28) {
            int i4 = typedArray.getInt(11, -1);
            this.f836k = i4;
            if (i4 != -1) {
                this.f835j &= 2;
            }
        }
        if (!typedArray.hasValue(10) && !typedArray.hasValue(12)) {
            if (typedArray.hasValue(1)) {
                this.f838m = false;
                int i5 = typedArray.getInt(1, 1);
                if (i5 == 1) {
                    this.f837l = Typeface.SANS_SERIF;
                    return;
                } else if (i5 == 2) {
                    this.f837l = Typeface.SERIF;
                    return;
                } else {
                    if (i5 != 3) {
                        return;
                    }
                    this.f837l = Typeface.MONOSPACE;
                    return;
                }
            }
            return;
        }
        this.f837l = null;
        int i6 = typedArray.hasValue(12) ? 12 : 10;
        int i7 = this.f836k;
        int i8 = this.f835j;
        if (!context.isRestricted()) {
            try {
                Typeface typefaceK = hVar.k(i6, this.f835j, new U(this, i7, i8, new WeakReference(this.f828a)));
                if (typefaceK != null) {
                    if (i3 < 28 || this.f836k == -1) {
                        this.f837l = typefaceK;
                    } else {
                        this.f837l = Y.a(Typeface.create(typefaceK, 0), this.f836k, (this.f835j & 2) != 0);
                    }
                }
                this.f838m = this.f837l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.f837l != null || (string = typedArray.getString(i6)) == null) {
            return;
        }
        if (Build.VERSION.SDK_INT < 28 || this.f836k == -1) {
            this.f837l = Typeface.create(string, this.f835j);
        } else {
            this.f837l = Y.a(Typeface.create(string, 0), this.f836k, (this.f835j & 2) != 0);
        }
    }
}
