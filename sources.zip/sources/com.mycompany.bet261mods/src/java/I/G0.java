package i;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import d.AbstractC0002a;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class G0 implements h.D {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public static final Method f745A;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final Method f746z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f747a;
    public ListAdapter b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C0077t0 f748c;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f751g;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f753i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f754j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f755k;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public D0 f758n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public View f759o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public AdapterView.OnItemClickListener f760p;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Handler f765u;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Rect f767w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f768x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final D f769y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f749d = -2;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f750e = -2;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f752h = 1002;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f756l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f757m = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final C0 f761q = new C0(this, 1);

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final F0 f762r = new F0(this);

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final E0 f763s = new E0(this);

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final C0 f764t = new C0(this, 0);

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Rect f766v = new Rect();

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                f746z = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                f745A = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
    }

    public G0(Context context, AttributeSet attributeSet, int i2) {
        int resourceId;
        this.f747a = context;
        this.f765u = new Handler(context.getMainLooper());
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0002a.f330o, i2, 0);
        this.f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f751g = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f753i = true;
        }
        typedArrayObtainStyledAttributes.recycle();
        D d2 = new D(context, attributeSet, i2, 0);
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, AbstractC0002a.f334s, i2, 0);
        if (typedArrayObtainStyledAttributes2.hasValue(2)) {
            D.o.c(d2, typedArrayObtainStyledAttributes2.getBoolean(2, false));
        }
        d2.setBackgroundDrawable((!typedArrayObtainStyledAttributes2.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes2.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes2.getDrawable(0) : D.g.w(context, resourceId));
        typedArrayObtainStyledAttributes2.recycle();
        this.f769y = d2;
        d2.setInputMethodMode(1);
    }

    @Override // h.D
    public final boolean a() {
        return this.f769y.isShowing();
    }

    public final void c(int i2) {
        this.f = i2;
    }

    public final int d() {
        return this.f;
    }

    @Override // h.D
    public final void dismiss() {
        D d2 = this.f769y;
        d2.dismiss();
        d2.setContentView(null);
        this.f748c = null;
        this.f765u.removeCallbacks(this.f761q);
    }

    @Override // h.D
    public final C0077t0 f() {
        return this.f748c;
    }

    @Override // h.D
    public final void h() {
        int i2;
        int paddingBottom;
        C0077t0 c0077t0;
        C0077t0 c0077t02 = this.f748c;
        D d2 = this.f769y;
        Context context = this.f747a;
        if (c0077t02 == null) {
            C0077t0 c0077t0O = o(context, !this.f768x);
            this.f748c = c0077t0O;
            c0077t0O.setAdapter(this.b);
            this.f748c.setOnItemClickListener(this.f760p);
            this.f748c.setFocusable(true);
            this.f748c.setFocusableInTouchMode(true);
            this.f748c.setOnItemSelectedListener(new C0089z0(this));
            this.f748c.setOnScrollListener(this.f763s);
            d2.setContentView(this.f748c);
        }
        Drawable background = d2.getBackground();
        Rect rect = this.f766v;
        if (background != null) {
            background.getPadding(rect);
            int i3 = rect.top;
            i2 = rect.bottom + i3;
            if (!this.f753i) {
                this.f751g = -i3;
            }
        } else {
            rect.setEmpty();
            i2 = 0;
        }
        int iA = A0.a(d2, this.f759o, this.f751g, d2.getInputMethodMode() == 2);
        int i4 = this.f749d;
        if (i4 == -1) {
            paddingBottom = iA + i2;
        } else {
            int i5 = this.f750e;
            int iA2 = this.f748c.a(i5 != -2 ? i5 != -1 ? View.MeasureSpec.makeMeasureSpec(i5, 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE), iA);
            paddingBottom = iA2 + (iA2 > 0 ? this.f748c.getPaddingBottom() + this.f748c.getPaddingTop() + i2 : 0);
        }
        boolean z2 = this.f769y.getInputMethodMode() == 2;
        D.o.d(d2, this.f752h);
        if (d2.isShowing()) {
            if (this.f759o.isAttachedToWindow()) {
                int width = this.f750e;
                if (width == -1) {
                    width = -1;
                } else if (width == -2) {
                    width = this.f759o.getWidth();
                }
                if (i4 == -1) {
                    i4 = z2 ? paddingBottom : -1;
                    if (z2) {
                        d2.setWidth(this.f750e == -1 ? -1 : 0);
                        d2.setHeight(0);
                    } else {
                        d2.setWidth(this.f750e == -1 ? -1 : 0);
                        d2.setHeight(-1);
                    }
                } else if (i4 == -2) {
                    i4 = paddingBottom;
                }
                d2.setOutsideTouchable(true);
                View view = this.f759o;
                int i6 = this.f;
                int i7 = this.f751g;
                if (width < 0) {
                    width = -1;
                }
                d2.update(view, i6, i7, width, i4 < 0 ? -1 : i4);
                return;
            }
            return;
        }
        int width2 = this.f750e;
        if (width2 == -1) {
            width2 = -1;
        } else if (width2 == -2) {
            width2 = this.f759o.getWidth();
        }
        if (i4 == -1) {
            i4 = -1;
        } else if (i4 == -2) {
            i4 = paddingBottom;
        }
        d2.setWidth(width2);
        d2.setHeight(i4);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = f746z;
            if (method != null) {
                try {
                    method.invoke(d2, Boolean.TRUE);
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            B0.b(d2, true);
        }
        d2.setOutsideTouchable(true);
        d2.setTouchInterceptor(this.f762r);
        if (this.f755k) {
            D.o.c(d2, this.f754j);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = f745A;
            if (method2 != null) {
                try {
                    method2.invoke(d2, this.f767w);
                } catch (Exception e2) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                }
            }
        } else {
            B0.a(d2, this.f767w);
        }
        d2.showAsDropDown(this.f759o, this.f, this.f751g, this.f756l);
        this.f748c.setSelection(-1);
        if ((!this.f768x || this.f748c.isInTouchMode()) && (c0077t0 = this.f748c) != null) {
            c0077t0.setListSelectionHidden(true);
            c0077t0.requestLayout();
        }
        if (this.f768x) {
            return;
        }
        this.f765u.post(this.f764t);
    }

    public final int i() {
        if (this.f753i) {
            return this.f751g;
        }
        return 0;
    }

    public final void j(Drawable drawable) {
        this.f769y.setBackgroundDrawable(drawable);
    }

    public final void k(int i2) {
        this.f751g = i2;
        this.f753i = true;
    }

    public final Drawable l() {
        return this.f769y.getBackground();
    }

    public void m(ListAdapter listAdapter) {
        D0 d02 = this.f758n;
        if (d02 == null) {
            this.f758n = new D0(this);
        } else {
            ListAdapter listAdapter2 = this.b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(d02);
            }
        }
        this.b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f758n);
        }
        C0077t0 c0077t0 = this.f748c;
        if (c0077t0 != null) {
            c0077t0.setAdapter(this.b);
        }
    }

    public C0077t0 o(Context context, boolean z2) {
        return new C0077t0(context, z2);
    }

    public final void p(int i2) {
        Drawable background = this.f769y.getBackground();
        if (background == null) {
            this.f750e = i2;
            return;
        }
        Rect rect = this.f766v;
        background.getPadding(rect);
        this.f750e = rect.left + rect.right + i2;
    }
}
