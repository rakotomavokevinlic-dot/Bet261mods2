package i;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class U0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ColorStateList f821a;
    public PorterDuff.Mode b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f822c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f823d;
}
