package i;

import android.content.Context;
import android.view.View;

/* JADX INFO: renamed from: i.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0053h extends h.x {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f871l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C0061l f872m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0053h(C0061l c0061l, Context context, h.n nVar, View view) {
        super(2130903072, context, view, nVar, true);
        this.f872m = c0061l;
        this.f = 8388613;
        C.j jVar = c0061l.f925w;
        this.f724h = jVar;
        h.v vVar = this.f725i;
        if (vVar != null) {
            vVar.e(jVar);
        }
    }

    @Override // h.x
    public final void c() {
        switch (this.f871l) {
            case 0:
                C0061l c0061l = this.f872m;
                c0061l.f922t = null;
                c0061l.getClass();
                super.c();
                break;
            default:
                C0061l c0061l2 = this.f872m;
                h.n nVar = c0061l2.f906c;
                if (nVar != null) {
                    nVar.c(true);
                }
                c0061l2.f921s = null;
                super.c();
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0053h(C0061l c0061l, Context context, h.F f, View view) {
        super(2130903072, context, view, f, false);
        this.f872m = c0061l;
        if ((f.f601A.f707x & 32) != 32) {
            View view2 = c0061l.f911i;
            this.f722e = view2 == null ? (View) c0061l.f910h : view2;
        }
        C.j jVar = c0061l.f925w;
        this.f724h = jVar;
        h.v vVar = this.f725i;
        if (vVar != null) {
            vVar.e(jVar);
        }
    }
}
