package i;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import d.AbstractC0002a;

/* JADX INFO: renamed from: i.y0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class AbstractC0087y0 extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f983a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f984c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f985d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f986e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public float f987g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f988h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int[] f989i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int[] f990j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Drawable f991k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f992l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f993m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f994n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f995o;

    public AbstractC0087y0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f983a = true;
        this.b = -1;
        this.f984c = 0;
        this.f986e = 8388659;
        int[] iArr = AbstractC0002a.f329n;
        C.h hVarM = C.h.m(context, attributeSet, iArr, 0);
        y.K.g(this, context, iArr, attributeSet, (TypedArray) hVarM.b, 0);
        TypedArray typedArray = (TypedArray) hVarM.b;
        int i2 = typedArray.getInt(1, -1);
        if (i2 >= 0) {
            setOrientation(i2);
        }
        int i3 = typedArray.getInt(0, -1);
        if (i3 >= 0) {
            setGravity(i3);
        }
        boolean z2 = typedArray.getBoolean(2, true);
        if (!z2) {
            setBaselineAligned(z2);
        }
        this.f987g = typedArray.getFloat(4, -1.0f);
        this.b = typedArray.getInt(3, -1);
        this.f988h = typedArray.getBoolean(7, false);
        setDividerDrawable(hVarM.i(5));
        this.f994n = typedArray.getInt(8, 0);
        this.f995o = typedArray.getDimensionPixelSize(6, 0);
        hVarM.r();
    }

    public final void c(Canvas canvas, int i2) {
        this.f991k.setBounds(getPaddingLeft() + this.f995o, i2, (getWidth() - getPaddingRight()) - this.f995o, this.f993m + i2);
        this.f991k.draw(canvas);
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0085x0;
    }

    public final void d(Canvas canvas, int i2) {
        this.f991k.setBounds(i2, getPaddingTop() + this.f995o, this.f992l + i2, (getHeight() - getPaddingBottom()) - this.f995o);
        this.f991k.draw(canvas);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public C0085x0 generateDefaultLayoutParams() {
        int i2 = this.f985d;
        if (i2 == 0) {
            return new C0085x0(-2, -2);
        }
        if (i2 == 1) {
            return new C0085x0(-1, -2);
        }
        return null;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
    public C0085x0 generateLayoutParams(AttributeSet attributeSet) {
        return new C0085x0(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: g, reason: merged with bridge method [inline-methods] */
    public C0085x0 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0085x0 ? new C0085x0((C0085x0) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0085x0((ViewGroup.MarginLayoutParams) layoutParams) : new C0085x0(layoutParams);
    }

    @Override // android.view.View
    public int getBaseline() {
        int i2;
        if (this.b < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i3 = this.b;
        if (childCount <= i3) {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
        View childAt = getChildAt(i3);
        int baseline = childAt.getBaseline();
        if (baseline == -1) {
            if (this.b == 0) {
                return -1;
            }
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
        }
        int bottom = this.f984c;
        if (this.f985d == 1 && (i2 = this.f986e & 112) != 48) {
            if (i2 == 16) {
                bottom += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f) / 2;
            } else if (i2 == 80) {
                bottom = ((getBottom() - getTop()) - getPaddingBottom()) - this.f;
            }
        }
        return bottom + ((LinearLayout.LayoutParams) ((C0085x0) childAt.getLayoutParams())).topMargin + baseline;
    }

    public int getBaselineAlignedChildIndex() {
        return this.b;
    }

    public Drawable getDividerDrawable() {
        return this.f991k;
    }

    public int getDividerPadding() {
        return this.f995o;
    }

    public int getDividerWidth() {
        return this.f992l;
    }

    public int getGravity() {
        return this.f986e;
    }

    public int getOrientation() {
        return this.f985d;
    }

    public int getShowDividers() {
        return this.f994n;
    }

    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f987g;
    }

    public final boolean h(int i2) {
        if (i2 == 0) {
            return (this.f994n & 1) != 0;
        }
        if (i2 == getChildCount()) {
            return (this.f994n & 4) != 0;
        }
        if ((this.f994n & 2) != 0) {
            for (int i3 = i2 - 1; i3 >= 0; i3--) {
                if (getChildAt(i3).getVisibility() != 8) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        int right;
        int left;
        int i2;
        if (this.f991k == null) {
            return;
        }
        int i3 = 0;
        if (this.f985d == 1) {
            int virtualChildCount = getVirtualChildCount();
            while (i3 < virtualChildCount) {
                View childAt = getChildAt(i3);
                if (childAt != null && childAt.getVisibility() != 8 && h(i3)) {
                    c(canvas, (childAt.getTop() - ((LinearLayout.LayoutParams) ((C0085x0) childAt.getLayoutParams())).topMargin) - this.f993m);
                }
                i3++;
            }
            if (h(virtualChildCount)) {
                View childAt2 = getChildAt(virtualChildCount - 1);
                c(canvas, childAt2 == null ? (getHeight() - getPaddingBottom()) - this.f993m : childAt2.getBottom() + ((LinearLayout.LayoutParams) ((C0085x0) childAt2.getLayoutParams())).bottomMargin);
                return;
            }
            return;
        }
        int virtualChildCount2 = getVirtualChildCount();
        boolean z2 = m1.f926a;
        boolean z3 = getLayoutDirection() == 1;
        while (i3 < virtualChildCount2) {
            View childAt3 = getChildAt(i3);
            if (childAt3 != null && childAt3.getVisibility() != 8 && h(i3)) {
                C0085x0 c0085x0 = (C0085x0) childAt3.getLayoutParams();
                d(canvas, z3 ? childAt3.getRight() + ((LinearLayout.LayoutParams) c0085x0).rightMargin : (childAt3.getLeft() - ((LinearLayout.LayoutParams) c0085x0).leftMargin) - this.f992l);
            }
            i3++;
        }
        if (h(virtualChildCount2)) {
            View childAt4 = getChildAt(virtualChildCount2 - 1);
            if (childAt4 != null) {
                C0085x0 c0085x02 = (C0085x0) childAt4.getLayoutParams();
                if (z3) {
                    left = childAt4.getLeft() - ((LinearLayout.LayoutParams) c0085x02).leftMargin;
                    i2 = this.f992l;
                    right = left - i2;
                } else {
                    right = childAt4.getRight() + ((LinearLayout.LayoutParams) c0085x02).rightMargin;
                }
            } else if (z3) {
                right = getPaddingLeft();
            } else {
                left = getWidth() - getPaddingRight();
                i2 = this.f992l;
                right = left - i2;
            }
            d(canvas, right);
        }
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0159  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0162  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x0190  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x01a3  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01a8  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onLayout(boolean r23, int r24, int r25, int r26, int r27) {
        /*
            Method dump skipped, instruction units count: 460
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: i.AbstractC0087y0.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:228:0x04e4  */
    /* JADX WARN: Removed duplicated region for block: B:231:0x04f9  */
    /* JADX WARN: Removed duplicated region for block: B:237:0x0527  */
    /* JADX WARN: Removed duplicated region for block: B:243:0x0537  */
    /* JADX WARN: Removed duplicated region for block: B:246:0x053e  */
    /* JADX WARN: Removed duplicated region for block: B:250:0x0548  */
    /* JADX WARN: Removed duplicated region for block: B:366:0x079d  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x013f  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x0148  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onMeasure(int r39, int r40) {
        /*
            Method dump skipped, instruction units count: 2151
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: i.AbstractC0087y0.onMeasure(int, int):void");
    }

    public void setBaselineAligned(boolean z2) {
        this.f983a = z2;
    }

    public void setBaselineAlignedChildIndex(int i2) {
        if (i2 >= 0 && i2 < getChildCount()) {
            this.b = i2;
            return;
        }
        throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable == this.f991k) {
            return;
        }
        this.f991k = drawable;
        if (drawable != null) {
            this.f992l = drawable.getIntrinsicWidth();
            this.f993m = drawable.getIntrinsicHeight();
        } else {
            this.f992l = 0;
            this.f993m = 0;
        }
        setWillNotDraw(drawable == null);
        requestLayout();
    }

    public void setDividerPadding(int i2) {
        this.f995o = i2;
    }

    public void setGravity(int i2) {
        if (this.f986e != i2) {
            if ((8388615 & i2) == 0) {
                i2 |= 8388611;
            }
            if ((i2 & 112) == 0) {
                i2 |= 48;
            }
            this.f986e = i2;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i2) {
        int i3 = i2 & 8388615;
        int i4 = this.f986e;
        if ((8388615 & i4) != i3) {
            this.f986e = i3 | ((-8388616) & i4);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z2) {
        this.f988h = z2;
    }

    public void setOrientation(int i2) {
        if (this.f985d != i2) {
            this.f985d = i2;
            requestLayout();
        }
    }

    public void setShowDividers(int i2) {
        if (i2 != this.f994n) {
            requestLayout();
        }
        this.f994n = i2;
    }

    public void setVerticalGravity(int i2) {
        int i3 = i2 & 112;
        int i4 = this.f986e;
        if ((i4 & 112) != i3) {
            this.f986e = i3 | (i4 & (-113));
            requestLayout();
        }
    }

    public void setWeightSum(float f) {
        this.f987g = Math.max(0.0f, f);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
