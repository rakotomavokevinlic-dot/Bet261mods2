package i;

import android.view.ViewTreeObserver;
import android.widget.PopupWindow;
import h.ViewTreeObserverOnGlobalLayoutListenerC0035d;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class N implements PopupWindow.OnDismissListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ ViewTreeObserverOnGlobalLayoutListenerC0035d f786a;
    public final /* synthetic */ O b;

    public N(O o2, ViewTreeObserverOnGlobalLayoutListenerC0035d viewTreeObserverOnGlobalLayoutListenerC0035d) {
        this.b = o2;
        this.f786a = viewTreeObserverOnGlobalLayoutListenerC0035d;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public final void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.b.f797F.getViewTreeObserver();
        if (viewTreeObserver != null) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f786a);
        }
    }
}
