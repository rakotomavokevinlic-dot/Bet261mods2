package i;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;
import d.AbstractC0002a;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class e1 implements InterfaceC0064m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Toolbar f857a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final View f858c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Drawable f859d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Drawable f860e;
    public final Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f861g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public CharSequence f862h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final CharSequence f863i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final CharSequence f864j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Window.Callback f865k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f866l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public C0061l f867m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f868n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Drawable f869o;

    public e1(Toolbar toolbar, boolean z2) {
        Drawable drawable;
        this.f868n = 0;
        this.f857a = toolbar;
        this.f862h = toolbar.getTitle();
        this.f863i = toolbar.getSubtitle();
        this.f861g = this.f862h != null;
        this.f = toolbar.getNavigationIcon();
        C.h hVarM = C.h.m(toolbar.getContext(), null, AbstractC0002a.f318a, 2130903045);
        int i2 = 15;
        this.f869o = hVarM.i(15);
        if (z2) {
            TypedArray typedArray = (TypedArray) hVarM.b;
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                this.f861g = true;
                this.f862h = text;
                if ((this.b & 8) != 0) {
                    Toolbar toolbar2 = this.f857a;
                    toolbar2.setTitle(text);
                    if (this.f861g) {
                        y.K.i(toolbar2.getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                this.f863i = text2;
                if ((this.b & 8) != 0) {
                    toolbar.setSubtitle(text2);
                }
            }
            Drawable drawableI = hVarM.i(20);
            if (drawableI != null) {
                this.f860e = drawableI;
                c();
            }
            Drawable drawableI2 = hVarM.i(17);
            if (drawableI2 != null) {
                this.f859d = drawableI2;
                c();
            }
            if (this.f == null && (drawable = this.f869o) != null) {
                this.f = drawable;
                int i3 = this.b & 4;
                Toolbar toolbar3 = this.f857a;
                if (i3 != 0) {
                    toolbar3.setNavigationIcon(drawable);
                } else {
                    toolbar3.setNavigationIcon((Drawable) null);
                }
            }
            a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View viewInflate = LayoutInflater.from(toolbar.getContext()).inflate(resourceId, (ViewGroup) toolbar, false);
                View view = this.f858c;
                if (view != null && (this.b & 16) != 0) {
                    toolbar.removeView(view);
                }
                this.f858c = viewInflate;
                if (viewInflate != null && (this.b & 16) != 0) {
                    toolbar.addView(viewInflate);
                }
                a(this.b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = toolbar.getLayoutParams();
                layoutParams.height = layoutDimension;
                toolbar.setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int iMax = Math.max(dimensionPixelOffset, 0);
                int iMax2 = Math.max(dimensionPixelOffset2, 0);
                toolbar.d();
                toolbar.t.a(iMax, iMax2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = toolbar.getContext();
                toolbar.l = resourceId2;
                C0046d0 c0046d0 = toolbar.b;
                if (c0046d0 != null) {
                    c0046d0.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = toolbar.getContext();
                toolbar.m = resourceId3;
                C0046d0 c0046d02 = toolbar.c;
                if (c0046d02 != null) {
                    c0046d02.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                toolbar.setPopupTheme(resourceId4);
            }
        } else {
            if (toolbar.getNavigationIcon() != null) {
                this.f869o = toolbar.getNavigationIcon();
            } else {
                i2 = 11;
            }
            this.b = i2;
        }
        hVarM.r();
        if (2131623937 != this.f868n) {
            this.f868n = 2131623937;
            if (TextUtils.isEmpty(toolbar.getNavigationContentDescription())) {
                int i4 = this.f868n;
                this.f864j = i4 != 0 ? toolbar.getContext().getString(i4) : null;
                b();
            }
        }
        this.f864j = toolbar.getNavigationContentDescription();
        toolbar.setNavigationOnClickListener(new d1(this));
    }

    public final void a(int i2) {
        View view;
        int i3 = this.b ^ i2;
        this.b = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    b();
                }
                int i4 = this.b & 4;
                Toolbar toolbar = this.f857a;
                if (i4 != 0) {
                    Drawable drawable = this.f;
                    if (drawable == null) {
                        drawable = this.f869o;
                    }
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            if ((i3 & 3) != 0) {
                c();
            }
            int i5 = i3 & 8;
            Toolbar toolbar2 = this.f857a;
            if (i5 != 0) {
                if ((i2 & 8) != 0) {
                    toolbar2.setTitle(this.f862h);
                    toolbar2.setSubtitle(this.f863i);
                } else {
                    toolbar2.setTitle((CharSequence) null);
                    toolbar2.setSubtitle((CharSequence) null);
                }
            }
            if ((i3 & 16) == 0 || (view = this.f858c) == null) {
                return;
            }
            if ((i2 & 16) != 0) {
                toolbar2.addView(view);
            } else {
                toolbar2.removeView(view);
            }
        }
    }

    public final void b() {
        if ((this.b & 4) != 0) {
            boolean zIsEmpty = TextUtils.isEmpty(this.f864j);
            Toolbar toolbar = this.f857a;
            if (zIsEmpty) {
                toolbar.setNavigationContentDescription(this.f868n);
            } else {
                toolbar.setNavigationContentDescription(this.f864j);
            }
        }
    }

    public final void c() {
        Drawable drawable;
        int i2 = this.b;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) == 0 || (drawable = this.f860e) == null) {
            drawable = this.f859d;
        }
        this.f857a.setLogo(drawable);
    }
}
