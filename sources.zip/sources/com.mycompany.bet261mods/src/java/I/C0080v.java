package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.Log;

/* JADX INFO: renamed from: i.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0080v {
    public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static C0080v f967c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public N0 f968a;

    public static synchronized C0080v a() {
        try {
            if (f967c == null) {
                c();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f967c;
    }

    public static synchronized void c() {
        if (f967c == null) {
            C0080v c0080v = new C0080v();
            f967c = c0080v;
            c0080v.f968a = N0.b();
            N0 n0 = f967c.f968a;
            C0078u c0078u = new C0078u();
            synchronized (n0) {
                n0.f792e = c0078u;
            }
        }
    }

    public static void d(Drawable drawable, U0 u0, int[] iArr) {
        PorterDuff.Mode mode = N0.f;
        int[] state = drawable.getState();
        if (drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
            drawable.setState(new int[0]);
            drawable.setState(state);
        }
        boolean z2 = u0.f823d;
        if (!z2 && !u0.f822c) {
            drawable.clearColorFilter();
            return;
        }
        PorterDuffColorFilter porterDuffColorFilterE = null;
        ColorStateList colorStateList = z2 ? u0.f821a : null;
        PorterDuff.Mode mode2 = u0.f822c ? u0.b : N0.f;
        if (colorStateList != null && mode2 != null) {
            porterDuffColorFilterE = N0.e(colorStateList.getColorForState(iArr, 0), mode2);
        }
        drawable.setColorFilter(porterDuffColorFilterE);
    }

    public final synchronized Drawable b(Context context, int i2) {
        return this.f968a.c(context, i2);
    }
}
