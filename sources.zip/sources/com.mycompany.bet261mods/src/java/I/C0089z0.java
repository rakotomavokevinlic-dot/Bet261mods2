package i;

import android.view.View;
import android.widget.AdapterView;

/* JADX INFO: renamed from: i.z0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0089z0 implements AdapterView.OnItemSelectedListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ G0 f998a;

    public C0089z0(G0 g02) {
        this.f998a = g02;
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public final void onItemSelected(AdapterView adapterView, View view, int i2, long j2) {
        C0077t0 c0077t0;
        if (i2 == -1 || (c0077t0 = this.f998a.f748c) == null) {
            return;
        }
        c0077t0.setListSelectionHidden(false);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public final void onNothingSelected(AdapterView adapterView) {
    }
}
