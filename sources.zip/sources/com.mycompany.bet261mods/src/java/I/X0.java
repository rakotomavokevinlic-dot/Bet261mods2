package i;

import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class X0 implements InterfaceC0067o, h.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Toolbar f827a;

    @Override // h.l
    public void g(h.n nVar) {
        Toolbar toolbar = this.f827a;
        C0061l c0061l = toolbar.a.t;
        if (c0061l == null || !c0061l.h()) {
            toolbar.G.p();
        }
        e.G g2 = toolbar.O;
        if (g2 != null) {
            g2.g(nVar);
        }
    }

    @Override // h.l
    public boolean h(h.n nVar, MenuItem menuItem) {
        e.G g2 = this.f827a.O;
        return false;
    }
}
