package i;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class H extends SeekBar {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final I f770a;

    public H(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 2130903262);
        S0.a(this, getContext());
        I i2 = new I(this);
        this.f770a = i2;
        i2.b(attributeSet, 2130903262);
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        I i2 = this.f770a;
        Drawable drawable = i2.f;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        H h2 = i2.f771e;
        if (drawable.setState(h2.getDrawableState())) {
            h2.invalidateDrawable(drawable);
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f770a.f;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f770a.g(canvas);
    }
}
