package i;

import android.view.View;
import android.widget.PopupWindow;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class A0 {
    public static int a(PopupWindow popupWindow, View view, int i2, boolean z2) {
        return popupWindow.getMaxAvailableHeight(view, i2, z2);
    }
}
