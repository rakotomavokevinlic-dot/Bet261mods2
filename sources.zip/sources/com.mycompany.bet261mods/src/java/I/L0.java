package i;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.widget.PopupWindow;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class L0 extends G0 implements H0 {

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public static final Method f783C;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public C.j f784B;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                f783C = PopupWindow.class.getDeclaredMethod("setTouchModal", Boolean.TYPE);
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    @Override // i.G0
    public final C0077t0 o(Context context, boolean z2) {
        K0 k0 = new K0(context, z2);
        k0.setHoverListener(this);
        return k0;
    }

    @Override // i.H0
    public final void r(h.n nVar, h.p pVar) {
        C.j jVar = this.f784B;
        if (jVar != null) {
            jVar.r(nVar, pVar);
        }
    }

    @Override // i.H0
    public final void t(h.n nVar, h.p pVar) {
        C.j jVar = this.f784B;
        if (jVar != null) {
            jVar.t(nVar, pVar);
        }
    }
}
