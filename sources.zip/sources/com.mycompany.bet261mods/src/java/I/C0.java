package i;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f735a;
    public final /* synthetic */ G0 b;

    public /* synthetic */ C0(G0 g02, int i2) {
        this.f735a = i2;
        this.b = g02;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f735a) {
            case 0:
                C0077t0 c0077t0 = this.b.f748c;
                if (c0077t0 != null) {
                    c0077t0.setListSelectionHidden(true);
                    c0077t0.requestLayout();
                }
                break;
            default:
                G0 g02 = this.b;
                C0077t0 c0077t02 = g02.f748c;
                if (c0077t02 != null && c0077t02.isAttachedToWindow() && g02.f748c.getCount() > g02.f748c.getChildCount() && g02.f748c.getChildCount() <= g02.f757m) {
                    g02.f769y.setInputMethodMode(2);
                    g02.h();
                    break;
                }
                break;
        }
    }
}
