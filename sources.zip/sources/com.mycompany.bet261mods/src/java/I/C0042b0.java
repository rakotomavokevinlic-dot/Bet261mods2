package i;

/* JADX INFO: renamed from: i.b0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public class C0042b0 extends C.j {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0046d0 f845c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0042b0(C0046d0 c0046d0) {
        super(19, c0046d0);
        this.f845c = c0046d0;
    }

    @Override // C.j, i.InterfaceC0040a0
    public final void d(int i2) {
        super/*android.widget.TextView*/.setFirstBaselineToTopHeight(i2);
    }

    @Override // C.j, i.InterfaceC0040a0
    public final void v(int i2) {
        super/*android.widget.TextView*/.setLastBaselineToBottomHeight(i2);
    }
}
