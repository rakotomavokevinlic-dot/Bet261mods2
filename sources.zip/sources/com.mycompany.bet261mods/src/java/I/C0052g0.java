package i;

import android.text.StaticLayout;
import android.widget.TextView;

/* JADX INFO: renamed from: i.g0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0052g0 extends C0050f0 {
    @Override // i.C0050f0, i.AbstractC0054h0
    public void a(StaticLayout.Builder builder, TextView textView) {
        builder.setTextDirection(textView.getTextDirectionHeuristic());
    }

    @Override // i.AbstractC0054h0
    public boolean b(TextView textView) {
        return textView.isHorizontallyScrollable();
    }
}
