package i;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import d.AbstractC0002a;

/* JADX INFO: renamed from: i.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0038A {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ImageView f728a;
    public U0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f729c = 0;

    public C0038A(ImageView imageView) {
        this.f728a = imageView;
    }

    public final void a() {
        U0 u0;
        ImageView imageView = this.f728a;
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            AbstractC0066n0.a(drawable);
        }
        if (drawable == null || (u0 = this.b) == null) {
            return;
        }
        C0080v.d(drawable, u0, imageView.getDrawableState());
    }

    public final void b(AttributeSet attributeSet, int i2) {
        int resourceId;
        ImageView imageView = this.f728a;
        Context context = imageView.getContext();
        int[] iArr = AbstractC0002a.f;
        C.h hVarM = C.h.m(context, attributeSet, iArr, i2);
        y.K.g(imageView, imageView.getContext(), iArr, attributeSet, (TypedArray) hVarM.b, i2);
        try {
            Drawable drawable = imageView.getDrawable();
            TypedArray typedArray = (TypedArray) hVarM.b;
            if (drawable == null && (resourceId = typedArray.getResourceId(1, -1)) != -1 && (drawable = D.g.w(imageView.getContext(), resourceId)) != null) {
                imageView.setImageDrawable(drawable);
            }
            if (drawable != null) {
                AbstractC0066n0.a(drawable);
            }
            if (typedArray.hasValue(2)) {
                D.h.c(imageView, hVarM.h(2));
            }
            if (typedArray.hasValue(3)) {
                D.h.d(imageView, AbstractC0066n0.b(typedArray.getInt(3, -1), null));
            }
            hVarM.r();
        } catch (Throwable th) {
            hVarM.r();
            throw th;
        }
    }
}
