package i;

import android.view.MotionEvent;
import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class F0 implements View.OnTouchListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ G0 f744a;

    public F0(G0 g02) {
        this.f744a = g02;
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        D d2;
        int action = motionEvent.getAction();
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        G0 g02 = this.f744a;
        if (action == 0 && (d2 = g02.f769y) != null && d2.isShowing() && x2 >= 0 && x2 < g02.f769y.getWidth() && y2 >= 0 && y2 < g02.f769y.getHeight()) {
            g02.f765u.postDelayed(g02.f761q, 250L);
            return false;
        }
        if (action != 1) {
            return false;
        }
        g02.f765u.removeCallbacks(g02.f761q);
        return false;
    }
}
