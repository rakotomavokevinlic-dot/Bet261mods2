package m;

/* JADX INFO: renamed from: m.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0110f {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C0110f f1060c = new C0110f();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public volatile Thread f1061a;
    public volatile C0110f b;

    public C0110f() {
        AbstractFutureC0111g.f.W(this, Thread.currentThread());
    }
}
