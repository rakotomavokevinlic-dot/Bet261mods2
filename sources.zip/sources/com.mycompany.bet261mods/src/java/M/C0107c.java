package m;

/* JADX INFO: renamed from: m.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0107c {
    public static final C0107c b = new C0107c();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public C0107c f1054a;
}
