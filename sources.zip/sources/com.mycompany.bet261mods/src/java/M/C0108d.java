package m;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* JADX INFO: renamed from: m.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0108d extends D.g {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1055o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1056p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1057q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1058r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final AtomicReferenceFieldUpdater f1059s;

    public C0108d(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater5) {
        this.f1055o = atomicReferenceFieldUpdater;
        this.f1056p = atomicReferenceFieldUpdater2;
        this.f1057q = atomicReferenceFieldUpdater3;
        this.f1058r = atomicReferenceFieldUpdater4;
        this.f1059s = atomicReferenceFieldUpdater5;
    }

    @Override // D.g
    public final void V(C0110f c0110f, C0110f c0110f2) {
        this.f1056p.lazySet(c0110f, c0110f2);
    }

    @Override // D.g
    public final void W(C0110f c0110f, Thread thread) {
        this.f1055o.lazySet(c0110f, thread);
    }

    @Override // D.g
    public final boolean a(AbstractFutureC0111g abstractFutureC0111g, C0107c c0107c) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        C0107c c0107c2 = C0107c.b;
        do {
            atomicReferenceFieldUpdater = this.f1058r;
            if (atomicReferenceFieldUpdater.compareAndSet(abstractFutureC0111g, c0107c, c0107c2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(abstractFutureC0111g) == c0107c);
        return false;
    }

    @Override // D.g
    public final boolean b(AbstractFutureC0111g abstractFutureC0111g, Object obj, Object obj2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f1059s;
            if (atomicReferenceFieldUpdater.compareAndSet(abstractFutureC0111g, obj, obj2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(abstractFutureC0111g) == obj);
        return false;
    }

    @Override // D.g
    public final boolean c(AbstractFutureC0111g abstractFutureC0111g, C0110f c0110f, C0110f c0110f2) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = this.f1057q;
            if (atomicReferenceFieldUpdater.compareAndSet(abstractFutureC0111g, c0110f, c0110f2)) {
                return true;
            }
        } while (atomicReferenceFieldUpdater.get(abstractFutureC0111g) == c0110f);
        return false;
    }
}
