package M;

import C.h;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import android.widget.TextView;
import d.AbstractC0002a;
import i.AbstractC0066n0;
import i.C0076t;
import s.AbstractC0120a;
import y.K;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f115a;
    public boolean b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f116c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f117d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Parcelable f118e;
    public Object f;

    public /* synthetic */ e(TextView textView) {
        this.f118e = null;
        this.f = null;
        this.f115a = false;
        this.b = false;
        this.f117d = textView;
    }

    public void a() {
        CompoundButton compoundButton = (CompoundButton) this.f117d;
        Drawable drawableA = D.d.a(compoundButton);
        if (drawableA != null) {
            if (this.f115a || this.b) {
                Drawable drawableMutate = drawableA.mutate();
                if (this.f115a) {
                    AbstractC0120a.h(drawableMutate, (ColorStateList) this.f118e);
                }
                if (this.b) {
                    AbstractC0120a.i(drawableMutate, (PorterDuff.Mode) this.f);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(compoundButton.getDrawableState());
                }
                compoundButton.setButtonDrawable(drawableMutate);
            }
        }
    }

    public void b() {
        C0076t c0076t = (C0076t) this.f117d;
        Drawable checkMarkDrawable = c0076t.getCheckMarkDrawable();
        if (checkMarkDrawable != null) {
            if (this.f115a || this.b) {
                Drawable drawableMutate = checkMarkDrawable.mutate();
                if (this.f115a) {
                    AbstractC0120a.h(drawableMutate, (ColorStateList) this.f118e);
                }
                if (this.b) {
                    AbstractC0120a.i(drawableMutate, (PorterDuff.Mode) this.f);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(c0076t.getDrawableState());
                }
                c0076t.setCheckMarkDrawable(drawableMutate);
            }
        }
    }

    public Bundle c(String str) {
        if (!this.b) {
            throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
        }
        Bundle bundle = (Bundle) this.f118e;
        if (bundle == null) {
            return null;
        }
        Bundle bundle2 = bundle.getBundle(str);
        Bundle bundle3 = (Bundle) this.f118e;
        if (bundle3 != null) {
            bundle3.remove(str);
        }
        Bundle bundle4 = (Bundle) this.f118e;
        if (bundle4 != null && !bundle4.isEmpty()) {
            return bundle2;
        }
        this.f118e = null;
        return bundle2;
    }

    public void d(AttributeSet attributeSet, int i2) {
        int resourceId;
        int resourceId2;
        CompoundButton compoundButton = (CompoundButton) this.f117d;
        Context context = compoundButton.getContext();
        int[] iArr = AbstractC0002a.f328m;
        h hVarM = h.m(context, attributeSet, iArr, i2);
        TypedArray typedArray = (TypedArray) hVarM.b;
        K.g(compoundButton, compoundButton.getContext(), iArr, attributeSet, (TypedArray) hVarM.b, i2);
        try {
            if (typedArray.hasValue(1) && (resourceId2 = typedArray.getResourceId(1, 0)) != 0) {
                try {
                    compoundButton.setButtonDrawable(D.g.w(compoundButton.getContext(), resourceId2));
                } catch (Resources.NotFoundException unused) {
                    if (typedArray.hasValue(0)) {
                        compoundButton.setButtonDrawable(D.g.w(compoundButton.getContext(), resourceId));
                    }
                }
            } else if (typedArray.hasValue(0) && (resourceId = typedArray.getResourceId(0, 0)) != 0) {
                compoundButton.setButtonDrawable(D.g.w(compoundButton.getContext(), resourceId));
            }
            if (typedArray.hasValue(2)) {
                D.c.c(compoundButton, hVarM.h(2));
            }
            if (typedArray.hasValue(3)) {
                D.c.d(compoundButton, AbstractC0066n0.b(typedArray.getInt(3, -1), null));
            }
            hVarM.r();
        } catch (Throwable th) {
            hVarM.r();
            throw th;
        }
    }

    public void e(String str, d dVar) {
        Object obj;
        k.f fVar = (k.f) this.f117d;
        k.c cVar = fVar.f1010a;
        while (cVar != null && !cVar.f1005a.equals(str)) {
            cVar = cVar.f1006c;
        }
        if (cVar != null) {
            obj = cVar.b;
        } else {
            k.c cVar2 = new k.c(str, dVar);
            fVar.f1012d++;
            k.c cVar3 = fVar.b;
            if (cVar3 == null) {
                fVar.f1010a = cVar2;
                fVar.b = cVar2;
            } else {
                cVar3.f1006c = cVar2;
                cVar2.f1007d = cVar3;
                fVar.b = cVar2;
            }
            obj = null;
        }
        if (((d) obj) != null) {
            throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
        }
    }

    public e() {
        this.f117d = new k.f();
        this.f116c = true;
    }
}
