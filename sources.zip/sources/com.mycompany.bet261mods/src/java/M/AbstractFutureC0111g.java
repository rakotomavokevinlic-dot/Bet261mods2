package m;

import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

/* JADX INFO: renamed from: m.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class AbstractFutureC0111g implements Future {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final boolean f1062d = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Logger f1063e = Logger.getLogger(AbstractFutureC0111g.class.getName());
    public static final D.g f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final Object f1064g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public volatile Object f1065a;
    public volatile C0107c b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile C0110f f1066c;

    static {
        D.g c0109e;
        try {
            c0109e = new C0108d(AtomicReferenceFieldUpdater.newUpdater(C0110f.class, Thread.class, "a"), AtomicReferenceFieldUpdater.newUpdater(C0110f.class, C0110f.class, "b"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0111g.class, C0110f.class, "c"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0111g.class, C0107c.class, "b"), AtomicReferenceFieldUpdater.newUpdater(AbstractFutureC0111g.class, Object.class, "a"));
            th = null;
        } catch (Throwable th) {
            th = th;
            c0109e = new C0109e();
        }
        f = c0109e;
        if (th != null) {
            f1063e.log(Level.SEVERE, "SafeAtomicHelper is broken!", th);
        }
        f1064g = new Object();
    }

    public static void b(AbstractFutureC0111g abstractFutureC0111g) {
        C0110f c0110f;
        C0107c c0107c;
        do {
            c0110f = abstractFutureC0111g.f1066c;
        } while (!f.c(abstractFutureC0111g, c0110f, C0110f.f1060c));
        while (c0110f != null) {
            Thread thread = c0110f.f1061a;
            if (thread != null) {
                c0110f.f1061a = null;
                LockSupport.unpark(thread);
            }
            c0110f = c0110f.b;
        }
        do {
            c0107c = abstractFutureC0111g.b;
        } while (!f.a(abstractFutureC0111g, c0107c));
        C0107c c0107c2 = null;
        while (c0107c != null) {
            C0107c c0107c3 = c0107c.f1054a;
            c0107c.f1054a = c0107c2;
            c0107c2 = c0107c;
            c0107c = c0107c3;
        }
        while (c0107c2 != null) {
            c0107c2 = c0107c2.f1054a;
            try {
                throw null;
            } catch (RuntimeException e2) {
                f1063e.log(Level.SEVERE, "RuntimeException while executing runnable null with executor null", (Throwable) e2);
            }
        }
    }

    public static Object c(Object obj) throws ExecutionException {
        if (obj instanceof C0105a) {
            CancellationException cancellationException = ((C0105a) obj).f1053a;
            CancellationException cancellationException2 = new CancellationException("Task was cancelled.");
            cancellationException2.initCause(cancellationException);
            throw cancellationException2;
        }
        if (obj instanceof AbstractC0106b) {
            ((AbstractC0106b) obj).getClass();
            throw new ExecutionException((Throwable) null);
        }
        if (obj == f1064g) {
            return null;
        }
        return obj;
    }

    public static Object d(AbstractFutureC0111g abstractFutureC0111g) {
        Object obj;
        boolean z2 = false;
        while (true) {
            try {
                obj = abstractFutureC0111g.get();
                break;
            } catch (InterruptedException unused) {
                z2 = true;
            } catch (Throwable th) {
                if (z2) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z2) {
            Thread.currentThread().interrupt();
        }
        return obj;
    }

    public final void a(StringBuilder sb) {
        try {
            Object objD = d(this);
            sb.append("SUCCESS, result=[");
            sb.append(objD == this ? "this future" : String.valueOf(objD));
            sb.append("]");
        } catch (CancellationException unused) {
            sb.append("CANCELLED");
        } catch (RuntimeException e2) {
            sb.append("UNKNOWN, cause=[");
            sb.append(e2.getClass());
            sb.append(" thrown from get()]");
        } catch (ExecutionException e3) {
            sb.append("FAILURE, cause=[");
            sb.append(e3.getCause());
            sb.append("]");
        }
    }

    @Override // java.util.concurrent.Future
    public final boolean cancel(boolean z2) {
        Object obj = this.f1065a;
        if (obj != null) {
            return false;
        }
        if (!f.b(this, obj, f1062d ? new C0105a(z2, new CancellationException("Future.cancel() was called.")) : z2 ? C0105a.b : C0105a.f1052c)) {
            return false;
        }
        b(this);
        return true;
    }

    public final void e(C0110f c0110f) {
        c0110f.f1061a = null;
        while (true) {
            C0110f c0110f2 = this.f1066c;
            if (c0110f2 == C0110f.f1060c) {
                return;
            }
            C0110f c0110f3 = null;
            while (c0110f2 != null) {
                C0110f c0110f4 = c0110f2.b;
                if (c0110f2.f1061a != null) {
                    c0110f3 = c0110f2;
                } else if (c0110f3 != null) {
                    c0110f3.b = c0110f4;
                    if (c0110f3.f1061a == null) {
                        break;
                    }
                } else if (!f.c(this, c0110f2, c0110f4)) {
                    break;
                }
                c0110f2 = c0110f4;
            }
            return;
        }
    }

    @Override // java.util.concurrent.Future
    public final Object get(long j2, TimeUnit timeUnit) throws InterruptedException, TimeoutException {
        long nanos = timeUnit.toNanos(j2);
        if (Thread.interrupted()) {
            throw new InterruptedException();
        }
        Object obj = this.f1065a;
        if (obj != null) {
            return c(obj);
        }
        long jNanoTime = nanos > 0 ? System.nanoTime() + nanos : 0L;
        if (nanos >= 1000) {
            C0110f c0110f = this.f1066c;
            C0110f c0110f2 = C0110f.f1060c;
            if (c0110f != c0110f2) {
                C0110f c0110f3 = new C0110f();
                do {
                    D.g gVar = f;
                    gVar.V(c0110f3, c0110f);
                    if (gVar.c(this, c0110f, c0110f3)) {
                        do {
                            LockSupport.parkNanos(this, nanos);
                            if (Thread.interrupted()) {
                                e(c0110f3);
                                throw new InterruptedException();
                            }
                            Object obj2 = this.f1065a;
                            if (obj2 != null) {
                                return c(obj2);
                            }
                            nanos = jNanoTime - System.nanoTime();
                        } while (nanos >= 1000);
                        e(c0110f3);
                    } else {
                        c0110f = this.f1066c;
                    }
                } while (c0110f != c0110f2);
            }
            return c(this.f1065a);
        }
        while (nanos > 0) {
            Object obj3 = this.f1065a;
            if (obj3 != null) {
                return c(obj3);
            }
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            nanos = jNanoTime - System.nanoTime();
        }
        String string = toString();
        String string2 = timeUnit.toString();
        Locale locale = Locale.ROOT;
        String lowerCase = string2.toLowerCase(locale);
        String str = "Waited " + j2 + " " + timeUnit.toString().toLowerCase(locale);
        if (nanos + 1000 < 0) {
            String str2 = str + " (plus ";
            long j3 = -nanos;
            long jConvert = timeUnit.convert(j3, TimeUnit.NANOSECONDS);
            long nanos2 = j3 - timeUnit.toNanos(jConvert);
            boolean z2 = jConvert == 0 || nanos2 > 1000;
            if (jConvert > 0) {
                String str3 = str2 + jConvert + " " + lowerCase;
                if (z2) {
                    str3 = str3 + ",";
                }
                str2 = str3 + " ";
            }
            if (z2) {
                str2 = str2 + nanos2 + " nanoseconds ";
            }
            str = str2 + "delay)";
        }
        if (isDone()) {
            throw new TimeoutException(str + " but future completed as timeout expired");
        }
        throw new TimeoutException(str + " for " + string);
    }

    @Override // java.util.concurrent.Future
    public final boolean isCancelled() {
        return this.f1065a instanceof C0105a;
    }

    @Override // java.util.concurrent.Future
    public final boolean isDone() {
        return this.f1065a != null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("[status=");
        if (this.f1065a instanceof C0105a) {
            sb.append("CANCELLED");
        } else if (isDone()) {
            a(sb);
        } else {
            try {
                if (this instanceof ScheduledFuture) {
                    str = "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
                } else {
                    str = null;
                }
            } catch (RuntimeException e2) {
                str = "Exception thrown from implementation: " + e2.getClass();
            }
            if (str != null && !str.isEmpty()) {
                sb.append("PENDING, info=[");
                sb.append(str);
                sb.append("]");
            } else if (isDone()) {
                a(sb);
            } else {
                sb.append("PENDING");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    @Override // java.util.concurrent.Future
    public final Object get() throws InterruptedException {
        Object obj;
        if (!Thread.interrupted()) {
            Object obj2 = this.f1065a;
            if (obj2 != null) {
                return c(obj2);
            }
            C0110f c0110f = this.f1066c;
            C0110f c0110f2 = C0110f.f1060c;
            if (c0110f != c0110f2) {
                C0110f c0110f3 = new C0110f();
                do {
                    D.g gVar = f;
                    gVar.V(c0110f3, c0110f);
                    if (gVar.c(this, c0110f, c0110f3)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f1065a;
                            } else {
                                e(c0110f3);
                                throw new InterruptedException();
                            }
                        } while (obj == null);
                        return c(obj);
                    }
                    c0110f = this.f1066c;
                } while (c0110f != c0110f2);
            }
            return c(this.f1065a);
        }
        throw new InterruptedException();
    }
}
