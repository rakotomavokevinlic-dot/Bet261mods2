package m;

import java.util.concurrent.CancellationException;

/* JADX INFO: renamed from: m.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0105a {
    public static final C0105a b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C0105a f1052c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final CancellationException f1053a;

    static {
        if (AbstractFutureC0111g.f1062d) {
            f1052c = null;
            b = null;
        } else {
            f1052c = new C0105a(false, null);
            b = new C0105a(true, null);
        }
    }

    public C0105a(boolean z2, CancellationException cancellationException) {
        this.f1053a = cancellationException;
    }
}
