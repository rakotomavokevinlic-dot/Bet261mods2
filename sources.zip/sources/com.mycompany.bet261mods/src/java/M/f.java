package M;

import android.os.Bundle;
import androidx.lifecycle.k;
import androidx.lifecycle.l;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import androidx.lifecycle.s;
import androidx.savedstate.Recreator;
import java.util.ArrayList;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f119a;
    public boolean b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f120c;

    public f(g gVar) {
        this.f119a = gVar;
        this.f120c = new e();
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [M.g, androidx.lifecycle.q, java.lang.Object] */
    public void a() {
        ?? r0 = this.f119a;
        s sVarC = r0.c();
        if (sVarC.c != l.b) {
            throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
        }
        sVarC.a(new Recreator((g) r0));
        final e eVar = (e) this.f120c;
        eVar.getClass();
        if (eVar.f115a) {
            throw new IllegalStateException("SavedStateRegistry was already attached.");
        }
        sVarC.a(new o() { // from class: M.b
            public final void b(q qVar, k kVar) {
                e eVar2 = eVar;
                e0.c.e(eVar2, "this$0");
                if (kVar == k.ON_START) {
                    eVar2.f116c = true;
                } else if (kVar == k.ON_STOP) {
                    eVar2.f116c = false;
                }
            }
        });
        eVar.f115a = true;
        this.b = true;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [androidx.lifecycle.q, java.lang.Object] */
    public void b(Bundle bundle) {
        if (!this.b) {
            a();
        }
        s sVarC = this.f119a.c();
        if (sVarC.c.compareTo(l.d) >= 0) {
            throw new IllegalStateException(("performRestore cannot be called when owner is " + sVarC.c).toString());
        }
        e eVar = (e) this.f120c;
        if (!eVar.f115a) {
            throw new IllegalStateException("You must call performAttach() before calling performRestore(Bundle).");
        }
        if (eVar.b) {
            throw new IllegalStateException("SavedStateRegistry was already restored.");
        }
        eVar.f118e = bundle != null ? bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key") : null;
        eVar.b = true;
    }

    public void c(Bundle bundle) {
        e eVar = (e) this.f120c;
        eVar.getClass();
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = (Bundle) eVar.f118e;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        k.f fVar = (k.f) eVar.f117d;
        fVar.getClass();
        k.d dVar = new k.d(fVar);
        fVar.f1011c.put(dVar, Boolean.FALSE);
        while (dVar.hasNext()) {
            Map.Entry entry = (Map.Entry) dVar.next();
            bundle2.putBundle((String) entry.getKey(), ((d) entry.getValue()).a());
        }
        if (bundle2.isEmpty()) {
            return;
        }
        bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
    }

    public f(androidx.activity.k kVar, androidx.activity.e eVar) {
        this.f119a = new Object();
        this.f120c = new ArrayList();
    }
}
