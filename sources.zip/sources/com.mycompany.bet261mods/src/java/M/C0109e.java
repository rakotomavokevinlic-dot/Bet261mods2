package m;

/* JADX INFO: renamed from: m.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0109e extends D.g {
    @Override // D.g
    public final void V(C0110f c0110f, C0110f c0110f2) {
        c0110f.b = c0110f2;
    }

    @Override // D.g
    public final void W(C0110f c0110f, Thread thread) {
        c0110f.f1061a = thread;
    }

    @Override // D.g
    public final boolean a(AbstractFutureC0111g abstractFutureC0111g, C0107c c0107c) {
        C0107c c0107c2 = C0107c.b;
        synchronized (abstractFutureC0111g) {
            try {
                if (abstractFutureC0111g.b != c0107c) {
                    return false;
                }
                abstractFutureC0111g.b = c0107c2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // D.g
    public final boolean b(AbstractFutureC0111g abstractFutureC0111g, Object obj, Object obj2) {
        synchronized (abstractFutureC0111g) {
            try {
                if (abstractFutureC0111g.f1065a != obj) {
                    return false;
                }
                abstractFutureC0111g.f1065a = obj2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // D.g
    public final boolean c(AbstractFutureC0111g abstractFutureC0111g, C0110f c0110f, C0110f c0110f2) {
        synchronized (abstractFutureC0111g) {
            try {
                if (abstractFutureC0111g.f1066c != c0110f) {
                    return false;
                }
                abstractFutureC0111g.f1066c = c0110f2;
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
