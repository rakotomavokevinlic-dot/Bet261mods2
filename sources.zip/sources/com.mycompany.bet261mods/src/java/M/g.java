package M;

import androidx.lifecycle.q;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface g extends q {
    e a();
}
