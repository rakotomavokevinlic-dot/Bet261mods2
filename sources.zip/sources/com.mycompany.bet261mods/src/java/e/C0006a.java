package e;

import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;

/* JADX INFO: renamed from: e.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0006a implements AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0010e f460a;
    public final /* synthetic */ C0007b b;

    public C0006a(C0007b c0007b, C0010e c0010e) {
        this.b = c0007b;
        this.f460a = c0010e;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        C0007b c0007b = this.b;
        DialogInterface.OnClickListener onClickListener = c0007b.f466h;
        C0010e c0010e = this.f460a;
        onClickListener.onClick(c0010e.b, i2);
        if (c0007b.f467i) {
            return;
        }
        c0010e.b.dismiss();
    }
}
