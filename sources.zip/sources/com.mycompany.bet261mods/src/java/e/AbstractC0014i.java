package e;

import android.R;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import g.C0027h;
import i.C0080v;
import i.N0;
import i.j1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import l.C0097e;

/* JADX INFO: renamed from: e.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class AbstractC0014i extends androidx.activity.l implements InterfaceC0015j, o.b {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f499t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f500u;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public LayoutInflaterFactory2C0004B f502w;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final C.j f497r = new C.j(12, new androidx.fragment.app.f(this));

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final androidx.lifecycle.s f498s = new androidx.lifecycle.s(this);

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f501v = true;

    public AbstractC0014i() {
        ((M.e) ((androidx.activity.l) this).e.f120c).e("android:support:lifecycle", new androidx.activity.f(1, this));
        ((androidx.activity.l) this).k.add(new androidx.fragment.app.e(this, 0));
        ((androidx.activity.l) this).m.add(new androidx.fragment.app.e(this, 1));
        f(new androidx.activity.g(this, 1));
    }

    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        h();
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        layoutInflaterFactory2C0004B.w();
        ((ViewGroup) layoutInflaterFactory2C0004B.f358A.findViewById(R.id.content)).addView(view, layoutParams);
        layoutInflaterFactory2C0004B.f393m.a(layoutInflaterFactory2C0004B.f392l.getCallback());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:167:0x0232 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0099  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00ab  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void attachBaseContext(android.content.Context r11) {
        /*
            Method dump skipped, instruction units count: 587
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: e.AbstractC0014i.attachBaseContext(android.content.Context):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void closeOptionsMenu() {
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        layoutInflaterFactory2C0004B.A();
        D.g gVar = layoutInflaterFactory2C0004B.f395o;
        if (getWindow().hasFeature(0)) {
            if (gVar == null || !gVar.f()) {
                super/*android.app.Activity*/.closeOptionsMenu();
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        layoutInflaterFactory2C0004B.A();
        D.g gVar = layoutInflaterFactory2C0004B.f395o;
        if (keyCode == 82 && gVar != null && gVar.P(keyEvent)) {
            return true;
        }
        return super/*o.h*/.dispatchKeyEvent(keyEvent);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0046  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void dump(java.lang.String r6, java.io.FileDescriptor r7, java.io.PrintWriter r8, java.lang.String[] r9) {
        /*
            Method dump skipped, instruction units count: 620
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: e.AbstractC0014i.dump(java.lang.String, java.io.FileDescriptor, java.io.PrintWriter, java.lang.String[]):void");
    }

    public final View findViewById(int i2) {
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        layoutInflaterFactory2C0004B.w();
        return layoutInflaterFactory2C0004B.f392l.findViewById(i2);
    }

    public final MenuInflater getMenuInflater() {
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        if (layoutInflaterFactory2C0004B.f396p == null) {
            layoutInflaterFactory2C0004B.A();
            D.g gVar = layoutInflaterFactory2C0004B.f395o;
            layoutInflaterFactory2C0004B.f396p = new C0027h(gVar != null ? gVar.D() : layoutInflaterFactory2C0004B.f391k);
        }
        return layoutInflaterFactory2C0004B.f396p;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final Resources getResources() {
        int i2 = j1.f903a;
        return super/*android.content.Context*/.getResources();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final o i() {
        if (this.f502w == null) {
            ExecutorC0018m executorC0018m = o.f506a;
            this.f502w = new LayoutInflaterFactory2C0004B(this, null, this, this);
        }
        return this.f502w;
    }

    public final void invalidateOptionsMenu() {
        i().b();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void j() {
        Integer num;
        Integer num2;
        Integer num3;
        super/*android.app.Activity*/.onDestroy();
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) this.f497r.b).c;
        boolean zIsChangingConfigurations = true;
        pVar.A = true;
        pVar.e(true);
        Iterator it = pVar.b().iterator();
        if (it.hasNext()) {
            ((androidx.fragment.app.v) it.next()).a();
            throw null;
        }
        androidx.fragment.app.f fVar = pVar.r;
        T.t tVar = pVar.c;
        if (fVar != null) {
            zIsChangingConfigurations = ((androidx.fragment.app.r) tVar.f213d).f;
        } else {
            androidx.activity.l lVar = fVar.a;
            if (lVar != null) {
                zIsChangingConfigurations = true ^ lVar.isChangingConfigurations();
            }
        }
        if (zIsChangingConfigurations) {
            Iterator it2 = pVar.i.values().iterator();
            while (it2.hasNext()) {
                ArrayList arrayList = ((androidx.fragment.app.c) it2.next()).a;
                int size = arrayList.size();
                int i2 = 0;
                while (i2 < size) {
                    Object obj = arrayList.get(i2);
                    i2++;
                    String str = (String) obj;
                    androidx.fragment.app.r rVar = (androidx.fragment.app.r) tVar.f213d;
                    rVar.getClass();
                    if (androidx.fragment.app.p.h(3)) {
                        Log.d("FragmentManager", "Clearing non-config state for saved state of Fragment " + str);
                    }
                    HashMap map = rVar.d;
                    androidx.fragment.app.r rVar2 = (androidx.fragment.app.r) map.get(str);
                    if (rVar2 != null) {
                        rVar2.a();
                        map.remove(str);
                    }
                    HashMap map2 = rVar.e;
                    androidx.lifecycle.G g2 = (androidx.lifecycle.G) map2.get(str);
                    if (g2 != null) {
                        g2.a();
                        map2.remove(str);
                    }
                }
            }
        }
        pVar.c(-1);
        androidx.fragment.app.f fVar2 = pVar.r;
        if (fVar2 != null) {
            ((androidx.activity.l) fVar2.d).l.remove(pVar.m);
        }
        androidx.fragment.app.f fVar3 = pVar.r;
        if (fVar3 != null) {
            ((androidx.activity.l) fVar3.d).k.remove(pVar.l);
        }
        androidx.fragment.app.f fVar4 = pVar.r;
        if (fVar4 != null) {
            ((androidx.activity.l) fVar4.d).n.remove(pVar.n);
        }
        androidx.fragment.app.f fVar5 = pVar.r;
        if (fVar5 != null) {
            ((androidx.activity.l) fVar5.d).o.remove(pVar.o);
        }
        androidx.fragment.app.f fVar6 = pVar.r;
        if (fVar6 != null) {
            C.h hVar = ((androidx.activity.l) fVar6.d).c;
            CopyOnWriteArrayList copyOnWriteArrayList = (CopyOnWriteArrayList) hVar.b;
            androidx.fragment.app.l lVar2 = pVar.p;
            copyOnWriteArrayList.remove(lVar2);
            if (((HashMap) hVar.f7c).remove(lVar2) != null) {
                throw new ClassCastException();
            }
            ((Runnable) hVar.f6a).run();
        }
        pVar.r = null;
        pVar.s = null;
        if (pVar.f != null) {
            Iterator it3 = pVar.g.b.iterator();
            while (it3.hasNext()) {
                ((androidx.activity.c) it3.next()).cancel();
            }
            pVar.f = null;
        }
        G.a aVar = pVar.u;
        if (aVar != null) {
            androidx.activity.h hVar2 = (androidx.activity.h) aVar.b;
            ArrayList arrayList2 = hVar2.d;
            String str2 = (String) aVar.f57a;
            if (!arrayList2.contains(str2) && (num3 = (Integer) hVar2.b.remove(str2)) != null) {
                hVar2.a.remove(num3);
            }
            hVar2.e.remove(str2);
            HashMap map3 = hVar2.f;
            if (map3.containsKey(str2)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str2 + ": " + map3.get(str2));
                map3.remove(str2);
            }
            Bundle bundle = hVar2.g;
            if (bundle.containsKey(str2)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str2 + ": " + bundle.getParcelable(str2));
                bundle.remove(str2);
            }
            if (hVar2.c.get(str2) != null) {
                throw new ClassCastException();
            }
            G.a aVar2 = pVar.v;
            androidx.activity.h hVar3 = (androidx.activity.h) aVar2.b;
            ArrayList arrayList3 = hVar3.d;
            String str3 = (String) aVar2.f57a;
            if (!arrayList3.contains(str3) && (num2 = (Integer) hVar3.b.remove(str3)) != null) {
                hVar3.a.remove(num2);
            }
            hVar3.e.remove(str3);
            HashMap map4 = hVar3.f;
            if (map4.containsKey(str3)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str3 + ": " + map4.get(str3));
                map4.remove(str3);
            }
            Bundle bundle2 = hVar3.g;
            if (bundle2.containsKey(str3)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str3 + ": " + bundle2.getParcelable(str3));
                bundle2.remove(str3);
            }
            if (hVar3.c.get(str3) != null) {
                throw new ClassCastException();
            }
            G.a aVar3 = pVar.w;
            androidx.activity.h hVar4 = (androidx.activity.h) aVar3.b;
            ArrayList arrayList4 = hVar4.d;
            String str4 = (String) aVar3.f57a;
            if (!arrayList4.contains(str4) && (num = (Integer) hVar4.b.remove(str4)) != null) {
                hVar4.a.remove(num);
            }
            hVar4.e.remove(str4);
            HashMap map5 = hVar4.f;
            if (map5.containsKey(str4)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str4 + ": " + map5.get(str4));
                map5.remove(str4);
            }
            Bundle bundle3 = hVar4.g;
            if (bundle3.containsKey(str4)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str4 + ": " + bundle3.getParcelable(str4));
                bundle3.remove(str4);
            }
            if (hVar4.c.get(str4) != null) {
                throw new ClassCastException();
            }
        }
        this.f498s.d(androidx.lifecycle.k.ON_DESTROY);
    }

    public final boolean k(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 != 6) {
            return false;
        }
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) this.f497r.b).c;
        if (pVar.q < 1) {
            return false;
        }
        Iterator it = pVar.c.d().iterator();
        while (it.hasNext()) {
            if (it.next() != null) {
                throw new ClassCastException();
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void l() {
        super/*android.app.Activity*/.onPostResume();
        this.f498s.d(androidx.lifecycle.k.ON_RESUME);
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) this.f497r.b).c;
        pVar.y = false;
        pVar.z = false;
        pVar.E.getClass();
        pVar.c(7);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void m() {
        C.j jVar = this.f497r;
        jVar.x();
        super/*android.app.Activity*/.onStart();
        this.f501v = false;
        boolean z2 = this.f499t;
        androidx.fragment.app.f fVar = (androidx.fragment.app.f) jVar.b;
        if (!z2) {
            this.f499t = true;
            androidx.fragment.app.p pVar = fVar.c;
            pVar.y = false;
            pVar.z = false;
            pVar.E.getClass();
            pVar.c(4);
        }
        fVar.c.e(true);
        this.f498s.d(androidx.lifecycle.k.ON_START);
        androidx.fragment.app.p pVar2 = fVar.c;
        pVar2.y = false;
        pVar2.z = false;
        pVar2.E.getClass();
        pVar2.c(5);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void n() {
        super/*android.app.Activity*/.onStop();
        this.f501v = true;
        C.j jVar = this.f497r;
        Iterator it = ((androidx.fragment.app.f) jVar.b).c.c.d().iterator();
        while (it.hasNext()) {
            if (it.next() != null) {
                throw new ClassCastException();
            }
        }
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) jVar.b).c;
        pVar.z = true;
        pVar.E.getClass();
        pVar.c(4);
        this.f498s.d(androidx.lifecycle.k.ON_STOP);
    }

    public void onActivityResult(int i2, int i3, Intent intent) {
        this.f497r.x();
        super.onActivityResult(i2, i3, intent);
    }

    public final void onConfigurationChanged(Configuration configuration) throws IllegalAccessException {
        super.onConfigurationChanged(configuration);
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        if (layoutInflaterFactory2C0004B.f363F && layoutInflaterFactory2C0004B.f406z) {
            layoutInflaterFactory2C0004B.A();
            D.g gVar = layoutInflaterFactory2C0004B.f395o;
            if (gVar != null) {
                gVar.J();
            }
        }
        C0080v c0080vA = C0080v.a();
        Context context = layoutInflaterFactory2C0004B.f391k;
        synchronized (c0080vA) {
            N0 n0 = c0080vA.f968a;
            synchronized (n0) {
                C0097e c0097e = (C0097e) n0.b.get(context);
                if (c0097e != null) {
                    int i2 = c0097e.f1030d;
                    Object[] objArr = c0097e.f1029c;
                    for (int i3 = 0; i3 < i2; i3++) {
                        objArr[i3] = null;
                    }
                    c0097e.f1030d = 0;
                    c0097e.f1028a = false;
                }
            }
        }
        layoutInflaterFactory2C0004B.f375R = new Configuration(layoutInflaterFactory2C0004B.f391k.getResources().getConfiguration());
        layoutInflaterFactory2C0004B.n(false, false);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f498s.d(androidx.lifecycle.k.ON_CREATE);
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) this.f497r.b).c;
        pVar.y = false;
        pVar.z = false;
        pVar.E.getClass();
        pVar.c(1);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((androidx.fragment.app.f) this.f497r.b).c.e.onCreateView(view, str, context, attributeSet);
        return viewOnCreateView == null ? super/*android.app.Activity*/.onCreateView(view, str, context, attributeSet) : viewOnCreateView;
    }

    public void onDestroy() {
        j();
        i().e();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        Window window;
        if (Build.VERSION.SDK_INT >= 26 || keyEvent.isCtrlPressed() || KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState()) || keyEvent.getRepeatCount() != 0 || KeyEvent.isModifierKey(keyEvent.getKeyCode()) || (window = getWindow()) == null || window.getDecorView() == null || !window.getDecorView().dispatchKeyShortcutEvent(keyEvent)) {
            return super/*android.app.Activity*/.onKeyDown(i2, keyEvent);
        }
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        Intent intentB;
        if (!k(i2, menuItem)) {
            LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
            layoutInflaterFactory2C0004B.A();
            D.g gVar = layoutInflaterFactory2C0004B.f395o;
            if (menuItem.getItemId() != 16908332 || gVar == null || (gVar.u() & 4) == 0 || (intentB = o.e.b(this)) == null) {
                return false;
            }
            if (!shouldUpRecreateTask(intentB)) {
                navigateUpTo(intentB);
                return true;
            }
            ArrayList arrayList = new ArrayList();
            Intent intentB2 = o.e.b(this);
            if (intentB2 == null) {
                intentB2 = o.e.b(this);
            }
            if (intentB2 != null) {
                ComponentName component = intentB2.getComponent();
                if (component == null) {
                    component = intentB2.resolveActivity(getPackageManager());
                }
                int size = arrayList.size();
                try {
                    Intent intentC = o.e.c(this, component);
                    while (intentC != null) {
                        arrayList.add(size, intentC);
                        intentC = o.e.c(this, intentC.getComponent());
                    }
                    arrayList.add(intentB2);
                } catch (PackageManager.NameNotFoundException e2) {
                    Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
                    throw new IllegalArgumentException(e2);
                }
            }
            if (arrayList.isEmpty()) {
                throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
            }
            Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[0]);
            intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
            startActivities(intentArr, null);
            try {
                finishAffinity();
            } catch (IllegalStateException unused) {
                finish();
            }
        }
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onPause() {
        super/*android.app.Activity*/.onPause();
        this.f500u = false;
        ((androidx.fragment.app.f) this.f497r.b).c.c(5);
        this.f498s.d(androidx.lifecycle.k.ON_PAUSE);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void onPostCreate(Bundle bundle) {
        super/*android.app.Activity*/.onPostCreate(bundle);
        ((LayoutInflaterFactory2C0004B) i()).w();
    }

    public final void onPostResume() {
        l();
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        layoutInflaterFactory2C0004B.A();
        D.g gVar = layoutInflaterFactory2C0004B.f395o;
        if (gVar != null) {
            gVar.e0(true);
        }
    }

    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        this.f497r.x();
        super.onRequestPermissionsResult(i2, strArr, iArr);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onResume() {
        C.j jVar = this.f497r;
        jVar.x();
        super/*android.app.Activity*/.onResume();
        this.f500u = true;
        ((androidx.fragment.app.f) jVar.b).c.e(true);
    }

    public final void onStart() throws IllegalAccessException {
        m();
        ((LayoutInflaterFactory2C0004B) i()).n(true, false);
    }

    public final void onStateNotSaved() {
        this.f497r.x();
    }

    public final void onStop() {
        n();
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        layoutInflaterFactory2C0004B.A();
        D.g gVar = layoutInflaterFactory2C0004B.f395o;
        if (gVar != null) {
            gVar.e0(false);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void onTitleChanged(CharSequence charSequence, int i2) {
        super/*android.app.Activity*/.onTitleChanged(charSequence, i2);
        i().m(charSequence);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void openOptionsMenu() {
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        layoutInflaterFactory2C0004B.A();
        D.g gVar = layoutInflaterFactory2C0004B.f395o;
        if (getWindow().hasFeature(0)) {
            if (gVar == null || !gVar.R()) {
                super/*android.app.Activity*/.openOptionsMenu();
            }
        }
    }

    public final void setContentView(int i2) {
        h();
        i().j(i2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void setTheme(int i2) {
        super/*android.content.Context*/.setTheme(i2);
        ((LayoutInflaterFactory2C0004B) i()).f377T = i2;
    }

    public void setContentView(View view) {
        h();
        i().k(view);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((androidx.fragment.app.f) this.f497r.b).c.e.onCreateView((View) null, str, context, attributeSet);
        return viewOnCreateView == null ? super/*android.app.Activity*/.onCreateView(str, context, attributeSet) : viewOnCreateView;
    }

    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        h();
        i().l(view, layoutParams);
    }

    public final void onContentChanged() {
    }
}
