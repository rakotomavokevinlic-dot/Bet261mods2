package e;

import android.os.Bundle;
import android.view.View;
import g.C0022c;

/* JADX INFO: renamed from: e.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0003A {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f342a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f343c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f344d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public z f345e;
    public View f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public View f346g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public h.n f347h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public h.j f348i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public C0022c f349j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f350k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f351l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f352m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f353n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f354o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Bundle f355p;
}
