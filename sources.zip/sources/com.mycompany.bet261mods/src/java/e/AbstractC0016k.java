package e;

import android.os.LocaleList;

/* JADX INFO: renamed from: e.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class AbstractC0016k {
    public static LocaleList a(String str) {
        return LocaleList.forLanguageTags(str);
    }
}
