package P;

import android.view.animation.Animation;
import android.view.animation.Transformation;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class g extends Animation {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f156a;
    public final /* synthetic */ SwipeRefreshLayout b;

    public /* synthetic */ g(SwipeRefreshLayout swipeRefreshLayout, int i2) {
        this.f156a = i2;
        this.b = swipeRefreshLayout;
    }

    @Override // android.view.animation.Animation
    public final void applyTransformation(float f, Transformation transformation) {
        switch (this.f156a) {
            case 0:
                this.b.setAnimationProgress(f);
                break;
            case 1:
                this.b.setAnimationProgress(1.0f - f);
                break;
            case 2:
                SwipeRefreshLayout swipeRefreshLayout = this.b;
                int iAbs = swipeRefreshLayout.x - Math.abs(swipeRefreshLayout.w);
                swipeRefreshLayout.setTargetOffsetTopAndBottom((swipeRefreshLayout.v + ((int) ((iAbs - r1) * f))) - swipeRefreshLayout.t.getTop());
                e eVar = swipeRefreshLayout.z;
                float f2 = 1.0f - f;
                d dVar = eVar.f151a;
                if (f2 != dVar.f142p) {
                    dVar.f142p = f2;
                }
                eVar.invalidateSelf();
                break;
            default:
                this.b.k(f);
                break;
        }
    }
}
