package P;

import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final RectF f129a = new RectF();
    public final Paint b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Paint f130c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Paint f131d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f132e;
    public float f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public float f133g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public float f134h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int[] f135i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f136j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public float f137k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public float f138l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public float f139m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f140n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Path f141o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public float f142p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public float f143q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f144r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f145s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f146t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f147u;

    public d() {
        Paint paint = new Paint();
        this.b = paint;
        Paint paint2 = new Paint();
        this.f130c = paint2;
        Paint paint3 = new Paint();
        this.f131d = paint3;
        this.f132e = 0.0f;
        this.f = 0.0f;
        this.f133g = 0.0f;
        this.f134h = 5.0f;
        this.f142p = 1.0f;
        this.f146t = 255;
        paint.setStrokeCap(Paint.Cap.SQUARE);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint2.setStyle(Paint.Style.FILL);
        paint2.setAntiAlias(true);
        paint3.setColor(0);
    }

    public final void a(int i2) {
        this.f136j = i2;
        this.f147u = this.f135i[i2];
    }
}
