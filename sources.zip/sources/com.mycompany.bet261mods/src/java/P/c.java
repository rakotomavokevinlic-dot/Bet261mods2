package P;

import android.animation.Animator;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class c implements Animator.AnimatorListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ d f128a;
    public final /* synthetic */ e b;

    public c(e eVar, d dVar) {
        this.b = eVar;
        this.f128a = dVar;
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationRepeat(Animator animator) {
        e eVar = this.b;
        d dVar = this.f128a;
        eVar.a(1.0f, dVar, true);
        dVar.f137k = dVar.f132e;
        dVar.f138l = dVar.f;
        dVar.f139m = dVar.f133g;
        dVar.a((dVar.f136j + 1) % dVar.f135i.length);
        if (!eVar.f) {
            eVar.f154e += 1.0f;
            return;
        }
        eVar.f = false;
        animator.cancel();
        animator.setDuration(1332L);
        animator.start();
        if (dVar.f140n) {
            dVar.f140n = false;
        }
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        this.b.f154e = 0.0f;
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationCancel(Animator animator) {
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
    }
}
