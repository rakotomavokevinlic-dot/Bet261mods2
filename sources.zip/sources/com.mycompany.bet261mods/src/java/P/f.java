package P;

import android.view.animation.Animation;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.mycompany.bet261mods.MainActivity;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class f implements Animation.AnimationListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f155a;
    public final /* synthetic */ SwipeRefreshLayout b;

    public /* synthetic */ f(SwipeRefreshLayout swipeRefreshLayout, int i2) {
        this.f155a = i2;
        this.b = swipeRefreshLayout;
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationEnd(Animation animation) {
        j jVar;
        switch (this.f155a) {
            case 0:
                SwipeRefreshLayout swipeRefreshLayout = this.b;
                if (!swipeRefreshLayout.c) {
                    swipeRefreshLayout.l();
                } else {
                    swipeRefreshLayout.z.setAlpha(255);
                    swipeRefreshLayout.z.start();
                    if (swipeRefreshLayout.E && (jVar = swipeRefreshLayout.b) != null) {
                        ((MainActivity) ((C.j) jVar).b).f315x.reload();
                    }
                    swipeRefreshLayout.n = swipeRefreshLayout.t.getTop();
                }
                break;
            default:
                SwipeRefreshLayout swipeRefreshLayout2 = this.b;
                swipeRefreshLayout2.getClass();
                g gVar = new g(swipeRefreshLayout2, 1);
                swipeRefreshLayout2.B = gVar;
                gVar.setDuration(150L);
                a aVar = swipeRefreshLayout2.t;
                aVar.f126a = null;
                aVar.clearAnimation();
                swipeRefreshLayout2.t.startAnimation(swipeRefreshLayout2.B);
                break;
        }
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationRepeat(Animation animation) {
        int i2 = this.f155a;
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationStart(Animation animation) {
        int i2 = this.f155a;
    }

    private final void a(Animation animation) {
    }

    private final void b(Animation animation) {
    }

    private final void c(Animation animation) {
    }

    private final void d(Animation animation) {
    }
}
