package P;

import android.animation.ValueAnimator;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class b implements ValueAnimator.AnimatorUpdateListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ d f127a;
    public final /* synthetic */ e b;

    public b(e eVar, d dVar) {
        this.b = eVar;
        this.f127a = dVar;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        e eVar = this.b;
        eVar.getClass();
        d dVar = this.f127a;
        e.d(fFloatValue, dVar);
        eVar.a(fFloatValue, dVar, false);
        eVar.invalidateSelf();
    }
}
