package P;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.view.animation.LinearInterpolator;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class e extends Drawable implements Animatable {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final LinearInterpolator f148g = new LinearInterpolator();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final I.a f149h = new I.a(I.a.f73c);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final int[] f150i = {-16777216};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d f151a;
    public float b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Resources f152c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ValueAnimator f153d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f154e;
    public boolean f;

    public e(Context context) {
        context.getClass();
        this.f152c = context.getResources();
        d dVar = new d();
        this.f151a = dVar;
        dVar.f135i = f150i;
        dVar.a(0);
        dVar.f134h = 2.5f;
        dVar.b.setStrokeWidth(2.5f);
        invalidateSelf();
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        valueAnimatorOfFloat.addUpdateListener(new b(this, dVar));
        valueAnimatorOfFloat.setRepeatCount(-1);
        valueAnimatorOfFloat.setRepeatMode(1);
        valueAnimatorOfFloat.setInterpolator(f148g);
        valueAnimatorOfFloat.addListener(new c(this, dVar));
        this.f153d = valueAnimatorOfFloat;
    }

    public static void d(float f, d dVar) {
        if (f <= 0.75f) {
            dVar.f147u = dVar.f135i[dVar.f136j];
            return;
        }
        float f2 = (f - 0.75f) / 0.25f;
        int[] iArr = dVar.f135i;
        int i2 = dVar.f136j;
        int i3 = iArr[i2];
        int i4 = iArr[(i2 + 1) % iArr.length];
        dVar.f147u = ((((i3 >> 24) & 255) + ((int) ((((i4 >> 24) & 255) - r1) * f2))) << 24) | ((((i3 >> 16) & 255) + ((int) ((((i4 >> 16) & 255) - r3) * f2))) << 16) | ((((i3 >> 8) & 255) + ((int) ((((i4 >> 8) & 255) - r4) * f2))) << 8) | ((i3 & 255) + ((int) (f2 * ((i4 & 255) - r2))));
    }

    public final void a(float f, d dVar, boolean z2) {
        float interpolation;
        float interpolation2;
        if (this.f) {
            d(f, dVar);
            float fFloor = (float) (Math.floor(dVar.f139m / 0.8f) + 1.0d);
            float f2 = dVar.f137k;
            float f3 = dVar.f138l;
            dVar.f132e = (((f3 - 0.01f) - f2) * f) + f2;
            dVar.f = f3;
            float f4 = dVar.f139m;
            dVar.f133g = ((fFloor - f4) * f) + f4;
            return;
        }
        if (f != 1.0f || z2) {
            float f5 = dVar.f139m;
            I.a aVar = f149h;
            if (f < 0.5f) {
                interpolation = dVar.f137k;
                interpolation2 = (aVar.getInterpolation(f / 0.5f) * 0.79f) + 0.01f + interpolation;
            } else {
                float f6 = dVar.f137k + 0.79f;
                interpolation = f6 - (((1.0f - aVar.getInterpolation((f - 0.5f) / 0.5f)) * 0.79f) + 0.01f);
                interpolation2 = f6;
            }
            float f7 = (0.20999998f * f) + f5;
            float f8 = (f + this.f154e) * 216.0f;
            dVar.f132e = interpolation;
            dVar.f = interpolation2;
            dVar.f133g = f7;
            this.b = f8;
        }
    }

    public final void b(float f, float f2, float f3, float f4) {
        float f5 = this.f152c.getDisplayMetrics().density;
        float f6 = f2 * f5;
        d dVar = this.f151a;
        dVar.f134h = f6;
        dVar.b.setStrokeWidth(f6);
        dVar.f143q = f * f5;
        dVar.a(0);
        dVar.f144r = (int) (f3 * f5);
        dVar.f145s = (int) (f4 * f5);
    }

    public final void c(int i2) {
        if (i2 == 0) {
            b(11.0f, 3.0f, 12.0f, 6.0f);
        } else {
            b(7.5f, 2.5f, 10.0f, 5.0f);
        }
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public final void draw(Canvas canvas) {
        Rect bounds = getBounds();
        canvas.save();
        canvas.rotate(this.b, bounds.exactCenterX(), bounds.exactCenterY());
        d dVar = this.f151a;
        RectF rectF = dVar.f129a;
        float f = dVar.f143q;
        float fMin = (dVar.f134h / 2.0f) + f;
        if (f <= 0.0f) {
            fMin = (Math.min(bounds.width(), bounds.height()) / 2.0f) - Math.max((dVar.f144r * dVar.f142p) / 2.0f, dVar.f134h / 2.0f);
        }
        rectF.set(bounds.centerX() - fMin, bounds.centerY() - fMin, bounds.centerX() + fMin, bounds.centerY() + fMin);
        float f2 = dVar.f132e;
        float f3 = dVar.f133g;
        float f4 = (f2 + f3) * 360.0f;
        float f5 = ((dVar.f + f3) * 360.0f) - f4;
        Paint paint = dVar.b;
        paint.setColor(dVar.f147u);
        paint.setAlpha(dVar.f146t);
        float f6 = dVar.f134h / 2.0f;
        rectF.inset(f6, f6);
        canvas.drawCircle(rectF.centerX(), rectF.centerY(), rectF.width() / 2.0f, dVar.f131d);
        float f7 = -f6;
        rectF.inset(f7, f7);
        canvas.drawArc(rectF, f4, f5, false, paint);
        if (dVar.f140n) {
            Path path = dVar.f141o;
            if (path == null) {
                Path path2 = new Path();
                dVar.f141o = path2;
                path2.setFillType(Path.FillType.EVEN_ODD);
            } else {
                path.reset();
            }
            float fMin2 = Math.min(rectF.width(), rectF.height()) / 2.0f;
            float f8 = (dVar.f144r * dVar.f142p) / 2.0f;
            dVar.f141o.moveTo(0.0f, 0.0f);
            dVar.f141o.lineTo(dVar.f144r * dVar.f142p, 0.0f);
            Path path3 = dVar.f141o;
            float f9 = dVar.f144r;
            float f10 = dVar.f142p;
            path3.lineTo((f9 * f10) / 2.0f, dVar.f145s * f10);
            dVar.f141o.offset((rectF.centerX() + fMin2) - f8, (dVar.f134h / 2.0f) + rectF.centerY());
            dVar.f141o.close();
            Paint paint2 = dVar.f130c;
            paint2.setColor(dVar.f147u);
            paint2.setAlpha(dVar.f146t);
            canvas.save();
            canvas.rotate(f4 + f5, rectF.centerX(), rectF.centerY());
            canvas.drawPath(dVar.f141o, paint2);
            canvas.restore();
        }
        canvas.restore();
    }

    @Override // android.graphics.drawable.Drawable
    public final int getAlpha() {
        return this.f151a.f146t;
    }

    @Override // android.graphics.drawable.Drawable
    public final int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Animatable
    public final boolean isRunning() {
        return this.f153d.isRunning();
    }

    @Override // android.graphics.drawable.Drawable
    public final void setAlpha(int i2) {
        this.f151a.f146t = i2;
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public final void setColorFilter(ColorFilter colorFilter) {
        this.f151a.b.setColorFilter(colorFilter);
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Animatable
    public final void start() {
        this.f153d.cancel();
        d dVar = this.f151a;
        float f = dVar.f132e;
        dVar.f137k = f;
        float f2 = dVar.f;
        dVar.f138l = f2;
        dVar.f139m = dVar.f133g;
        if (f2 != f) {
            this.f = true;
            this.f153d.setDuration(666L);
            this.f153d.start();
            return;
        }
        dVar.a(0);
        dVar.f137k = 0.0f;
        dVar.f138l = 0.0f;
        dVar.f139m = 0.0f;
        dVar.f132e = 0.0f;
        dVar.f = 0.0f;
        dVar.f133g = 0.0f;
        this.f153d.setDuration(1332L);
        this.f153d.start();
    }

    @Override // android.graphics.drawable.Animatable
    public final void stop() {
        this.f153d.cancel();
        this.b = 0.0f;
        d dVar = this.f151a;
        if (dVar.f140n) {
            dVar.f140n = false;
        }
        dVar.a(0);
        dVar.f137k = 0.0f;
        dVar.f138l = 0.0f;
        dVar.f139m = 0.0f;
        dVar.f132e = 0.0f;
        dVar.f = 0.0f;
        dVar.f133g = 0.0f;
        invalidateSelf();
    }
}
