package T;

import android.os.Process;
import java.util.concurrent.PriorityBlockingQueue;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class d extends Thread {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final boolean f177g = s.f210a;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final PriorityBlockingQueue f178a;
    public final PriorityBlockingQueue b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final U.e f179c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final C.j f180d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public volatile boolean f181e = false;
    public final t f;

    public d(PriorityBlockingQueue priorityBlockingQueue, PriorityBlockingQueue priorityBlockingQueue2, U.e eVar, C.j jVar) {
        this.f178a = priorityBlockingQueue;
        this.b = priorityBlockingQueue2;
        this.f179c = eVar;
        this.f180d = jVar;
        this.f = new t(this, priorityBlockingQueue2, jVar);
    }

    private void a() {
        U.h hVar = (U.h) this.f178a.take();
        hVar.a("cache-queue-take");
        hVar.j();
        try {
            synchronized (hVar.f233e) {
            }
            b bVarA = this.f179c.a(hVar.d());
            if (bVarA == null) {
                hVar.a("cache-miss");
                if (!this.f.e(hVar)) {
                    this.b.put(hVar);
                }
                return;
            }
            long jCurrentTimeMillis = System.currentTimeMillis();
            if (bVarA.f172e < jCurrentTimeMillis) {
                hVar.a("cache-hit-expired");
                hVar.f239l = bVarA;
                if (!this.f.e(hVar)) {
                    this.b.put(hVar);
                }
                return;
            }
            hVar.a("cache-hit");
            k kVarI = U.h.i(new k(bVarA.f169a, bVarA.f173g));
            hVar.a("cache-hit-parsed");
            if (((p) kVarI.f194d) == null) {
                if (bVarA.f < jCurrentTimeMillis) {
                    hVar.a("cache-hit-refresh-needed");
                    hVar.f239l = bVarA;
                    kVarI.f192a = true;
                    if (this.f.e(hVar)) {
                        this.f180d.y(hVar, kVarI, null);
                    } else {
                        this.f180d.y(hVar, kVarI, new c(this, hVar));
                    }
                } else {
                    this.f180d.y(hVar, kVarI, null);
                }
                return;
            }
            hVar.a("cache-parsing-failed");
            U.e eVar = this.f179c;
            String strD = hVar.d();
            synchronized (eVar) {
                b bVarA2 = eVar.a(strD);
                if (bVarA2 != null) {
                    bVarA2.f = 0L;
                    bVarA2.f172e = 0L;
                    eVar.f(strD, bVarA2);
                }
            }
            hVar.f239l = null;
            if (!this.f.e(hVar)) {
                this.b.put(hVar);
            }
        } finally {
            hVar.j();
        }
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        if (f177g) {
            s.d("start new dispatcher", new Object[0]);
        }
        Process.setThreadPriority(10);
        this.f179c.d();
        while (true) {
            try {
                a();
            } catch (InterruptedException unused) {
                if (this.f181e) {
                    Thread.currentThread().interrupt();
                    return;
                }
                s.c("Ignoring spurious interrupt of CacheDispatcher thread; use quit() to terminate it", new Object[0]);
            }
        }
    }
}
