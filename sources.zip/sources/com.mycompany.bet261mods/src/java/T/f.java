package T;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f182a;
    public int b;
}
