package T;

import android.os.Handler;
import android.util.Log;
import v.C0132d;
import v.CallableC0131c;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class h implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f184a = 2;
    public Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f185c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f186d;

    public /* synthetic */ h() {
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object objCall;
        F.d dVar;
        o oVar;
        switch (this.f184a) {
            case 0:
                synchronized (((U.h) this.b).f233e) {
                    break;
                }
                k kVar = (k) this.f185c;
                p pVar = (p) kVar.f194d;
                if (pVar != null) {
                    U.h hVar = (U.h) this.b;
                    synchronized (hVar.f233e) {
                        dVar = hVar.f;
                        break;
                    }
                    if (dVar != null) {
                        switch (dVar.f56a) {
                            case 9:
                                Log.d("Error Get JSON", "Error:" + pVar.toString());
                                break;
                            case 10:
                            default:
                                Log.d("Error Get JSON", "Error:" + pVar.toString());
                                break;
                            case 11:
                                Log.d("Error click", "Error:" + pVar.toString());
                                break;
                            case 12:
                                Log.d("Error Get JSON", "Error:" + pVar.toString());
                                break;
                        }
                    }
                } else {
                    U.h hVar2 = (U.h) this.b;
                    String str = (String) kVar.b;
                    hVar2.getClass();
                    synchronized (hVar2.f241n) {
                        oVar = hVar2.f242o;
                        break;
                    }
                    if (oVar != null) {
                        oVar.u(str);
                    }
                }
                if (((k) this.f185c).f192a) {
                    ((U.h) this.b).a("intermediate-response");
                } else {
                    ((U.h) this.b).b("done");
                }
                c cVar = (c) this.f186d;
                if (cVar != null) {
                    cVar.run();
                    return;
                }
                return;
            case 1:
                W.g gVar = (W.g) this.f186d;
                if (gVar.f268e) {
                    gVar.f266c = gVar.f;
                    gVar.f268e = false;
                } else {
                    gVar.f281s = Boolean.FALSE;
                    if (!gVar.f271i.equals("false")) {
                        D.g.I(gVar.b).a(new U.h(0, (String) this.b, new C.j(8, this), new F.d(12)));
                    }
                }
                gVar.f267d.postDelayed(this, gVar.f266c);
                if (gVar.f266c == gVar.f) {
                    gVar.f266c = gVar.f269g;
                    return;
                }
                return;
            default:
                try {
                    objCall = ((CallableC0131c) this.b).call();
                    break;
                } catch (Exception unused) {
                    objCall = null;
                }
                ((Handler) this.f186d).post(new c((C0132d) this.f185c, 5, objCall));
                return;
        }
    }

    public h(U.h hVar, k kVar, c cVar) {
        this.b = hVar;
        this.f185c = kVar;
        this.f186d = cVar;
    }

    public h(W.g gVar, String str) {
        this.f186d = gVar;
        this.b = str;
    }
}
