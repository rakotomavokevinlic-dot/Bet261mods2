package T;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class m implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f195a;
    public final /* synthetic */ long b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ U.h f196c;

    public m(U.h hVar, String str, long j2) {
        this.f196c = hVar;
        this.f195a = str;
        this.b = j2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        U.h hVar = this.f196c;
        hVar.f230a.a(this.f195a, this.b);
        hVar.f230a.b(hVar.toString());
    }
}
