package T;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f206a;
    public final long b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f207c;

    public q(String str, long j2, long j3) {
        this.f206a = str;
        this.b = j2;
        this.f207c = j3;
    }
}
