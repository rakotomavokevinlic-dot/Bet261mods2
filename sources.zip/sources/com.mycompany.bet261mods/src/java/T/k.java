package T;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f192a;
    public final Serializable b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f193c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f194d;

    public k(String str, b bVar) {
        this.f192a = false;
        this.b = str;
        this.f193c = bVar;
        this.f194d = null;
    }

    public k(p pVar) {
        this.f192a = false;
        this.b = null;
        this.f193c = null;
        this.f194d = pVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public k(byte[] bArr, Map map, List list, boolean z2) {
        this.b = bArr;
        this.f193c = map;
        if (list == null) {
            this.f194d = null;
        } else {
            this.f194d = Collections.unmodifiableList(list);
        }
        this.f192a = z2;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.util.TreeMap] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.util.Map] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.util.Map] */
    /* JADX WARN: Type inference failed for: r0v4 */
    public k(byte[] bArr, boolean z2, List list) {
        ?? treeMap;
        if (list == null) {
            treeMap = 0;
        } else if (list.isEmpty()) {
            treeMap = Collections.EMPTY_MAP;
        } else {
            treeMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
            Iterator it = list.iterator();
            while (it.hasNext()) {
                i iVar = (i) it.next();
                treeMap.put(iVar.f187a, iVar.b);
            }
        }
        this(bArr, treeMap, list, z2);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r0v4 */
    public k(byte[] bArr, Map map) {
        ?? arrayList;
        if (map == null) {
            arrayList = 0;
        } else if (map.isEmpty()) {
            arrayList = Collections.EMPTY_LIST;
        } else {
            arrayList = new ArrayList(map.size());
            for (Map.Entry entry : map.entrySet()) {
                arrayList.add(new i((String) entry.getKey(), (String) entry.getValue()));
            }
        }
        this(bArr, map, arrayList, false);
    }
}
