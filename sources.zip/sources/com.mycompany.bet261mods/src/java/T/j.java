package T;

import android.net.TrafficStats;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;
import java.util.concurrent.PriorityBlockingQueue;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class j extends Thread {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final PriorityBlockingQueue f188a;
    public final G.a b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final U.e f189c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final C.j f190d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public volatile boolean f191e = false;

    public j(PriorityBlockingQueue priorityBlockingQueue, G.a aVar, U.e eVar, C.j jVar) {
        this.f188a = priorityBlockingQueue;
        this.b = aVar;
        this.f189c = eVar;
        this.f190d = jVar;
    }

    private void a() {
        b bVar;
        U.h hVar = (U.h) this.f188a.take();
        C.j jVar = this.f190d;
        SystemClock.elapsedRealtime();
        hVar.j();
        try {
            try {
                try {
                    hVar.a("network-queue-take");
                    synchronized (hVar.f233e) {
                    }
                    TrafficStats.setThreadStatsTag(hVar.f232d);
                    k kVarF = this.b.f(hVar);
                    hVar.a("network-http-complete");
                    if (kVarF.f192a && hVar.f()) {
                        hVar.b("not-modified");
                        hVar.g();
                        return;
                    }
                    k kVarI = U.h.i(kVarF);
                    hVar.a("network-parse-complete");
                    if (hVar.f236i && (bVar = (b) kVarI.f193c) != null) {
                        this.f189c.f(hVar.d(), bVar);
                        hVar.a("network-cache-written");
                    }
                    synchronized (hVar.f233e) {
                        hVar.f237j = true;
                    }
                    jVar.y(hVar, kVarI, null);
                    hVar.h(kVarI);
                } catch (p e2) {
                    SystemClock.elapsedRealtime();
                    jVar.getClass();
                    hVar.a("post-error");
                    ((g) jVar.b).execute(new h(hVar, new k(e2), null));
                    hVar.g();
                }
            } catch (Exception e3) {
                Log.e("Volley", s.a("Unhandled exception %s", e3.toString()), e3);
                p pVar = new p(e3);
                SystemClock.elapsedRealtime();
                jVar.getClass();
                hVar.a("post-error");
                ((g) jVar.b).execute(new h(hVar, new k(pVar), null));
                hVar.g();
            }
        } finally {
            hVar.j();
        }
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        Process.setThreadPriority(10);
        while (true) {
            try {
                a();
            } catch (InterruptedException unused) {
                if (this.f191e) {
                    Thread.currentThread().interrupt();
                    return;
                }
                s.c("Ignoring spurious interrupt of NetworkDispatcher thread; use quit() to terminate it", new Object[0]);
            }
        }
    }
}
