package T;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public byte[] f169a;
    public String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f170c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f171d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f172e;
    public long f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Map f173g = Collections.EMPTY_MAP;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public List f174h;
}
