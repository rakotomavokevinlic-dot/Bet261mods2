package T;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AtomicInteger f197a;
    public final HashSet b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final PriorityBlockingQueue f198c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final PriorityBlockingQueue f199d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final U.e f200e;
    public final G.a f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final C.j f201g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final j[] f202h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public d f203i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final ArrayList f204j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final ArrayList f205k;

    public n(U.e eVar, G.a aVar) {
        C.j jVar = new C.j(new Handler(Looper.getMainLooper()));
        this.f197a = new AtomicInteger();
        this.b = new HashSet();
        this.f198c = new PriorityBlockingQueue();
        this.f199d = new PriorityBlockingQueue();
        this.f204j = new ArrayList();
        this.f205k = new ArrayList();
        this.f200e = eVar;
        this.f = aVar;
        this.f202h = new j[4];
        this.f201g = jVar;
    }

    public final void a(U.h hVar) {
        hVar.f235h = this;
        synchronized (this.b) {
            this.b.add(hVar);
        }
        hVar.f234g = Integer.valueOf(this.f197a.incrementAndGet());
        hVar.a("add-to-queue");
        b();
        if (hVar.f236i) {
            this.f198c.add(hVar);
        } else {
            this.f199d.add(hVar);
        }
    }

    public final void b() {
        synchronized (this.f205k) {
            try {
                Iterator it = this.f205k.iterator();
                if (it.hasNext()) {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                    throw null;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
