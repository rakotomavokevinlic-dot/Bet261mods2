package T;

import android.app.Application;
import android.graphics.Typeface;
import android.util.Log;
import i.U;
import java.lang.reflect.Method;
import v.C0132d;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class c implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f175a;
    public final /* synthetic */ Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f176c;

    public /* synthetic */ c(Object obj, int i2, Object obj2) {
        this.f175a = i2;
        this.b = obj;
        this.f176c = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f175a) {
            case 0:
                try {
                    ((d) this.f176c).b.put((U.h) this.b);
                    return;
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                    return;
                }
            case 1:
                ((o.c) this.b).f1069a = this.f176c;
                return;
            case 2:
                ((Application) this.b).unregisterActivityLifecycleCallbacks((o.c) this.f176c);
                return;
            case 3:
                try {
                    Method method = o.d.f1075d;
                    Object obj = this.f176c;
                    Object obj2 = this.b;
                    if (method != null) {
                        method.invoke(obj2, obj, Boolean.FALSE, "AppCompat recreation");
                    } else {
                        o.d.f1076e.invoke(obj2, obj, Boolean.FALSE);
                    }
                    return;
                } catch (RuntimeException e2) {
                    if (e2.getClass() == RuntimeException.class && e2.getMessage() != null && e2.getMessage().startsWith("Unable to stop")) {
                        throw e2;
                    }
                    return;
                } catch (Throwable th) {
                    Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th);
                    return;
                }
            case 4:
                U u2 = (U) ((C.j) this.b).b;
                if (u2 != null) {
                    u2.b((Typeface) this.f176c);
                    return;
                }
                return;
            default:
                ((C0132d) this.b).a(this.f176c);
                return;
        }
    }

    public c(d dVar, U.h hVar) {
        this.f175a = 0;
        this.f176c = dVar;
        this.b = hVar;
    }
}
