package T;

import android.content.Context;
import android.graphics.Typeface;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import androidx.emoji2.text.w;
import g.AbstractC0020a;
import g.C0024e;
import h.C;
import h.u;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.PriorityBlockingQueue;
import l.C0103k;
import t.InterfaceMenuItemC0123a;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f211a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f212c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f213d;

    public t() {
        this.b = new ArrayList();
        this.f211a = new HashMap();
        this.f212c = new HashMap();
    }

    public void a() {
        Iterator it = ((HashMap) this.f211a).values().iterator();
        while (it.hasNext()) {
            L.d.a(it.next());
        }
    }

    public C0024e b(AbstractC0020a abstractC0020a) {
        ArrayList arrayList = (ArrayList) this.f212c;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0024e c0024e = (C0024e) arrayList.get(i2);
            if (c0024e != null && c0024e.b == abstractC0020a) {
                return c0024e;
            }
        }
        C0024e c0024e2 = new C0024e((Context) this.b, abstractC0020a);
        arrayList.add(c0024e2);
        return c0024e2;
    }

    public ArrayList c() {
        ArrayList arrayList = new ArrayList();
        Iterator it = ((HashMap) this.f211a).values().iterator();
        while (it.hasNext()) {
            L.d.a(it.next());
        }
        return arrayList;
    }

    public List d() {
        ArrayList arrayList;
        if (((ArrayList) this.b).isEmpty()) {
            return Collections.EMPTY_LIST;
        }
        synchronized (((ArrayList) this.b)) {
            arrayList = new ArrayList((ArrayList) this.b);
        }
        return arrayList;
    }

    public synchronized boolean e(U.h hVar) {
        try {
            String strD = hVar.d();
            if (!((HashMap) this.f211a).containsKey(strD)) {
                ((HashMap) this.f211a).put(strD, null);
                synchronized (hVar.f233e) {
                    hVar.f240m = this;
                }
                if (s.f210a) {
                    s.b("new request, sending to network %s", strD);
                }
                return false;
            }
            List arrayList = (List) ((HashMap) this.f211a).get(strD);
            if (arrayList == null) {
                arrayList = new ArrayList();
            }
            hVar.a("waiting-for-response");
            arrayList.add(hVar);
            ((HashMap) this.f211a).put(strD, arrayList);
            if (s.f210a) {
                s.b("Request for cacheKey=%s is in flight, putting on hold.", strD);
            }
            return true;
        } catch (Throwable th) {
            throw th;
        }
    }

    public boolean f(AbstractC0020a abstractC0020a, MenuItem menuItem) {
        return ((ActionMode.Callback) this.f211a).onActionItemClicked(b(abstractC0020a), new u((Context) this.b, (InterfaceMenuItemC0123a) menuItem));
    }

    public boolean g(AbstractC0020a abstractC0020a, h.n nVar) {
        C0024e c0024eB = b(abstractC0020a);
        C0103k c0103k = (C0103k) this.f213d;
        Menu c2 = (Menu) c0103k.getOrDefault(nVar, null);
        if (c2 == null) {
            c2 = new C((Context) this.b, nVar);
            c0103k.put(nVar, c2);
        }
        return ((ActionMode.Callback) this.f211a).onCreateActionMode(c0024eB, c2);
    }

    public synchronized void h(U.h hVar) {
        PriorityBlockingQueue priorityBlockingQueue;
        try {
            String strD = hVar.d();
            List list = (List) ((HashMap) this.f211a).remove(strD);
            if (list != null && !list.isEmpty()) {
                if (s.f210a) {
                    s.d("%d waiting requests for cacheKey=%s; resend to network", Integer.valueOf(list.size()), strD);
                }
                U.h hVar2 = (U.h) list.remove(0);
                ((HashMap) this.f211a).put(strD, list);
                synchronized (hVar2.f233e) {
                    hVar2.f240m = this;
                }
                if (((d) this.f212c) != null && (priorityBlockingQueue = (PriorityBlockingQueue) this.f213d) != null) {
                    try {
                        priorityBlockingQueue.put(hVar2);
                    } catch (InterruptedException e2) {
                        s.c("Couldn't add request to queue. %s", e2.toString());
                        Thread.currentThread().interrupt();
                        d dVar = (d) this.f212c;
                        dVar.f181e = true;
                        dVar.interrupt();
                    }
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public t(d dVar, PriorityBlockingQueue priorityBlockingQueue, C.j jVar) {
        this.f211a = new HashMap();
        this.b = jVar;
        this.f212c = dVar;
        this.f213d = priorityBlockingQueue;
    }

    public t(Typeface typeface, F.b bVar) {
        int i2;
        int i3;
        int i4;
        int i5;
        this.f213d = typeface;
        this.f211a = bVar;
        this.f212c = new androidx.emoji2.text.t(1024);
        int iA = bVar.a(6);
        if (iA != 0) {
            int i6 = iA + bVar.f53a;
            i2 = ((ByteBuffer) bVar.f55d).getInt(((ByteBuffer) bVar.f55d).getInt(i6) + i6);
        } else {
            i2 = 0;
        }
        this.b = new char[i2 * 2];
        int iA2 = bVar.a(6);
        if (iA2 != 0) {
            int i7 = iA2 + bVar.f53a;
            i3 = ((ByteBuffer) bVar.f55d).getInt(((ByteBuffer) bVar.f55d).getInt(i7) + i7);
        } else {
            i3 = 0;
        }
        for (int i8 = 0; i8 < i3; i8++) {
            w wVar = new w(this, i8);
            F.a aVarB = wVar.b();
            int iA3 = aVarB.a(4);
            Character.toChars(iA3 != 0 ? ((ByteBuffer) aVarB.f55d).getInt(iA3 + aVarB.f53a) : 0, (char[]) this.b, i8 * 2);
            F.a aVarB2 = wVar.b();
            int iA4 = aVarB2.a(16);
            if (iA4 != 0) {
                int i9 = iA4 + aVarB2.f53a;
                i4 = ((ByteBuffer) aVarB2.f55d).getInt(((ByteBuffer) aVarB2.f55d).getInt(i9) + i9);
            } else {
                i4 = 0;
            }
            if (i4 > 0) {
                F.a aVarB3 = wVar.b();
                int iA5 = aVarB3.a(16);
                if (iA5 != 0) {
                    int i10 = iA5 + aVarB3.f53a;
                    i5 = ((ByteBuffer) aVarB3.f55d).getInt(((ByteBuffer) aVarB3.f55d).getInt(i10) + i10);
                } else {
                    i5 = 0;
                }
                ((androidx.emoji2.text.t) this.f212c).a(wVar, 0, i5 - 1);
            } else {
                throw new IllegalArgumentException("invalid metadata codepoint length");
            }
        }
    }

    public t(Context context, ActionMode.Callback callback) {
        this.b = context;
        this.f211a = callback;
        this.f212c = new ArrayList();
        this.f213d = new C0103k();
    }
}
