package com.mycompany.bet261mods;

import D.b;
import F.d;
import M.a;
import M.e;
import U.h;
import V.f;
import V.i;
import V.j;
import W.g;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.l;
import androidx.appcompat.widget.Toolbar;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import e.AbstractC0014i;
import e.C0013h;
import e.I;
import e.LayoutInflaterFactory2C0004B;
import e.N;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.WeakHashMap;
import y.AbstractC0142A;
import y.K;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public class MainActivity extends AbstractC0014i {

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public static boolean f305J;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public SharedPreferences f306A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public boolean f307B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f308C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public SwipeRefreshLayout f309D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public SwipeRefreshLayout f310E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public g f311F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public GeolocationPermissions.Callback f312G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public String f313H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public PermissionRequest f314I;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public WebView f315x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public ValueCallback f316y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public String f317z;

    public MainActivity() {
        ((e) ((l) this).e.f120c).e("androidx:appcompat", new a(this));
        f(new C0013h(this));
        this.f306A = null;
        this.f307B = false;
        this.f308C = false;
        this.f312G = null;
        this.f313H = null;
    }

    public static File o(MainActivity mainActivity) {
        return File.createTempFile("JPEG_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + "_", ".jpg", Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static String p(MainActivity mainActivity) {
        WindowManager windowManager = (WindowManager) mainActivity.getSystemService("window");
        Point point = new Point();
        windowManager.getDefaultDisplay().getRealSize(point);
        return point.x + "x" + point.y;
    }

    public static boolean q(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isAvailable() && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x002b  */
    @Override // e.AbstractC0014i
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onActivityResult(int r3, int r4, android.content.Intent r5) {
        /*
            r2 = this;
            r0 = 1
            if (r3 != r0) goto L34
            android.webkit.ValueCallback r1 = r2.f316y
            if (r1 != 0) goto L8
            goto L34
        L8:
            r3 = -1
            r1 = 0
            if (r4 != r3) goto L2b
            r3 = 0
            if (r5 != 0) goto L1c
            java.lang.String r4 = r2.f317z
            if (r4 == 0) goto L2b
            android.net.Uri[] r5 = new android.net.Uri[r0]
            android.net.Uri r4 = android.net.Uri.parse(r4)
            r5[r3] = r4
            goto L2c
        L1c:
            java.lang.String r4 = r5.getDataString()
            if (r4 == 0) goto L2b
            android.net.Uri[] r5 = new android.net.Uri[r0]
            android.net.Uri r4 = android.net.Uri.parse(r4)
            r5[r3] = r4
            goto L2c
        L2b:
            r5 = r1
        L2c:
            android.webkit.ValueCallback r3 = r2.f316y
            r3.onReceiveValue(r5)
            r2.f316y = r1
            return
        L34:
            super.onActivityResult(r3, r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.mycompany.bet261mods.MainActivity.onActivityResult(int, int, android.content.Intent):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // e.AbstractC0014i
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(2131427356);
        setRequestedOrientation(-1);
        g gVar = new g();
        gVar.f267d = new Handler();
        gVar.f268e = true;
        gVar.f270h = "https://webintoapp.com/ads/";
        gVar.f271i = "true";
        gVar.f272j = "true";
        gVar.f273k = "banner ";
        gVar.f274l = "";
        gVar.f275m = "true";
        gVar.f276n = "";
        gVar.f277o = "";
        gVar.f278p = "";
        gVar.f279q = "live";
        gVar.f280r = "";
        gVar.f281s = Boolean.FALSE;
        gVar.f = 3000;
        gVar.f269g = 60000;
        gVar.b = this;
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if (defaultSharedPreferences.getString("installkey", null) == null) {
            Random random = new Random();
            StringBuilder sb = new StringBuilder(32);
            for (int i2 = 0; i2 < 32; i2++) {
                sb.append("0123456789qwertyuiopasdfghjklzxcvbnm".charAt(random.nextInt(36)));
            }
            defaultSharedPreferences.edit().putString("installkey", sb.toString()).apply();
        }
        String string = defaultSharedPreferences.getString("installkey", null);
        gVar.f277o = string;
        gVar.f276n = "1211158";
        gVar.f270h = "https://ads.webintoapp.com/ads/";
        D.g.I(gVar.b).a(new h(0, "https://ads.webintoapp.com/ads/ads-start.json?ai=1211158&ik=" + string, new W.e(gVar), new d(9)));
        this.f311F = gVar;
        WebView webView = (WebView) findViewById(2131230781);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("file:///android_asset/htmlapp/helpers/loading.html");
        Toolbar toolbarFindViewById = findViewById(2131230837);
        LayoutInflaterFactory2C0004B layoutInflaterFactory2C0004B = (LayoutInflaterFactory2C0004B) i();
        if (layoutInflaterFactory2C0004B.f390j instanceof Activity) {
            layoutInflaterFactory2C0004B.A();
            D.g gVar2 = layoutInflaterFactory2C0004B.f395o;
            if (gVar2 instanceof N) {
                throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
            }
            layoutInflaterFactory2C0004B.f396p = null;
            if (gVar2 != null) {
                gVar2.L();
            }
            layoutInflaterFactory2C0004B.f395o = null;
            if (toolbarFindViewById != null) {
                Object obj = layoutInflaterFactory2C0004B.f390j;
                I i3 = new I(toolbarFindViewById, obj instanceof Activity ? ((Activity) obj).getTitle() : layoutInflaterFactory2C0004B.f397q, layoutInflaterFactory2C0004B.f393m);
                layoutInflaterFactory2C0004B.f395o = i3;
                layoutInflaterFactory2C0004B.f393m.b = i3.f419q;
                toolbarFindViewById.setBackInvokedCallbackEnabled(true);
            } else {
                layoutInflaterFactory2C0004B.f393m.b = null;
            }
            layoutInflaterFactory2C0004B.b();
        }
        if (Build.VERSION.SDK_INT >= 35) {
            getWindow().getDecorView().setOnApplyWindowInsetsListener(new f());
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController insetsController = getWindow().getInsetsController();
            if (insetsController != null) {
                insetsController.setSystemBarsAppearance(0, 8);
            }
        }
        this.f306A = getSharedPreferences("com.mycompany.bet261mods", 0);
        this.f315x = (WebView) findViewById(2131230780);
        View viewFindViewById = findViewById(2131230804);
        V.g gVar3 = new V.g();
        WeakHashMap weakHashMap = K.f1165a;
        AbstractC0142A.u(viewFindViewById, gVar3);
        this.f315x.setWebChromeClient(new V.h(this));
        this.f309D = findViewById(2131230880);
        this.f310E = findViewById(2131230880);
        this.f315x.getSettings().setDomStorageEnabled(true);
        this.f315x.setDownloadListener(new i(this));
        this.f315x.setWebViewClient(new j(this));
        WebView webView2 = this.f315x;
        WebSettings settings = webView2.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setAllowFileAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setSupportZoom(true);
        settings.setDatabaseEnabled(true);
        settings.setUserAgentString(System.getProperty("http.agent"));
        V.d dVar = new V.d();
        dVar.f248a = this;
        webView2.addJavascriptInterface(dVar, "Android");
        if (!q(this)) {
            this.f315x.loadUrl("file:///android_asset/htmlapp/helpers/error.html");
            this.f308C = true;
            return;
        }
        Intent intent = getIntent();
        if (intent.getData() != null) {
            String dataString = intent.getDataString();
            if (dataString.startsWith("https://betting.tendry.mg")) {
                this.f315x.loadUrl(dataString);
            } else {
                this.f315x.loadUrl("https://betting.tendry.mg");
            }
        } else {
            this.f315x.loadUrl("https://betting.tendry.mg");
        }
        this.f309D.setOnRefreshListener(new C.j(6, this));
    }

    public final boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(2131492864, menu);
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [android.app.Activity, com.mycompany.bet261mods.MainActivity, java.lang.Object] */
    @Override // e.AbstractC0014i
    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 0 || i2 != 4) {
            return super.onKeyDown(i2, keyEvent);
        }
        if (this.f308C) {
            finish();
        }
        if (this.f315x.canGoBack()) {
            this.f315x.goBack();
            return true;
        }
        g gVar = this.f311F;
        boolean zEquals = gVar.f272j.equals("false");
        ?? r0 = gVar.b;
        if (zEquals) {
            r0.finish();
        }
        String str = (gVar.f270h + "ads-exit.json") + "?ai=" + gVar.f276n + "&ik=" + gVar.f277o + "&si=" + gVar.f278p;
        C.j jVar = new C.j(9);
        jVar.b = new W.e(gVar);
        D.g.I(r0).a(new h(0, str, new G.a(jVar, r0, false), new d(13)));
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super/*android.app.Activity*/.onOptionsItemSelected(menuItem);
        }
        this.f315x.loadUrl("https://betting.tendry.mg");
        return true;
    }

    @Override // e.AbstractC0014i
    public final void onPause() {
        super.onPause();
        g gVar = this.f311F;
        gVar.f267d.removeCallbacks(gVar.f265a);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // e.AbstractC0014i
    public final void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i2, strArr, iArr);
        if (iArr.length <= 0 || iArr[0] != 0) {
            return;
        }
        if (i2 == 100) {
            GeolocationPermissions.Callback callback = this.f312G;
            if (callback != null) {
                callback.invoke(this.f313H, true, true);
            }
        } else if (i2 == 1001) {
            if (o.e.a(this, "android.permission.RECORD_AUDIO") == 0) {
                PermissionRequest permissionRequest = this.f314I;
                permissionRequest.grant(permissionRequest.getResources());
            } else {
                o.e.g(this, new String[]{"android.permission.RECORD_AUDIO"}, 106);
            }
        } else if (i2 == 1002) {
            PermissionRequest permissionRequest2 = this.f314I;
            permissionRequest2.grant(permissionRequest2.getResources());
        }
        this.f315x.reload();
    }

    @Override // e.AbstractC0014i
    public final void onResume() {
        super.onResume();
        if (this.f306A.getBoolean("firstrun", true)) {
            new Thread(new b(2, this)).start();
            g gVar = this.f311F;
            gVar.f267d.removeCallbacks(gVar.f265a);
        }
    }
}
