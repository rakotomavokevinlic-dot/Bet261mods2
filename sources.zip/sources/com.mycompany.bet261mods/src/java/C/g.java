package C;

import android.content.ClipDescription;
import android.net.Uri;
import android.view.inputmethod.InputContentInfo;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class g implements i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final InputContentInfo f4a;

    public g(Object obj) {
        this.f4a = (InputContentInfo) obj;
    }

    @Override // C.i
    public final ClipDescription a() {
        return this.f4a.getDescription();
    }

    @Override // C.i
    public final void b() {
        this.f4a.requestPermission();
    }

    @Override // C.i
    public final Uri c() {
        return this.f4a.getLinkUri();
    }

    @Override // C.i
    public final Object d() {
        return this.f4a;
    }

    @Override // C.i
    public final Uri e() {
        return this.f4a.getContentUri();
    }

    public g(Uri uri, ClipDescription clipDescription, Uri uri2) {
        this.f4a = new InputContentInfo(uri, clipDescription, uri2);
    }
}
