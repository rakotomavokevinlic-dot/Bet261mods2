package C;

import android.content.ClipDescription;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.Selection;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.KeyEvent;
import androidx.emoji2.text.q;
import androidx.emoji2.text.t;
import androidx.emoji2.text.w;
import androidx.emoji2.text.x;
import androidx.fragment.app.l;
import androidx.fragment.app.p;
import androidx.lifecycle.E;
import androidx.lifecycle.F;
import androidx.lifecycle.G;
import e.K;
import i.C0080v;
import i.U;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import l.C0098f;
import org.xmlpull.v1.XmlPullParserException;
import q.m;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class h implements i {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static h f5d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f6a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f7c;

    public h(G g2, F.d dVar) {
        e0.c.e(g2, "store");
        J.a aVar = J.a.b;
        e0.c.e(aVar, "defaultCreationExtras");
        this.f6a = g2;
        this.b = dVar;
        this.f7c = aVar;
    }

    public static boolean f(Editable editable, KeyEvent keyEvent, boolean z2) {
        x[] xVarArr;
        if (KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState())) {
            int selectionStart = Selection.getSelectionStart(editable);
            int selectionEnd = Selection.getSelectionEnd(editable);
            if (selectionStart != -1 && selectionEnd != -1 && selectionStart == selectionEnd && (xVarArr = (x[]) editable.getSpans(selectionStart, selectionEnd, x.class)) != null && xVarArr.length > 0) {
                for (x xVar : xVarArr) {
                    int spanStart = editable.getSpanStart(xVar);
                    int spanEnd = editable.getSpanEnd(xVar);
                    if ((z2 && spanStart == selectionStart) || ((!z2 && spanEnd == selectionStart) || (selectionStart > spanStart && selectionStart < spanEnd))) {
                        editable.delete(spanStart, spanEnd);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static h m(Context context, AttributeSet attributeSet, int[] iArr, int i2) {
        return new h(context, context.obtainStyledAttributes(attributeSet, iArr, i2, 0));
    }

    @Override // C.i
    public ClipDescription a() {
        return (ClipDescription) this.f7c;
    }

    @Override // C.i
    public Uri c() {
        return (Uri) this.b;
    }

    @Override // C.i
    public Object d() {
        return null;
    }

    @Override // C.i
    public Uri e() {
        return (Uri) this.f6a;
    }

    public E g(Class cls) {
        E eC;
        String canonicalName = cls.getCanonicalName();
        if (canonicalName == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        String strConcat = "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(canonicalName);
        F.d dVar = (F.d) this.b;
        e0.c.e(strConcat, "key");
        G g2 = (G) this.f6a;
        g2.getClass();
        LinkedHashMap linkedHashMap = g2.a;
        E e2 = (E) linkedHashMap.get(strConcat);
        if (cls.isInstance(e2)) {
            e0.c.c(e2, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
            return e2;
        }
        J.b bVar = (J.b) this.f7c;
        e0.c.e(bVar, "initialExtras");
        J.c cVar = new J.c();
        cVar.f75a.putAll(bVar.f75a);
        cVar.f75a.put(F.b, strConcat);
        try {
            eC = dVar.c(cls);
        } catch (AbstractMethodError unused) {
            eC = dVar.c(cls);
        }
        e0.c.e(eC, "viewModel");
        E e3 = (E) linkedHashMap.put(strConcat, eC);
        if (e3 != null) {
            e3.a();
        }
        return eC;
    }

    public ColorStateList h(int i2) {
        int resourceId;
        ColorStateList colorStateListT;
        TypedArray typedArray = (TypedArray) this.b;
        return (!typedArray.hasValue(i2) || (resourceId = typedArray.getResourceId(i2, 0)) == 0 || (colorStateListT = D.g.t((Context) this.f6a, resourceId)) == null) ? typedArray.getColorStateList(i2) : colorStateListT;
    }

    public Drawable i(int i2) {
        int resourceId;
        TypedArray typedArray = (TypedArray) this.b;
        return (!typedArray.hasValue(i2) || (resourceId = typedArray.getResourceId(i2, 0)) == 0) ? typedArray.getDrawable(i2) : D.g.w((Context) this.f6a, resourceId);
    }

    public Drawable j(int i2) {
        int resourceId;
        Drawable drawableD;
        if (!((TypedArray) this.b).hasValue(i2) || (resourceId = ((TypedArray) this.b).getResourceId(i2, 0)) == 0) {
            return null;
        }
        C0080v c0080vA = C0080v.a();
        Context context = (Context) this.f6a;
        synchronized (c0080vA) {
            drawableD = c0080vA.f968a.d(context, resourceId, true);
        }
        return drawableD;
    }

    public Typeface k(int i2, int i3, U u2) {
        U u3;
        XmlPullParserException xmlPullParserException;
        IOException iOException;
        int resourceId = ((TypedArray) this.b).getResourceId(i2, 0);
        if (resourceId != 0) {
            if (((TypedValue) this.f7c) == null) {
                this.f7c = new TypedValue();
            }
            TypedValue typedValue = (TypedValue) this.f7c;
            ThreadLocal threadLocal = m.f1105a;
            Context context = (Context) this.f6a;
            if (!context.isRestricted()) {
                Resources resources = context.getResources();
                resources.getValue(resourceId, typedValue, true);
                CharSequence charSequence = typedValue.string;
                if (charSequence == null) {
                    throw new Resources.NotFoundException("Resource \"" + resources.getResourceName(resourceId) + "\" (" + Integer.toHexString(resourceId) + ") is not a Font: " + typedValue);
                }
                String string = charSequence.toString();
                if (!string.startsWith("res/")) {
                    u2.a();
                    return null;
                }
                int i4 = typedValue.assetCookie;
                C0098f c0098f = r.f.b;
                Typeface typeface = (Typeface) c0098f.a(r.f.b(resources, resourceId, string, i4, i3));
                if (typeface != null) {
                    new Handler(Looper.getMainLooper()).post(new L.h(u2, 2, typeface));
                    return typeface;
                }
                try {
                } catch (IOException e2) {
                    e = e2;
                    u3 = u2;
                } catch (XmlPullParserException e3) {
                    e = e3;
                    u3 = u2;
                }
                try {
                    if (!string.toLowerCase().endsWith(".xml")) {
                        int i5 = typedValue.assetCookie;
                        Typeface typefaceO = r.f.f1122a.o(context, resources, resourceId, string, i3);
                        if (typefaceO != null) {
                            c0098f.b(r.f.b(resources, resourceId, string, i5, i3), typefaceO);
                        }
                        if (typefaceO != null) {
                            new Handler(Looper.getMainLooper()).post(new L.h(u2, 2, typefaceO));
                        } else {
                            u2.a();
                        }
                        return typefaceO;
                    }
                    q.e eVarC = q.b.c(resources.getXml(resourceId), resources);
                    if (eVarC != null) {
                        return r.f.a(context, eVarC, resources, resourceId, string, typedValue.assetCookie, i3, u2);
                    }
                    try {
                        Log.e("ResourcesCompat", "Failed to find font-family tag");
                        u2.a();
                        return null;
                    } catch (IOException e4) {
                        iOException = e4;
                        u3 = u2;
                    } catch (XmlPullParserException e5) {
                        xmlPullParserException = e5;
                        u3 = u2;
                        Log.e("ResourcesCompat", "Failed to parse xml resource ".concat(string), xmlPullParserException);
                        u3.a();
                        return null;
                    }
                } catch (IOException e6) {
                    e = e6;
                    iOException = e;
                } catch (XmlPullParserException e7) {
                    e = e7;
                    xmlPullParserException = e;
                    Log.e("ResourcesCompat", "Failed to parse xml resource ".concat(string), xmlPullParserException);
                    u3.a();
                    return null;
                }
                iOException = e;
                Log.e("ResourcesCompat", "Failed to read xml resource ".concat(string), iOException);
                u3.a();
                return null;
            }
        }
        return null;
    }

    public boolean l(CharSequence charSequence, int i2, int i3, w wVar) {
        if ((wVar.c & 3) == 0) {
            androidx.emoji2.text.e eVar = (androidx.emoji2.text.e) this.f7c;
            F.a aVarB = wVar.b();
            int iA = aVarB.a(8);
            if (iA != 0) {
                ((ByteBuffer) aVarB.f55d).getShort(iA + aVarB.f53a);
            }
            eVar.getClass();
            ThreadLocal threadLocal = androidx.emoji2.text.e.b;
            if (threadLocal.get() == null) {
                threadLocal.set(new StringBuilder());
            }
            StringBuilder sb = (StringBuilder) threadLocal.get();
            sb.setLength(0);
            while (i2 < i3) {
                sb.append(charSequence.charAt(i2));
                i2++;
            }
            TextPaint textPaint = eVar.a;
            String string = sb.toString();
            int i4 = r.e.f1121a;
            boolean zA = r.d.a(textPaint, string);
            int i5 = wVar.c & 4;
            wVar.c = zA ? i5 | 2 : i5 | 1;
        }
        return (wVar.c & 3) == 2;
    }

    public void n() {
        Iterator it = ((CopyOnWriteArrayList) this.b).iterator();
        while (it.hasNext()) {
            p pVar = ((l) it.next()).a;
            if (pVar.q >= 1) {
                Iterator it2 = pVar.c.d().iterator();
                while (it2.hasNext()) {
                    if (it2.next() != null) {
                        throw new ClassCastException();
                    }
                }
            }
        }
    }

    public void o() {
        Iterator it = ((CopyOnWriteArrayList) this.b).iterator();
        while (it.hasNext()) {
            p pVar = ((l) it.next()).a;
            if (pVar.q >= 1) {
                Iterator it2 = pVar.c.d().iterator();
                while (it2.hasNext()) {
                    if (it2.next() != null) {
                        throw new ClassCastException();
                    }
                }
            }
        }
    }

    public void p() {
        Iterator it = ((CopyOnWriteArrayList) this.b).iterator();
        while (it.hasNext()) {
            p pVar = ((l) it.next()).a;
            if (pVar.q >= 1) {
                Iterator it2 = pVar.c.d().iterator();
                while (it2.hasNext()) {
                    if (it2.next() != null) {
                        throw new ClassCastException();
                    }
                }
            }
        }
    }

    public Object q(CharSequence charSequence, int i2, int i3, int i4, boolean z2, androidx.emoji2.text.p pVar) {
        int i5;
        char c2;
        q qVar = new q((t) ((T.t) this.b).f212c);
        int iCodePointAt = Character.codePointAt(charSequence, i2);
        boolean zC = true;
        int i6 = 0;
        int iCharCount = i2;
        loop0: while (true) {
            i5 = iCharCount;
            while (iCharCount < i3 && i6 < i4 && zC) {
                SparseArray sparseArray = qVar.c.a;
                t tVar = sparseArray == null ? null : (t) sparseArray.get(iCodePointAt);
                if (qVar.a == 2) {
                    if (tVar != null) {
                        qVar.c = tVar;
                        qVar.f++;
                    } else {
                        if (iCodePointAt == 65038) {
                            qVar.a();
                        } else if (iCodePointAt != 65039) {
                            t tVar2 = qVar.c;
                            if (tVar2.b != null) {
                                if (qVar.f != 1) {
                                    qVar.d = tVar2;
                                    qVar.a();
                                } else if (qVar.b()) {
                                    qVar.d = qVar.c;
                                    qVar.a();
                                } else {
                                    qVar.a();
                                }
                                c2 = 3;
                            } else {
                                qVar.a();
                            }
                        }
                        c2 = 1;
                    }
                    c2 = 2;
                } else if (tVar == null) {
                    qVar.a();
                    c2 = 1;
                } else {
                    qVar.a = 2;
                    qVar.c = tVar;
                    qVar.f = 1;
                    c2 = 2;
                }
                qVar.e = iCodePointAt;
                if (c2 == 1) {
                    iCharCount = Character.charCount(Character.codePointAt(charSequence, i5)) + i5;
                    if (iCharCount < i3) {
                        iCodePointAt = Character.codePointAt(charSequence, iCharCount);
                    }
                } else if (c2 == 2) {
                    int iCharCount2 = Character.charCount(iCodePointAt) + iCharCount;
                    if (iCharCount2 < i3) {
                        iCodePointAt = Character.codePointAt(charSequence, iCharCount2);
                    }
                    iCharCount = iCharCount2;
                } else if (c2 == 3) {
                    if (z2 || !l(charSequence, i5, iCharCount, qVar.d.b)) {
                        zC = pVar.c(charSequence, i5, iCharCount, qVar.d.b);
                        i6++;
                    }
                }
            }
            break loop0;
        }
        if (qVar.a == 2 && qVar.c.b != null && ((qVar.f > 1 || qVar.b()) && i6 < i4 && zC && (z2 || !l(charSequence, i5, iCharCount, qVar.c.b)))) {
            pVar.c(charSequence, i5, iCharCount, qVar.c.b);
        }
        return pVar.i();
    }

    public void r() {
        ((TypedArray) this.b).recycle();
    }

    public h(Uri uri, ClipDescription clipDescription, Uri uri2) {
        this.f6a = uri;
        this.f7c = clipDescription;
        this.b = uri2;
    }

    public h(Runnable runnable) {
        this.b = new CopyOnWriteArrayList();
        this.f7c = new HashMap();
        this.f6a = runnable;
    }

    public h(Context context, TypedArray typedArray) {
        this.f6a = context;
        this.b = typedArray;
    }

    public h(Context context, LocationManager locationManager) {
        this.f7c = new K();
        this.f6a = context;
        this.b = locationManager;
    }

    public h(T.t tVar, F.d dVar, androidx.emoji2.text.e eVar, Set set) {
        this.f6a = dVar;
        this.b = tVar;
        this.f7c = eVar;
        if (set.isEmpty()) {
            return;
        }
        Iterator it = set.iterator();
        while (it.hasNext()) {
            int[] iArr = (int[]) it.next();
            String str = new String(iArr, 0, iArr.length);
            q(str, 0, str.length(), 1, true, new j(11, str));
        }
    }

    @Override // C.i
    public void b() {
    }
}
