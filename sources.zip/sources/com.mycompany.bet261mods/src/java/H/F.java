package h;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class F extends n implements SubMenu {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final p f601A;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final n f602z;

    public F(Context context, n nVar, p pVar) {
        super(context);
        this.f602z = nVar;
        this.f601A = pVar;
    }

    @Override // h.n
    public final boolean d(p pVar) {
        return this.f602z.d(pVar);
    }

    @Override // h.n
    public final boolean e(n nVar, MenuItem menuItem) {
        return super.e(nVar, menuItem) || this.f602z.e(nVar, menuItem);
    }

    @Override // h.n
    public final boolean f(p pVar) {
        return this.f602z.f(pVar);
    }

    @Override // android.view.SubMenu
    public final MenuItem getItem() {
        return this.f601A;
    }

    @Override // h.n
    public final String j() {
        p pVar = this.f601A;
        int i2 = pVar != null ? pVar.f686a : 0;
        if (i2 == 0) {
            return null;
        }
        return "android:menu:actionviewstates:" + i2;
    }

    @Override // h.n
    public final n k() {
        return this.f602z.k();
    }

    @Override // h.n
    public final boolean m() {
        return this.f602z.m();
    }

    @Override // h.n
    public final boolean n() {
        return this.f602z.n();
    }

    @Override // h.n
    public final boolean o() {
        return this.f602z.o();
    }

    @Override // h.n, android.view.Menu
    public final void setGroupDividerEnabled(boolean z2) {
        this.f602z.setGroupDividerEnabled(z2);
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderIcon(Drawable drawable) {
        u(0, null, 0, drawable, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderTitle(CharSequence charSequence) {
        u(0, charSequence, 0, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderView(View view) {
        u(0, null, 0, null, view);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setIcon(Drawable drawable) {
        this.f601A.setIcon(drawable);
        return this;
    }

    @Override // h.n, android.view.Menu
    public final void setQwertyMode(boolean z2) {
        this.f602z.setQwertyMode(z2);
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderIcon(int i2) {
        u(0, null, i2, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderTitle(int i2) {
        u(i2, null, 0, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setIcon(int i2) {
        this.f601A.setIcon(i2);
        return this;
    }
}
