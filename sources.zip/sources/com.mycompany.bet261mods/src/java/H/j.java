package h;

import android.content.Context;
import android.content.ContextWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import androidx.appcompat.view.menu.ExpandedMenuView;
import e.C0007b;
import e.C0011f;
import e.DialogC0012g;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class j implements z, AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Context f650a;
    public LayoutInflater b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public n f651c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ExpandedMenuView f652d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public y f653e;
    public i f;

    public j(ContextWrapper contextWrapper) {
        this.f650a = contextWrapper;
        this.b = LayoutInflater.from(contextWrapper);
    }

    @Override // h.z
    public final void b(n nVar, boolean z2) {
        y yVar = this.f653e;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    @Override // h.z
    public final void c() {
        i iVar = this.f;
        if (iVar != null) {
            iVar.notifyDataSetChanged();
        }
    }

    @Override // h.z
    public final boolean d(p pVar) {
        return false;
    }

    @Override // h.z
    public final void e(y yVar) {
        throw null;
    }

    @Override // h.z
    public final void g(Context context, n nVar) {
        if (this.f650a != null) {
            this.f650a = context;
            if (this.b == null) {
                this.b = LayoutInflater.from(context);
            }
        }
        this.f651c = nVar;
        i iVar = this.f;
        if (iVar != null) {
            iVar.notifyDataSetChanged();
        }
    }

    @Override // h.z
    public final boolean i() {
        return false;
    }

    @Override // h.z
    public final boolean j(F f) {
        if (!f.hasVisibleItems()) {
            return false;
        }
        o oVar = new o();
        oVar.f681a = f;
        Context context = f.f659a;
        C0011f c0011f = new C0011f(context);
        C0007b c0007b = (C0007b) c0011f.b;
        j jVar = new j(c0007b.f461a);
        oVar.f682c = jVar;
        jVar.f653e = oVar;
        f.b(jVar, context);
        j jVar2 = oVar.f682c;
        if (jVar2.f == null) {
            jVar2.f = new i(jVar2);
        }
        c0007b.f465g = jVar2.f;
        c0007b.f466h = oVar;
        View view = f.f671o;
        if (view != null) {
            c0007b.f464e = view;
        } else {
            c0007b.f462c = f.f670n;
            c0007b.f463d = f.f669m;
        }
        c0007b.f = oVar;
        DialogC0012g dialogC0012gA = c0011f.a();
        oVar.b = dialogC0012gA;
        dialogC0012gA.setOnDismissListener(oVar);
        WindowManager.LayoutParams attributes = oVar.b.getWindow().getAttributes();
        attributes.type = 1003;
        attributes.flags |= 131072;
        oVar.b.show();
        y yVar = this.f653e;
        if (yVar == null) {
            return true;
        }
        yVar.m(f);
        return true;
    }

    @Override // h.z
    public final boolean k(p pVar) {
        return false;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        this.f651c.q(this.f.getItem(i2), this, 0);
    }
}
