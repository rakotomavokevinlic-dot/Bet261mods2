package h;

/* JADX INFO: renamed from: h.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class RunnableC0037f implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ g f621a;
    public final /* synthetic */ p b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ n f622c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C.j f623d;

    public RunnableC0037f(C.j jVar, g gVar, p pVar, n nVar) {
        this.f623d = jVar;
        this.f621a = gVar;
        this.b = pVar;
        this.f622c = nVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        g gVar = this.f621a;
        if (gVar != null) {
            C.j jVar = this.f623d;
            ((h) jVar.b).f648z = true;
            gVar.b.c(false);
            ((h) jVar.b).f648z = false;
        }
        p pVar = this.b;
        if (pVar.isEnabled() && pVar.hasSubMenu()) {
            this.f622c.q(pVar, null, 4);
        }
    }
}
