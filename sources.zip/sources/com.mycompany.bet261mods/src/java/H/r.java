package h;

import android.view.CollapsibleActionView;
import android.view.View;
import android.widget.FrameLayout;
import g.InterfaceC0021b;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class r extends FrameLayout implements InterfaceC0021b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final CollapsibleActionView f712a;

    /* JADX WARN: Multi-variable type inference failed */
    public r(View view) {
        super(view.getContext());
        this.f712a = (CollapsibleActionView) view;
        addView(view);
    }
}
