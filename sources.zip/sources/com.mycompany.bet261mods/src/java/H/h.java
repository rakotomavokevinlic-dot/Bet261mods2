package h;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import i.C0077t0;
import i.I0;
import i.L0;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class h extends v implements View.OnKeyListener, PopupWindow.OnDismissListener {
    public final Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f626c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f627d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f628e;
    public final Handler f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ViewTreeObserverOnGlobalLayoutListenerC0035d f631i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final ViewOnAttachStateChangeListenerC0036e f632j;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public View f636n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public View f637o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f638p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f639q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f640r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f641s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f642t;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f644v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public y f645w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public ViewTreeObserver f646x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public w f647y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f648z;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ArrayList f629g = new ArrayList();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ArrayList f630h = new ArrayList();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final C.j f633k = new C.j(15, this);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f634l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f635m = 0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f643u = false;

    public h(Context context, View view, int i2, boolean z2) {
        int i3 = 0;
        this.f631i = new ViewTreeObserverOnGlobalLayoutListenerC0035d(i3, this);
        this.f632j = new ViewOnAttachStateChangeListenerC0036e(this, i3);
        this.b = context;
        this.f636n = view;
        this.f627d = i2;
        this.f628e = z2;
        this.f638p = view.getLayoutDirection() != 1 ? 1 : 0;
        Resources resources = context.getResources();
        this.f626c = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(2131099671));
        this.f = new Handler();
    }

    @Override // h.D
    public final boolean a() {
        ArrayList arrayList = this.f630h;
        return arrayList.size() > 0 && ((g) arrayList.get(0)).f624a.f769y.isShowing();
    }

    @Override // h.z
    public final void b(n nVar, boolean z2) {
        ArrayList arrayList = this.f630h;
        int size = arrayList.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (nVar == ((g) arrayList.get(i2)).b) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 < 0) {
            return;
        }
        int i3 = i2 + 1;
        if (i3 < arrayList.size()) {
            ((g) arrayList.get(i3)).b.c(false);
        }
        g gVar = (g) arrayList.remove(i2);
        gVar.b.r(this);
        boolean z3 = this.f648z;
        L0 l0 = gVar.f624a;
        if (z3) {
            I0.b(l0.f769y, null);
            l0.f769y.setAnimationStyle(0);
        }
        l0.dismiss();
        int size2 = arrayList.size();
        if (size2 > 0) {
            this.f638p = ((g) arrayList.get(size2 - 1)).f625c;
        } else {
            this.f638p = this.f636n.getLayoutDirection() == 1 ? 0 : 1;
        }
        if (size2 != 0) {
            if (z2) {
                ((g) arrayList.get(0)).b.c(false);
                return;
            }
            return;
        }
        dismiss();
        y yVar = this.f645w;
        if (yVar != null) {
            yVar.b(nVar, true);
        }
        ViewTreeObserver viewTreeObserver = this.f646x;
        if (viewTreeObserver != null) {
            if (viewTreeObserver.isAlive()) {
                this.f646x.removeGlobalOnLayoutListener(this.f631i);
            }
            this.f646x = null;
        }
        this.f637o.removeOnAttachStateChangeListener(this.f632j);
        this.f647y.onDismiss();
    }

    @Override // h.z
    public final void c() {
        ArrayList arrayList = this.f630h;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            ListAdapter adapter = ((g) obj).f624a.f748c.getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }
            ((k) adapter).notifyDataSetChanged();
        }
    }

    @Override // h.D
    public final void dismiss() {
        ArrayList arrayList = this.f630h;
        int size = arrayList.size();
        if (size > 0) {
            g[] gVarArr = (g[]) arrayList.toArray(new g[size]);
            for (int i2 = size - 1; i2 >= 0; i2--) {
                g gVar = gVarArr[i2];
                if (gVar.f624a.f769y.isShowing()) {
                    gVar.f624a.dismiss();
                }
            }
        }
    }

    @Override // h.z
    public final void e(y yVar) {
        this.f645w = yVar;
    }

    @Override // h.D
    public final C0077t0 f() {
        ArrayList arrayList = this.f630h;
        if (arrayList.isEmpty()) {
            return null;
        }
        return ((g) arrayList.get(arrayList.size() - 1)).f624a.f748c;
    }

    @Override // h.D
    public final void h() {
        if (a()) {
            return;
        }
        ArrayList arrayList = this.f629g;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            v((n) obj);
        }
        arrayList.clear();
        View view = this.f636n;
        this.f637o = view;
        if (view != null) {
            boolean z2 = this.f646x == null;
            ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
            this.f646x = viewTreeObserver;
            if (z2) {
                viewTreeObserver.addOnGlobalLayoutListener(this.f631i);
            }
            this.f637o.addOnAttachStateChangeListener(this.f632j);
        }
    }

    @Override // h.z
    public final boolean i() {
        return false;
    }

    @Override // h.z
    public final boolean j(F f) {
        ArrayList arrayList = this.f630h;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            g gVar = (g) obj;
            if (f == gVar.b) {
                gVar.f624a.f748c.requestFocus();
                return true;
            }
        }
        if (!f.hasVisibleItems()) {
            return false;
        }
        l(f);
        y yVar = this.f645w;
        if (yVar != null) {
            yVar.m(f);
        }
        return true;
    }

    @Override // h.v
    public final void l(n nVar) {
        nVar.b(this, this.b);
        if (a()) {
            v(nVar);
        } else {
            this.f629g.add(nVar);
        }
    }

    @Override // h.v
    public final void n(View view) {
        if (this.f636n != view) {
            this.f636n = view;
            this.f635m = Gravity.getAbsoluteGravity(this.f634l, view.getLayoutDirection());
        }
    }

    @Override // h.v
    public final void o(boolean z2) {
        this.f643u = z2;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public final void onDismiss() {
        g gVar;
        ArrayList arrayList = this.f630h;
        int size = arrayList.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                gVar = null;
                break;
            }
            gVar = (g) arrayList.get(i2);
            if (!gVar.f624a.f769y.isShowing()) {
                break;
            } else {
                i2++;
            }
        }
        if (gVar != null) {
            gVar.b.c(false);
        }
    }

    @Override // android.view.View.OnKeyListener
    public final boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // h.v
    public final void p(int i2) {
        if (this.f634l != i2) {
            this.f634l = i2;
            this.f635m = Gravity.getAbsoluteGravity(i2, this.f636n.getLayoutDirection());
        }
    }

    @Override // h.v
    public final void q(int i2) {
        this.f639q = true;
        this.f641s = i2;
    }

    @Override // h.v
    public final void r(PopupWindow.OnDismissListener onDismissListener) {
        this.f647y = (w) onDismissListener;
    }

    @Override // h.v
    public final void s(boolean z2) {
        this.f644v = z2;
    }

    @Override // h.v
    public final void t(int i2) {
        this.f640r = true;
        this.f642t = i2;
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x00ef  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0148  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x014b  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x01ba  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void v(h.n r18) {
        /*
            Method dump skipped, instruction units count: 534
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h.h.v(h.n):void");
    }
}
