package h;

import i.C0077t0;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface D {
    boolean a();

    void dismiss();

    C0077t0 f();

    void h();
}
