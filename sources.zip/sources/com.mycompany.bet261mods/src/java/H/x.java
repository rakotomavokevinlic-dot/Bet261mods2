package h;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f719a;
    public final n b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f720c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f721d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public View f722e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f723g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public y f724h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public v f725i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public w f726j;
    public int f = 8388611;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final w f727k = new w(this);

    public x(int i2, Context context, View view, n nVar, boolean z2) {
        this.f719a = context;
        this.b = nVar;
        this.f722e = view;
        this.f720c = z2;
        this.f721d = i2;
    }

    public final v a() {
        v e2;
        if (this.f725i == null) {
            Context context = this.f719a;
            Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
            Point point = new Point();
            defaultDisplay.getRealSize(point);
            if (Math.min(point.x, point.y) >= context.getResources().getDimensionPixelSize(2131099670)) {
                e2 = new h(context, this.f722e, this.f721d, this.f720c);
            } else {
                View view = this.f722e;
                Context context2 = this.f719a;
                boolean z2 = this.f720c;
                e2 = new E(this.f721d, context2, view, this.b, z2);
            }
            e2.l(this.b);
            e2.r(this.f727k);
            e2.n(this.f722e);
            e2.e(this.f724h);
            e2.o(this.f723g);
            e2.p(this.f);
            this.f725i = e2;
        }
        return this.f725i;
    }

    public final boolean b() {
        v vVar = this.f725i;
        return vVar != null && vVar.a();
    }

    public void c() {
        this.f725i = null;
        w wVar = this.f726j;
        if (wVar != null) {
            wVar.onDismiss();
        }
    }

    public final void d(int i2, int i3, boolean z2, boolean z3) {
        v vVarA = a();
        vVarA.s(z3);
        if (z2) {
            if ((Gravity.getAbsoluteGravity(this.f, this.f722e.getLayoutDirection()) & 7) == 5) {
                i2 -= this.f722e.getWidth();
            }
            vVarA.q(i2);
            vVarA.t(i3);
            int i4 = (int) ((this.f719a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            vVarA.f717a = new Rect(i2 - i4, i3 - i4, i2 + i4, i3 + i4);
        }
        vVarA.h();
    }
}
