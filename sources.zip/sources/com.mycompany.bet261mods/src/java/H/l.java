package h;

import android.view.MenuItem;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface l {
    void g(n nVar);

    boolean h(n nVar, MenuItem menuItem);
}
