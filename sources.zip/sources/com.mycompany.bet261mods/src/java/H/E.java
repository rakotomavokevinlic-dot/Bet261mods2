package h;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import i.C0077t0;
import i.L0;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class E extends v implements PopupWindow.OnDismissListener, View.OnKeyListener {
    public final Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final n f584c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final k f585d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f586e;
    public final int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f587g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final L0 f588h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ViewTreeObserverOnGlobalLayoutListenerC0035d f589i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final ViewOnAttachStateChangeListenerC0036e f590j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public w f591k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public View f592l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public View f593m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public y f594n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public ViewTreeObserver f595o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f596p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f597q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f598r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f599s = 0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f600t;

    public E(int i2, Context context, View view, n nVar, boolean z2) {
        int i3 = 1;
        this.f589i = new ViewTreeObserverOnGlobalLayoutListenerC0035d(i3, this);
        this.f590j = new ViewOnAttachStateChangeListenerC0036e(this, i3);
        this.b = context;
        this.f584c = nVar;
        this.f586e = z2;
        this.f585d = new k(nVar, LayoutInflater.from(context), z2, 2131427347);
        this.f587g = i2;
        Resources resources = context.getResources();
        this.f = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(2131099671));
        this.f592l = view;
        this.f588h = new L0(context, null, i2);
        nVar.b(this, context);
    }

    @Override // h.D
    public final boolean a() {
        return !this.f596p && this.f588h.f769y.isShowing();
    }

    @Override // h.z
    public final void b(n nVar, boolean z2) {
        if (nVar != this.f584c) {
            return;
        }
        dismiss();
        y yVar = this.f594n;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    @Override // h.z
    public final void c() {
        this.f597q = false;
        k kVar = this.f585d;
        if (kVar != null) {
            kVar.notifyDataSetChanged();
        }
    }

    @Override // h.D
    public final void dismiss() {
        if (a()) {
            this.f588h.dismiss();
        }
    }

    @Override // h.z
    public final void e(y yVar) {
        this.f594n = yVar;
    }

    @Override // h.D
    public final C0077t0 f() {
        return this.f588h.f748c;
    }

    @Override // h.D
    public final void h() {
        View view;
        if (a()) {
            return;
        }
        if (this.f596p || (view = this.f592l) == null) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
        this.f593m = view;
        L0 l0 = this.f588h;
        l0.f769y.setOnDismissListener(this);
        l0.f760p = this;
        l0.f768x = true;
        l0.f769y.setFocusable(true);
        View view2 = this.f593m;
        boolean z2 = this.f595o == null;
        ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
        this.f595o = viewTreeObserver;
        if (z2) {
            viewTreeObserver.addOnGlobalLayoutListener(this.f589i);
        }
        view2.addOnAttachStateChangeListener(this.f590j);
        l0.f759o = view2;
        l0.f756l = this.f599s;
        boolean z3 = this.f597q;
        Context context = this.b;
        k kVar = this.f585d;
        if (!z3) {
            this.f598r = v.m(kVar, context, this.f);
            this.f597q = true;
        }
        l0.p(this.f598r);
        l0.f769y.setInputMethodMode(2);
        Rect rect = this.f717a;
        l0.f767w = rect != null ? new Rect(rect) : null;
        l0.h();
        C0077t0 c0077t0 = l0.f748c;
        c0077t0.setOnKeyListener(this);
        if (this.f600t) {
            n nVar = this.f584c;
            if (nVar.f669m != null) {
                FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(context).inflate(2131427346, (ViewGroup) c0077t0, false);
                TextView textView = (TextView) frameLayout.findViewById(R.id.title);
                if (textView != null) {
                    textView.setText(nVar.f669m);
                }
                frameLayout.setEnabled(false);
                c0077t0.addHeaderView(frameLayout, null, false);
            }
        }
        l0.m(kVar);
        l0.h();
    }

    @Override // h.z
    public final boolean i() {
        return false;
    }

    @Override // h.z
    public final boolean j(F f) {
        if (f.hasVisibleItems()) {
            View view = this.f593m;
            x xVar = new x(this.f587g, this.b, view, f, this.f586e);
            y yVar = this.f594n;
            xVar.f724h = yVar;
            v vVar = xVar.f725i;
            if (vVar != null) {
                vVar.e(yVar);
            }
            boolean zU = v.u(f);
            xVar.f723g = zU;
            v vVar2 = xVar.f725i;
            if (vVar2 != null) {
                vVar2.o(zU);
            }
            xVar.f726j = this.f591k;
            this.f591k = null;
            this.f584c.c(false);
            L0 l0 = this.f588h;
            int width = l0.f;
            int i2 = l0.i();
            if ((Gravity.getAbsoluteGravity(this.f599s, this.f592l.getLayoutDirection()) & 7) == 5) {
                width += this.f592l.getWidth();
            }
            if (!xVar.b()) {
                if (xVar.f722e != null) {
                    xVar.d(width, i2, true, true);
                }
            }
            y yVar2 = this.f594n;
            if (yVar2 != null) {
                yVar2.m(f);
            }
            return true;
        }
        return false;
    }

    @Override // h.v
    public final void n(View view) {
        this.f592l = view;
    }

    @Override // h.v
    public final void o(boolean z2) {
        this.f585d.f655c = z2;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public final void onDismiss() {
        this.f596p = true;
        this.f584c.c(true);
        ViewTreeObserver viewTreeObserver = this.f595o;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.f595o = this.f593m.getViewTreeObserver();
            }
            this.f595o.removeGlobalOnLayoutListener(this.f589i);
            this.f595o = null;
        }
        this.f593m.removeOnAttachStateChangeListener(this.f590j);
        w wVar = this.f591k;
        if (wVar != null) {
            wVar.onDismiss();
        }
    }

    @Override // android.view.View.OnKeyListener
    public final boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // h.v
    public final void p(int i2) {
        this.f599s = i2;
    }

    @Override // h.v
    public final void q(int i2) {
        this.f588h.f = i2;
    }

    @Override // h.v
    public final void r(PopupWindow.OnDismissListener onDismissListener) {
        this.f591k = (w) onDismissListener;
    }

    @Override // h.v
    public final void s(boolean z2) {
        this.f600t = z2;
    }

    @Override // h.v
    public final void t(int i2) {
        this.f588h.k(i2);
    }

    @Override // h.v
    public final void l(n nVar) {
    }
}
