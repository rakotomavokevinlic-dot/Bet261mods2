package h;

import android.R;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import p.AbstractC0114a;
import s.AbstractC0120a;
import t.InterfaceMenuItemC0123a;

/* JADX INFO: renamed from: h.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0032a implements InterfaceMenuItemC0123a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public CharSequence f603a;
    public CharSequence b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Intent f604c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public char f605d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f606e;
    public char f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f607g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Drawable f608h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Context f609i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f610j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public CharSequence f611k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public ColorStateList f612l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public PorterDuff.Mode f613m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f614n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f615o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f616p;

    @Override // t.InterfaceMenuItemC0123a
    public final q a() {
        return null;
    }

    @Override // t.InterfaceMenuItemC0123a
    public final InterfaceMenuItemC0123a b(q qVar) {
        throw new UnsupportedOperationException();
    }

    public final void c() {
        Drawable drawable = this.f608h;
        if (drawable != null) {
            if (this.f614n || this.f615o) {
                this.f608h = drawable;
                Drawable drawableMutate = drawable.mutate();
                this.f608h = drawableMutate;
                if (this.f614n) {
                    AbstractC0120a.h(drawableMutate, this.f612l);
                }
                if (this.f615o) {
                    AbstractC0120a.i(this.f608h, this.f613m);
                }
            }
        }
    }

    @Override // android.view.MenuItem
    public final boolean collapseActionView() {
        return false;
    }

    @Override // android.view.MenuItem
    public final boolean expandActionView() {
        return false;
    }

    @Override // android.view.MenuItem
    public final ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public final View getActionView() {
        return null;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final int getAlphabeticModifiers() {
        return this.f607g;
    }

    @Override // android.view.MenuItem
    public final char getAlphabeticShortcut() {
        return this.f;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final CharSequence getContentDescription() {
        return this.f610j;
    }

    @Override // android.view.MenuItem
    public final int getGroupId() {
        return 0;
    }

    @Override // android.view.MenuItem
    public final Drawable getIcon() {
        return this.f608h;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final ColorStateList getIconTintList() {
        return this.f612l;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final PorterDuff.Mode getIconTintMode() {
        return this.f613m;
    }

    @Override // android.view.MenuItem
    public final Intent getIntent() {
        return this.f604c;
    }

    @Override // android.view.MenuItem
    public final int getItemId() {
        return R.id.home;
    }

    @Override // android.view.MenuItem
    public final ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final int getNumericModifiers() {
        return this.f606e;
    }

    @Override // android.view.MenuItem
    public final char getNumericShortcut() {
        return this.f605d;
    }

    @Override // android.view.MenuItem
    public final int getOrder() {
        return 0;
    }

    @Override // android.view.MenuItem
    public final SubMenu getSubMenu() {
        return null;
    }

    @Override // android.view.MenuItem
    public final CharSequence getTitle() {
        return this.f603a;
    }

    @Override // android.view.MenuItem
    public final CharSequence getTitleCondensed() {
        CharSequence charSequence = this.b;
        return charSequence != null ? charSequence : this.f603a;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final CharSequence getTooltipText() {
        return this.f611k;
    }

    @Override // android.view.MenuItem
    public final boolean hasSubMenu() {
        return false;
    }

    @Override // android.view.MenuItem
    public final boolean isActionViewExpanded() {
        return false;
    }

    @Override // android.view.MenuItem
    public final boolean isCheckable() {
        return (this.f616p & 1) != 0;
    }

    @Override // android.view.MenuItem
    public final boolean isChecked() {
        return (this.f616p & 2) != 0;
    }

    @Override // android.view.MenuItem
    public final boolean isEnabled() {
        return (this.f616p & 16) != 0;
    }

    @Override // android.view.MenuItem
    public final boolean isVisible() {
        return (this.f616p & 8) == 0;
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionView(View view) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public final MenuItem setAlphabeticShortcut(char c2) {
        this.f = Character.toLowerCase(c2);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setCheckable(boolean z2) {
        this.f616p = (z2 ? 1 : 0) | (this.f616p & (-2));
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setChecked(boolean z2) {
        this.f616p = (z2 ? 2 : 0) | (this.f616p & (-3));
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setContentDescription(CharSequence charSequence) {
        this.f610j = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setEnabled(boolean z2) {
        this.f616p = (z2 ? 16 : 0) | (this.f616p & (-17));
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIcon(Drawable drawable) {
        this.f608h = drawable;
        c();
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f612l = colorStateList;
        this.f614n = true;
        c();
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f613m = mode;
        this.f615o = true;
        c();
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIntent(Intent intent) {
        this.f604c = intent;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setNumericShortcut(char c2) {
        this.f605d = c2;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public final MenuItem setShortcut(char c2, char c3) {
        this.f605d = c2;
        this.f = Character.toLowerCase(c3);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitle(CharSequence charSequence) {
        this.f603a = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitleCondensed(CharSequence charSequence) {
        this.b = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTooltipText(CharSequence charSequence) {
        this.f611k = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setVisible(boolean z2) {
        this.f616p = (this.f616p & 8) | (z2 ? 0 : 8);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionView(int i2) {
        throw new UnsupportedOperationException();
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setAlphabeticShortcut(char c2, int i2) {
        this.f = Character.toLowerCase(c2);
        this.f607g = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final InterfaceMenuItemC0123a setContentDescription(CharSequence charSequence) {
        this.f610j = charSequence;
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setNumericShortcut(char c2, int i2) {
        this.f605d = c2;
        this.f606e = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitle(int i2) {
        this.f603a = this.f609i.getResources().getString(i2);
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final InterfaceMenuItemC0123a setTooltipText(CharSequence charSequence) {
        this.f611k = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIcon(int i2) {
        this.f608h = AbstractC0114a.b(this.f609i, i2);
        c();
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f605d = c2;
        this.f606e = KeyEvent.normalizeMetaState(i2);
        this.f = Character.toLowerCase(c3);
        this.f607g = KeyEvent.normalizeMetaState(i3);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        return this;
    }

    @Override // android.view.MenuItem
    public final void setShowAsAction(int i2) {
    }

    @Override // android.view.MenuItem
    public final MenuItem setShowAsActionFlags(int i2) {
        return this;
    }
}
