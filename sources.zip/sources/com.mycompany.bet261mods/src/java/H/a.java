package H;

import android.R;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f72a = {R.attr.name, R.attr.id, R.attr.tag};
    public static final int[] b = {R.attr.name, R.attr.tag};
}
