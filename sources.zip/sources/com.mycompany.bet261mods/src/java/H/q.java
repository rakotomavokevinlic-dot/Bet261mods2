package h;

import android.view.ActionProvider;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class q implements ActionProvider.VisibilityListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public C.j f710a;
    public final ActionProvider b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ u f711c;

    public q(u uVar, ActionProvider actionProvider) {
        this.f711c = uVar;
        this.b = actionProvider;
    }

    @Override // android.view.ActionProvider.VisibilityListener
    public final void onActionProviderVisibilityChanged(boolean z2) {
        C.j jVar = this.f710a;
        if (jVar != null) {
            n nVar = ((p) jVar.b).f697n;
            nVar.f664h = true;
            nVar.p(true);
        }
    }
}
