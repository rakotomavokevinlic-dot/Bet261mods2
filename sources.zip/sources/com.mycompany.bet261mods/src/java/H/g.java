package h;

import i.L0;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final L0 f624a;
    public final n b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f625c;

    public g(L0 l0, n nVar, int i2) {
        this.f624a = l0;
        this.b = nVar;
        this.f625c = i2;
    }
}
