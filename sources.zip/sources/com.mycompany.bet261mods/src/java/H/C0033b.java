package h;

import android.view.View;
import androidx.appcompat.view.menu.ActionMenuItemView;
import i.AbstractViewOnTouchListenerC0083w0;
import i.C0053h;
import i.C0055i;
import i.C0059k;
import i.C0061l;

/* JADX INFO: renamed from: h.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0033b extends AbstractViewOnTouchListenerC0083w0 {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ int f617j = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ View f618k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0033b(ActionMenuItemView actionMenuItemView) {
        super(actionMenuItemView);
        this.f618k = actionMenuItemView;
    }

    @Override // i.AbstractViewOnTouchListenerC0083w0
    public final D b() {
        C0053h c0053h;
        switch (this.f617j) {
            case 0:
                AbstractC0034c abstractC0034c = this.f618k.m;
                if (abstractC0034c == null || (c0053h = ((C0055i) abstractC0034c).f883a.f922t) == null) {
                    return null;
                }
                return c0053h.a();
            default:
                C0053h c0053h2 = ((C0059k) this.f618k).f904d.f921s;
                if (c0053h2 == null) {
                    return null;
                }
                return c0053h2.a();
        }
    }

    @Override // i.AbstractViewOnTouchListenerC0083w0
    public final boolean c() {
        D dB;
        switch (this.f617j) {
            case 0:
                ActionMenuItemView actionMenuItemView = this.f618k;
                m mVar = actionMenuItemView.k;
                return mVar != null && mVar.b(actionMenuItemView.h) && (dB = b()) != null && dB.a();
            default:
                ((C0059k) this.f618k).f904d.l();
                return true;
        }
    }

    @Override // i.AbstractViewOnTouchListenerC0083w0
    public boolean d() {
        switch (this.f617j) {
            case 1:
                C0061l c0061l = ((C0059k) this.f618k).f904d;
                if (c0061l.f923u != null) {
                    return false;
                }
                c0061l.f();
                return true;
            default:
                return super.d();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0033b(C0059k c0059k, C0059k c0059k2) {
        super(c0059k2);
        this.f618k = c0059k;
    }
}
