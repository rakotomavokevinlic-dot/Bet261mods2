package h;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class k extends BaseAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n f654a;
    public int b = -1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f655c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f656d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final LayoutInflater f657e;
    public final int f;

    public k(n nVar, LayoutInflater layoutInflater, boolean z2, int i2) {
        this.f656d = z2;
        this.f657e = layoutInflater;
        this.f654a = nVar;
        this.f = i2;
        a();
    }

    public final void a() {
        n nVar = this.f654a;
        p pVar = nVar.f678v;
        if (pVar != null) {
            nVar.i();
            ArrayList arrayList = nVar.f666j;
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (((p) arrayList.get(i2)) == pVar) {
                    this.b = i2;
                    return;
                }
            }
        }
        this.b = -1;
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public final p getItem(int i2) {
        ArrayList arrayListL;
        n nVar = this.f654a;
        if (this.f656d) {
            nVar.i();
            arrayListL = nVar.f666j;
        } else {
            arrayListL = nVar.l();
        }
        int i3 = this.b;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return (p) arrayListL.get(i2);
    }

    @Override // android.widget.Adapter
    public final int getCount() {
        ArrayList arrayListL;
        n nVar = this.f654a;
        if (this.f656d) {
            nVar.i();
            arrayListL = nVar.f666j;
        } else {
            arrayListL = nVar.l();
        }
        return this.b < 0 ? arrayListL.size() : arrayListL.size() - 1;
    }

    @Override // android.widget.Adapter
    public final long getItemId(int i2) {
        return i2;
    }

    @Override // android.widget.Adapter
    public final View getView(int i2, View view, ViewGroup viewGroup) {
        boolean z2 = false;
        if (view == null) {
            view = this.f657e.inflate(this.f, viewGroup, false);
        }
        int i3 = getItem(i2).b;
        int i4 = i2 - 1;
        int i5 = i4 >= 0 ? getItem(i4).b : i3;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        if (this.f654a.m() && i3 != i5) {
            z2 = true;
        }
        listMenuItemView.setGroupDividerEnabled(z2);
        InterfaceC0031A interfaceC0031A = (InterfaceC0031A) view;
        if (this.f655c) {
            listMenuItemView.setForceShowIcon(true);
        }
        interfaceC0031A.c(getItem(i2));
        return view;
    }

    @Override // android.widget.BaseAdapter
    public final void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
