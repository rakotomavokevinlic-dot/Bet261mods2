package h;

/* JADX INFO: renamed from: h.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface InterfaceC0031A {
    void c(p pVar);

    p getItemData();
}
