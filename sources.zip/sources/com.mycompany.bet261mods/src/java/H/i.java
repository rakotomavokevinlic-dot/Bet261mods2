package h;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class i extends BaseAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f649a = -1;
    public final /* synthetic */ j b;

    public i(j jVar) {
        this.b = jVar;
        a();
    }

    public final void a() {
        n nVar = this.b.f651c;
        p pVar = nVar.f678v;
        if (pVar != null) {
            nVar.i();
            ArrayList arrayList = nVar.f666j;
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (((p) arrayList.get(i2)) == pVar) {
                    this.f649a = i2;
                    return;
                }
            }
        }
        this.f649a = -1;
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public final p getItem(int i2) {
        j jVar = this.b;
        n nVar = jVar.f651c;
        nVar.i();
        ArrayList arrayList = nVar.f666j;
        jVar.getClass();
        int i3 = this.f649a;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return (p) arrayList.get(i2);
    }

    @Override // android.widget.Adapter
    public final int getCount() {
        j jVar = this.b;
        n nVar = jVar.f651c;
        nVar.i();
        int size = nVar.f666j.size();
        jVar.getClass();
        return this.f649a < 0 ? size : size - 1;
    }

    @Override // android.widget.Adapter
    public final long getItemId(int i2) {
        return i2;
    }

    @Override // android.widget.Adapter
    public final View getView(int i2, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.b.b.inflate(2131427344, viewGroup, false);
        }
        ((InterfaceC0031A) view).c(getItem(i2));
        return view;
    }

    @Override // android.widget.BaseAdapter
    public final void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
