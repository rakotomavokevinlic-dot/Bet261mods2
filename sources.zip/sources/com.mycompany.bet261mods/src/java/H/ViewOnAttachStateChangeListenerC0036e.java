package h;

import android.view.View;
import android.view.ViewTreeObserver;

/* JADX INFO: renamed from: h.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class ViewOnAttachStateChangeListenerC0036e implements View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f620a;
    public final /* synthetic */ v b;

    public /* synthetic */ ViewOnAttachStateChangeListenerC0036e(v vVar, int i2) {
        this.f620a = i2;
        this.b = vVar;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        int i2 = this.f620a;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        switch (this.f620a) {
            case 0:
                h hVar = (h) this.b;
                ViewTreeObserver viewTreeObserver = hVar.f646x;
                if (viewTreeObserver != null) {
                    if (!viewTreeObserver.isAlive()) {
                        hVar.f646x = view.getViewTreeObserver();
                    }
                    hVar.f646x.removeGlobalOnLayoutListener(hVar.f631i);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
            default:
                E e2 = (E) this.b;
                ViewTreeObserver viewTreeObserver2 = e2.f595o;
                if (viewTreeObserver2 != null) {
                    if (!viewTreeObserver2.isAlive()) {
                        e2.f595o = view.getViewTreeObserver();
                    }
                    e2.f595o.removeGlobalOnLayoutListener(e2.f589i);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
        }
    }

    private final void a(View view) {
    }

    private final void b(View view) {
    }
}
