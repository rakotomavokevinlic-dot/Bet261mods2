package h;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface y {
    void b(n nVar, boolean z2);

    boolean m(n nVar);
}
