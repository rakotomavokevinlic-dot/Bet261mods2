package h;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import java.util.ArrayList;
import s.AbstractC0120a;
import t.InterfaceMenuItemC0123a;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class p implements InterfaceMenuItemC0123a {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public q f683A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public MenuItem.OnActionExpandListener f684B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f686a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f687c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f688d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public CharSequence f689e;
    public CharSequence f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Intent f690g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public char f691h;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public char f693j;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Drawable f695l;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final n f697n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public F f698o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public MenuItem.OnMenuItemClickListener f699p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public CharSequence f700q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public CharSequence f701r;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f708y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public View f709z;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f692i = 4096;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f694k = 4096;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f696m = 0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public ColorStateList f702s = null;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public PorterDuff.Mode f703t = null;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f704u = false;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f705v = false;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f706w = false;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f707x = 16;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f685C = false;

    public p(n nVar, int i2, int i3, int i4, int i5, CharSequence charSequence, int i6) {
        this.f697n = nVar;
        this.f686a = i3;
        this.b = i2;
        this.f687c = i4;
        this.f688d = i5;
        this.f689e = charSequence;
        this.f708y = i6;
    }

    public static void c(StringBuilder sb, int i2, int i3, String str) {
        if ((i2 & i3) == i3) {
            sb.append(str);
        }
    }

    @Override // t.InterfaceMenuItemC0123a
    public final q a() {
        return this.f683A;
    }

    @Override // t.InterfaceMenuItemC0123a
    public final InterfaceMenuItemC0123a b(q qVar) {
        this.f709z = null;
        this.f683A = qVar;
        this.f697n.p(true);
        q qVar2 = this.f683A;
        if (qVar2 != null) {
            qVar2.f710a = new C.j(16, this);
            qVar2.b.setVisibilityListener(qVar2);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public final boolean collapseActionView() {
        if ((this.f708y & 8) == 0) {
            return false;
        }
        if (this.f709z == null) {
            return true;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f684B;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(this)) {
            return this.f697n.d(this);
        }
        return false;
    }

    public final Drawable d(Drawable drawable) {
        if (drawable != null && this.f706w && (this.f704u || this.f705v)) {
            drawable = drawable.mutate();
            if (this.f704u) {
                AbstractC0120a.h(drawable, this.f702s);
            }
            if (this.f705v) {
                AbstractC0120a.i(drawable, this.f703t);
            }
            this.f706w = false;
        }
        return drawable;
    }

    public final boolean e() {
        q qVar;
        if ((this.f708y & 8) != 0) {
            if (this.f709z == null && (qVar = this.f683A) != null) {
                this.f709z = qVar.b.onCreateActionView(this);
            }
            if (this.f709z != null) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.MenuItem
    public final boolean expandActionView() {
        if (!e()) {
            return false;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f684B;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand(this)) {
            return this.f697n.f(this);
        }
        return false;
    }

    public final void f(boolean z2) {
        if (z2) {
            this.f707x |= 32;
        } else {
            this.f707x &= -33;
        }
    }

    @Override // android.view.MenuItem
    public final ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    @Override // android.view.MenuItem
    public final View getActionView() {
        View view = this.f709z;
        if (view != null) {
            return view;
        }
        q qVar = this.f683A;
        if (qVar == null) {
            return null;
        }
        View viewOnCreateActionView = qVar.b.onCreateActionView(this);
        this.f709z = viewOnCreateActionView;
        return viewOnCreateActionView;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final int getAlphabeticModifiers() {
        return this.f694k;
    }

    @Override // android.view.MenuItem
    public final char getAlphabeticShortcut() {
        return this.f693j;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final CharSequence getContentDescription() {
        return this.f700q;
    }

    @Override // android.view.MenuItem
    public final int getGroupId() {
        return this.b;
    }

    @Override // android.view.MenuItem
    public final Drawable getIcon() {
        Drawable drawable = this.f695l;
        if (drawable != null) {
            return d(drawable);
        }
        int i2 = this.f696m;
        if (i2 == 0) {
            return null;
        }
        Drawable drawableW = D.g.w(this.f697n.f659a, i2);
        this.f696m = 0;
        this.f695l = drawableW;
        return d(drawableW);
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final ColorStateList getIconTintList() {
        return this.f702s;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final PorterDuff.Mode getIconTintMode() {
        return this.f703t;
    }

    @Override // android.view.MenuItem
    public final Intent getIntent() {
        return this.f690g;
    }

    @Override // android.view.MenuItem
    public final int getItemId() {
        return this.f686a;
    }

    @Override // android.view.MenuItem
    public final ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final int getNumericModifiers() {
        return this.f692i;
    }

    @Override // android.view.MenuItem
    public final char getNumericShortcut() {
        return this.f691h;
    }

    @Override // android.view.MenuItem
    public final int getOrder() {
        return this.f687c;
    }

    @Override // android.view.MenuItem
    public final SubMenu getSubMenu() {
        return this.f698o;
    }

    @Override // android.view.MenuItem
    public final CharSequence getTitle() {
        return this.f689e;
    }

    @Override // android.view.MenuItem
    public final CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f;
        return charSequence != null ? charSequence : this.f689e;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final CharSequence getTooltipText() {
        return this.f701r;
    }

    @Override // android.view.MenuItem
    public final boolean hasSubMenu() {
        return this.f698o != null;
    }

    @Override // android.view.MenuItem
    public final boolean isActionViewExpanded() {
        return this.f685C;
    }

    @Override // android.view.MenuItem
    public final boolean isCheckable() {
        return (this.f707x & 1) == 1;
    }

    @Override // android.view.MenuItem
    public final boolean isChecked() {
        return (this.f707x & 2) == 2;
    }

    @Override // android.view.MenuItem
    public final boolean isEnabled() {
        return (this.f707x & 16) != 0;
    }

    @Override // android.view.MenuItem
    public final boolean isVisible() {
        q qVar = this.f683A;
        return (qVar == null || !qVar.b.overridesItemVisibility()) ? (this.f707x & 8) == 0 : (this.f707x & 8) == 0 && this.f683A.b.isVisible();
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionView(View view) {
        int i2;
        this.f709z = view;
        this.f683A = null;
        if (view != null && view.getId() == -1 && (i2 = this.f686a) > 0) {
            view.setId(i2);
        }
        n nVar = this.f697n;
        nVar.f667k = true;
        nVar.p(true);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setAlphabeticShortcut(char c2) {
        if (this.f693j == c2) {
            return this;
        }
        this.f693j = Character.toLowerCase(c2);
        this.f697n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setCheckable(boolean z2) {
        int i2 = this.f707x;
        int i3 = (z2 ? 1 : 0) | (i2 & (-2));
        this.f707x = i3;
        if (i2 != i3) {
            this.f697n.p(false);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setChecked(boolean z2) {
        int i2 = this.f707x;
        if ((i2 & 4) == 0) {
            int i3 = (i2 & (-3)) | (z2 ? 2 : 0);
            this.f707x = i3;
            if (i2 != i3) {
                this.f697n.p(false);
            }
            return this;
        }
        n nVar = this.f697n;
        nVar.getClass();
        ArrayList arrayList = nVar.f;
        int size = arrayList.size();
        nVar.w();
        for (int i4 = 0; i4 < size; i4++) {
            p pVar = (p) arrayList.get(i4);
            if (pVar.b == this.b && (pVar.f707x & 4) != 0 && pVar.isCheckable()) {
                boolean z3 = pVar == this;
                int i5 = pVar.f707x;
                int i6 = (z3 ? 2 : 0) | (i5 & (-3));
                pVar.f707x = i6;
                if (i5 != i6) {
                    pVar.f697n.p(false);
                }
            }
        }
        nVar.v();
        return this;
    }

    @Override // android.view.MenuItem
    public final /* bridge */ /* synthetic */ MenuItem setContentDescription(CharSequence charSequence) {
        setContentDescription(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setEnabled(boolean z2) {
        if (z2) {
            this.f707x |= 16;
        } else {
            this.f707x &= -17;
        }
        this.f697n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIcon(Drawable drawable) {
        this.f696m = 0;
        this.f695l = drawable;
        this.f706w = true;
        this.f697n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f702s = colorStateList;
        this.f704u = true;
        this.f706w = true;
        this.f697n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f703t = mode;
        this.f705v = true;
        this.f706w = true;
        this.f697n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIntent(Intent intent) {
        this.f690g = intent;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setNumericShortcut(char c2) {
        if (this.f691h == c2) {
            return this;
        }
        this.f691h = c2;
        this.f697n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f684B = onActionExpandListener;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f699p = onMenuItemClickListener;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setShortcut(char c2, char c3) {
        this.f691h = c2;
        this.f693j = Character.toLowerCase(c3);
        this.f697n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final void setShowAsAction(int i2) {
        int i3 = i2 & 3;
        if (i3 != 0 && i3 != 1 && i3 != 2) {
            throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
        }
        this.f708y = i2;
        n nVar = this.f697n;
        nVar.f667k = true;
        nVar.p(true);
    }

    @Override // android.view.MenuItem
    public final MenuItem setShowAsActionFlags(int i2) {
        setShowAsAction(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitle(CharSequence charSequence) {
        this.f689e = charSequence;
        this.f697n.p(false);
        F f = this.f698o;
        if (f != null) {
            f.setHeaderTitle(charSequence);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f = charSequence;
        this.f697n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final /* bridge */ /* synthetic */ MenuItem setTooltipText(CharSequence charSequence) {
        setTooltipText(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setVisible(boolean z2) {
        int i2 = this.f707x;
        int i3 = (z2 ? 0 : 8) | (i2 & (-9));
        this.f707x = i3;
        if (i2 != i3) {
            n nVar = this.f697n;
            nVar.f664h = true;
            nVar.p(true);
        }
        return this;
    }

    public final String toString() {
        CharSequence charSequence = this.f689e;
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final InterfaceMenuItemC0123a setContentDescription(CharSequence charSequence) {
        this.f700q = charSequence;
        this.f697n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final InterfaceMenuItemC0123a setTooltipText(CharSequence charSequence) {
        this.f701r = charSequence;
        this.f697n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setAlphabeticShortcut(char c2, int i2) {
        if (this.f693j == c2 && this.f694k == i2) {
            return this;
        }
        this.f693j = Character.toLowerCase(c2);
        this.f694k = KeyEvent.normalizeMetaState(i2);
        this.f697n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setNumericShortcut(char c2, int i2) {
        if (this.f691h == c2 && this.f692i == i2) {
            return this;
        }
        this.f691h = c2;
        this.f692i = KeyEvent.normalizeMetaState(i2);
        this.f697n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0123a, android.view.MenuItem
    public final MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f691h = c2;
        this.f692i = KeyEvent.normalizeMetaState(i2);
        this.f693j = Character.toLowerCase(c3);
        this.f694k = KeyEvent.normalizeMetaState(i3);
        this.f697n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIcon(int i2) {
        this.f695l = null;
        this.f696m = i2;
        this.f706w = true;
        this.f697n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitle(int i2) {
        setTitle(this.f697n.f659a.getString(i2));
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionView(int i2) {
        int i3;
        Context context = this.f697n.f659a;
        View viewInflate = LayoutInflater.from(context).inflate(i2, (ViewGroup) new LinearLayout(context), false);
        this.f709z = viewInflate;
        this.f683A = null;
        if (viewInflate != null && viewInflate.getId() == -1 && (i3 = this.f686a) > 0) {
            viewInflate.setId(i3);
        }
        n nVar = this.f697n;
        nVar.f667k = true;
        nVar.p(true);
        return this;
    }
}
