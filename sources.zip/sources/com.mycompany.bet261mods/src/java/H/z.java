package h;

import android.content.Context;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public interface z {
    void b(n nVar, boolean z2);

    void c();

    boolean d(p pVar);

    void e(y yVar);

    void g(Context context, n nVar);

    boolean i();

    boolean j(F f);

    boolean k(p pVar);
}
