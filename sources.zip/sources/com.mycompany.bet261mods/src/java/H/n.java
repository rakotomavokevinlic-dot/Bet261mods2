package h;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import p.AbstractC0114a;
import y.L;
import y.N;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public class n implements Menu {

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final int[] f658y = {1, 4, 5, 3, 2, 0};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f659a;
    public final Resources b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f660c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f661d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public l f662e;
    public final ArrayList f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ArrayList f663g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f664h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ArrayList f665i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final ArrayList f666j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f667k;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public CharSequence f669m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Drawable f670n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public View f671o;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public p f678v;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f680x;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f668l = 0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f672p = false;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f673q = false;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f674r = false;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f675s = false;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final ArrayList f676t = new ArrayList();

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final CopyOnWriteArrayList f677u = new CopyOnWriteArrayList();

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f679w = false;

    public n(Context context) {
        boolean zB;
        boolean z2 = false;
        this.f659a = context;
        Resources resources = context.getResources();
        this.b = resources;
        this.f = new ArrayList();
        this.f663g = new ArrayList();
        this.f664h = true;
        this.f665i = new ArrayList();
        this.f666j = new ArrayList();
        this.f667k = true;
        if (resources.getConfiguration().keyboard != 1) {
            ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
            int i2 = N.f1169a;
            if (Build.VERSION.SDK_INT >= 28) {
                zB = L.b(viewConfiguration);
            } else {
                Resources resources2 = context.getResources();
                int identifier = resources2.getIdentifier("config_showMenuShortcutsWhenKeyboardPresent", "bool", "android");
                zB = identifier != 0 && resources2.getBoolean(identifier);
            }
            if (zB) {
                z2 = true;
            }
        }
        this.f661d = z2;
    }

    public final p a(int i2, int i3, int i4, CharSequence charSequence) {
        int i5;
        int i6 = ((-65536) & i4) >> 16;
        if (i6 < 0 || i6 >= 6) {
            throw new IllegalArgumentException("order does not contain a valid category.");
        }
        int i7 = (f658y[i6] << 16) | (65535 & i4);
        p pVar = new p(this, i2, i3, i4, i7, charSequence, this.f668l);
        ArrayList arrayList = this.f;
        int size = arrayList.size() - 1;
        while (true) {
            if (size < 0) {
                i5 = 0;
                break;
            }
            if (((p) arrayList.get(size)).f688d <= i7) {
                i5 = size + 1;
                break;
            }
            size--;
        }
        arrayList.add(i5, pVar);
        p(true);
        return pVar;
    }

    @Override // android.view.Menu
    public final MenuItem add(CharSequence charSequence) {
        return a(0, 0, 0, charSequence);
    }

    @Override // android.view.Menu
    public final int addIntentOptions(int i2, int i3, int i4, ComponentName componentName, Intent[] intentArr, Intent intent, int i5, MenuItem[] menuItemArr) {
        int i6;
        PackageManager packageManager = this.f659a.getPackageManager();
        List<ResolveInfo> listQueryIntentActivityOptions = packageManager.queryIntentActivityOptions(componentName, intentArr, intent, 0);
        int size = listQueryIntentActivityOptions != null ? listQueryIntentActivityOptions.size() : 0;
        if ((i5 & 1) == 0) {
            removeGroup(i2);
        }
        for (int i7 = 0; i7 < size; i7++) {
            ResolveInfo resolveInfo = listQueryIntentActivityOptions.get(i7);
            int i8 = resolveInfo.specificIndex;
            Intent intent2 = new Intent(i8 < 0 ? intent : intentArr[i8]);
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            intent2.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
            p pVarA = a(i2, i3, i4, resolveInfo.loadLabel(packageManager));
            pVarA.setIcon(resolveInfo.loadIcon(packageManager));
            pVarA.f690g = intent2;
            if (menuItemArr != null && (i6 = resolveInfo.specificIndex) >= 0) {
                menuItemArr[i6] = pVarA;
            }
        }
        return size;
    }

    @Override // android.view.Menu
    public final SubMenu addSubMenu(CharSequence charSequence) {
        return addSubMenu(0, 0, 0, charSequence);
    }

    public final void b(z zVar, Context context) {
        this.f677u.add(new WeakReference(zVar));
        zVar.g(context, this);
        this.f667k = true;
    }

    public final void c(boolean z2) {
        if (this.f675s) {
            return;
        }
        this.f675s = true;
        CopyOnWriteArrayList<WeakReference> copyOnWriteArrayList = this.f677u;
        for (WeakReference weakReference : copyOnWriteArrayList) {
            z zVar = (z) weakReference.get();
            if (zVar == null) {
                copyOnWriteArrayList.remove(weakReference);
            } else {
                zVar.b(this, z2);
            }
        }
        this.f675s = false;
    }

    @Override // android.view.Menu
    public final void clear() {
        p pVar = this.f678v;
        if (pVar != null) {
            d(pVar);
        }
        this.f.clear();
        p(true);
    }

    public final void clearHeader() {
        this.f670n = null;
        this.f669m = null;
        this.f671o = null;
        p(false);
    }

    @Override // android.view.Menu
    public final void close() {
        c(true);
    }

    public boolean d(p pVar) {
        CopyOnWriteArrayList<WeakReference> copyOnWriteArrayList = this.f677u;
        boolean zD = false;
        if (!copyOnWriteArrayList.isEmpty() && this.f678v == pVar) {
            w();
            for (WeakReference weakReference : copyOnWriteArrayList) {
                z zVar = (z) weakReference.get();
                if (zVar != null) {
                    zD = zVar.d(pVar);
                    if (zD) {
                        break;
                    }
                } else {
                    copyOnWriteArrayList.remove(weakReference);
                }
            }
            v();
            if (zD) {
                this.f678v = null;
            }
        }
        return zD;
    }

    public boolean e(n nVar, MenuItem menuItem) {
        l lVar = this.f662e;
        return lVar != null && lVar.h(nVar, menuItem);
    }

    public boolean f(p pVar) {
        CopyOnWriteArrayList<WeakReference> copyOnWriteArrayList = this.f677u;
        boolean zK = false;
        if (copyOnWriteArrayList.isEmpty()) {
            return false;
        }
        w();
        for (WeakReference weakReference : copyOnWriteArrayList) {
            z zVar = (z) weakReference.get();
            if (zVar != null) {
                zK = zVar.k(pVar);
                if (zK) {
                    break;
                }
            } else {
                copyOnWriteArrayList.remove(weakReference);
            }
        }
        v();
        if (zK) {
            this.f678v = pVar;
        }
        return zK;
    }

    @Override // android.view.Menu
    public final MenuItem findItem(int i2) {
        MenuItem menuItemFindItem;
        ArrayList arrayList = this.f;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            p pVar = (p) arrayList.get(i3);
            if (pVar.f686a == i2) {
                return pVar;
            }
            if (pVar.hasSubMenu() && (menuItemFindItem = pVar.f698o.findItem(i2)) != null) {
                return menuItemFindItem;
            }
        }
        return null;
    }

    public final p g(int i2, KeyEvent keyEvent) {
        ArrayList arrayList = this.f676t;
        arrayList.clear();
        h(arrayList, i2, keyEvent);
        if (arrayList.isEmpty()) {
            return null;
        }
        int metaState = keyEvent.getMetaState();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        keyEvent.getKeyData(keyData);
        int size = arrayList.size();
        if (size == 1) {
            return (p) arrayList.get(0);
        }
        boolean zN = n();
        for (int i3 = 0; i3 < size; i3++) {
            p pVar = (p) arrayList.get(i3);
            char c2 = zN ? pVar.f693j : pVar.f691h;
            char[] cArr = keyData.meta;
            if ((c2 == cArr[0] && (metaState & 2) == 0) || ((c2 == cArr[2] && (metaState & 2) != 0) || (zN && c2 == '\b' && i2 == 67))) {
                return pVar;
            }
        }
        return null;
    }

    @Override // android.view.Menu
    public final MenuItem getItem(int i2) {
        return (MenuItem) this.f.get(i2);
    }

    public final void h(ArrayList arrayList, int i2, KeyEvent keyEvent) {
        boolean zN = n();
        int modifiers = keyEvent.getModifiers();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        if (keyEvent.getKeyData(keyData) || i2 == 67) {
            ArrayList arrayList2 = this.f;
            int size = arrayList2.size();
            for (int i3 = 0; i3 < size; i3++) {
                p pVar = (p) arrayList2.get(i3);
                if (pVar.hasSubMenu()) {
                    pVar.f698o.h(arrayList, i2, keyEvent);
                }
                char c2 = zN ? pVar.f693j : pVar.f691h;
                if ((modifiers & 69647) == ((zN ? pVar.f694k : pVar.f692i) & 69647) && c2 != 0) {
                    char[] cArr = keyData.meta;
                    if ((c2 == cArr[0] || c2 == cArr[2] || (zN && c2 == '\b' && i2 == 67)) && pVar.isEnabled()) {
                        arrayList.add(pVar);
                    }
                }
            }
        }
    }

    @Override // android.view.Menu
    public final boolean hasVisibleItems() {
        if (this.f680x) {
            return true;
        }
        ArrayList arrayList = this.f;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (((p) arrayList.get(i2)).isVisible()) {
                return true;
            }
        }
        return false;
    }

    public final void i() {
        ArrayList arrayListL = l();
        if (this.f667k) {
            CopyOnWriteArrayList<WeakReference> copyOnWriteArrayList = this.f677u;
            boolean zI = false;
            for (WeakReference weakReference : copyOnWriteArrayList) {
                z zVar = (z) weakReference.get();
                if (zVar == null) {
                    copyOnWriteArrayList.remove(weakReference);
                } else {
                    zI |= zVar.i();
                }
            }
            ArrayList arrayList = this.f665i;
            ArrayList arrayList2 = this.f666j;
            if (zI) {
                arrayList.clear();
                arrayList2.clear();
                int size = arrayListL.size();
                for (int i2 = 0; i2 < size; i2++) {
                    p pVar = (p) arrayListL.get(i2);
                    if ((pVar.f707x & 32) == 32) {
                        arrayList.add(pVar);
                    } else {
                        arrayList2.add(pVar);
                    }
                }
            } else {
                arrayList.clear();
                arrayList2.clear();
                arrayList2.addAll(l());
            }
            this.f667k = false;
        }
    }

    @Override // android.view.Menu
    public final boolean isShortcutKey(int i2, KeyEvent keyEvent) {
        return g(i2, keyEvent) != null;
    }

    public String j() {
        return "android:menu:actionviewstates";
    }

    public final ArrayList l() {
        boolean z2 = this.f664h;
        ArrayList arrayList = this.f663g;
        if (!z2) {
            return arrayList;
        }
        arrayList.clear();
        ArrayList arrayList2 = this.f;
        int size = arrayList2.size();
        for (int i2 = 0; i2 < size; i2++) {
            p pVar = (p) arrayList2.get(i2);
            if (pVar.isVisible()) {
                arrayList.add(pVar);
            }
        }
        this.f664h = false;
        this.f667k = true;
        return arrayList;
    }

    public boolean m() {
        return this.f679w;
    }

    public boolean n() {
        return this.f660c;
    }

    public boolean o() {
        return this.f661d;
    }

    public final void p(boolean z2) {
        if (this.f672p) {
            this.f673q = true;
            if (z2) {
                this.f674r = true;
                return;
            }
            return;
        }
        if (z2) {
            this.f664h = true;
            this.f667k = true;
        }
        CopyOnWriteArrayList<WeakReference> copyOnWriteArrayList = this.f677u;
        if (copyOnWriteArrayList.isEmpty()) {
            return;
        }
        w();
        for (WeakReference weakReference : copyOnWriteArrayList) {
            z zVar = (z) weakReference.get();
            if (zVar == null) {
                copyOnWriteArrayList.remove(weakReference);
            } else {
                zVar.c();
            }
        }
        v();
    }

    @Override // android.view.Menu
    public final boolean performIdentifierAction(int i2, int i3) {
        return q(findItem(i2), null, i3);
    }

    @Override // android.view.Menu
    public final boolean performShortcut(int i2, KeyEvent keyEvent, int i3) {
        p pVarG = g(i2, keyEvent);
        boolean zQ = pVarG != null ? q(pVarG, null, i3) : false;
        if ((i3 & 2) != 0) {
            c(true);
        }
        return zQ;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0018  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0058  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0064  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean q(android.view.MenuItem r7, h.z r8, int r9) {
        /*
            Method dump skipped, instruction units count: 213
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h.n.q(android.view.MenuItem, h.z, int):boolean");
    }

    public final void r(z zVar) {
        CopyOnWriteArrayList<WeakReference> copyOnWriteArrayList = this.f677u;
        for (WeakReference weakReference : copyOnWriteArrayList) {
            z zVar2 = (z) weakReference.get();
            if (zVar2 == null || zVar2 == zVar) {
                copyOnWriteArrayList.remove(weakReference);
            }
        }
    }

    @Override // android.view.Menu
    public final void removeGroup(int i2) {
        ArrayList arrayList = this.f;
        int size = arrayList.size();
        int i3 = 0;
        int i4 = 0;
        while (true) {
            if (i4 >= size) {
                i4 = -1;
                break;
            } else if (((p) arrayList.get(i4)).b == i2) {
                break;
            } else {
                i4++;
            }
        }
        if (i4 >= 0) {
            int size2 = arrayList.size() - i4;
            while (true) {
                int i5 = i3 + 1;
                if (i3 >= size2 || ((p) arrayList.get(i4)).b != i2) {
                    break;
                }
                if (i4 >= 0) {
                    ArrayList arrayList2 = this.f;
                    if (i4 < arrayList2.size()) {
                        arrayList2.remove(i4);
                    }
                }
                i3 = i5;
            }
            p(true);
        }
    }

    @Override // android.view.Menu
    public final void removeItem(int i2) {
        ArrayList arrayList = this.f;
        int size = arrayList.size();
        int i3 = 0;
        while (true) {
            if (i3 >= size) {
                i3 = -1;
                break;
            } else if (((p) arrayList.get(i3)).f686a == i2) {
                break;
            } else {
                i3++;
            }
        }
        if (i3 >= 0) {
            ArrayList arrayList2 = this.f;
            if (i3 >= arrayList2.size()) {
                return;
            }
            arrayList2.remove(i3);
            p(true);
        }
    }

    public final void s(Bundle bundle) {
        MenuItem menuItemFindItem;
        if (bundle == null) {
            return;
        }
        SparseArray<Parcelable> sparseParcelableArray = bundle.getSparseParcelableArray(j());
        int size = this.f.size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = getItem(i2);
            View actionView = item.getActionView();
            if (actionView != null && actionView.getId() != -1) {
                actionView.restoreHierarchyState(sparseParcelableArray);
            }
            if (item.hasSubMenu()) {
                ((F) item.getSubMenu()).s(bundle);
            }
        }
        int i3 = bundle.getInt("android:menu:expandedactionview");
        if (i3 <= 0 || (menuItemFindItem = findItem(i3)) == null) {
            return;
        }
        menuItemFindItem.expandActionView();
    }

    @Override // android.view.Menu
    public final void setGroupCheckable(int i2, boolean z2, boolean z3) {
        ArrayList arrayList = this.f;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            p pVar = (p) arrayList.get(i3);
            if (pVar.b == i2) {
                pVar.f707x = (pVar.f707x & (-5)) | (z3 ? 4 : 0);
                pVar.setCheckable(z2);
            }
        }
    }

    @Override // android.view.Menu
    public void setGroupDividerEnabled(boolean z2) {
        this.f679w = z2;
    }

    @Override // android.view.Menu
    public final void setGroupEnabled(int i2, boolean z2) {
        ArrayList arrayList = this.f;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            p pVar = (p) arrayList.get(i3);
            if (pVar.b == i2) {
                pVar.setEnabled(z2);
            }
        }
    }

    @Override // android.view.Menu
    public final void setGroupVisible(int i2, boolean z2) {
        ArrayList arrayList = this.f;
        int size = arrayList.size();
        boolean z3 = false;
        for (int i3 = 0; i3 < size; i3++) {
            p pVar = (p) arrayList.get(i3);
            if (pVar.b == i2) {
                int i4 = pVar.f707x;
                int i5 = (i4 & (-9)) | (z2 ? 0 : 8);
                pVar.f707x = i5;
                if (i4 != i5) {
                    z3 = true;
                }
            }
        }
        if (z3) {
            p(true);
        }
    }

    @Override // android.view.Menu
    public void setQwertyMode(boolean z2) {
        this.f660c = z2;
        p(false);
    }

    @Override // android.view.Menu
    public final int size() {
        return this.f.size();
    }

    public final void t(Bundle bundle) {
        int size = this.f.size();
        SparseArray<? extends Parcelable> sparseArray = null;
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = getItem(i2);
            View actionView = item.getActionView();
            if (actionView != null && actionView.getId() != -1) {
                if (sparseArray == null) {
                    sparseArray = new SparseArray<>();
                }
                actionView.saveHierarchyState(sparseArray);
                if (item.isActionViewExpanded()) {
                    bundle.putInt("android:menu:expandedactionview", item.getItemId());
                }
            }
            if (item.hasSubMenu()) {
                ((F) item.getSubMenu()).t(bundle);
            }
        }
        if (sparseArray != null) {
            bundle.putSparseParcelableArray(j(), sparseArray);
        }
    }

    public final void u(int i2, CharSequence charSequence, int i3, Drawable drawable, View view) {
        if (view != null) {
            this.f671o = view;
            this.f669m = null;
            this.f670n = null;
        } else {
            if (i2 > 0) {
                this.f669m = this.b.getText(i2);
            } else if (charSequence != null) {
                this.f669m = charSequence;
            }
            if (i3 > 0) {
                this.f670n = AbstractC0114a.b(this.f659a, i3);
            } else if (drawable != null) {
                this.f670n = drawable;
            }
            this.f671o = null;
        }
        p(false);
    }

    public final void v() {
        this.f672p = false;
        if (this.f673q) {
            this.f673q = false;
            p(this.f674r);
        }
    }

    public final void w() {
        if (this.f672p) {
            return;
        }
        this.f672p = true;
        this.f673q = false;
        this.f674r = false;
    }

    @Override // android.view.Menu
    public final MenuItem add(int i2) {
        return a(0, 0, 0, this.b.getString(i2));
    }

    @Override // android.view.Menu
    public final SubMenu addSubMenu(int i2) {
        return addSubMenu(0, 0, 0, this.b.getString(i2));
    }

    @Override // android.view.Menu
    public final MenuItem add(int i2, int i3, int i4, CharSequence charSequence) {
        return a(i2, i3, i4, charSequence);
    }

    @Override // android.view.Menu
    public final SubMenu addSubMenu(int i2, int i3, int i4, CharSequence charSequence) {
        p pVarA = a(i2, i3, i4, charSequence);
        F f = new F(this.f659a, this, pVarA);
        pVarA.f698o = f;
        f.setHeaderTitle(pVarA.f689e);
        return f;
    }

    @Override // android.view.Menu
    public final MenuItem add(int i2, int i3, int i4, int i5) {
        return a(i2, i3, i4, this.b.getString(i5));
    }

    @Override // android.view.Menu
    public final SubMenu addSubMenu(int i2, int i3, int i4, int i5) {
        return addSubMenu(i2, i3, i4, this.b.getString(i5));
    }

    public n k() {
        return this;
    }
}
