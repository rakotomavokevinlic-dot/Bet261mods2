package F;

import android.os.Build;
import android.view.View;
import java.nio.ByteBuffer;
import y.C0149a;
import y.C0150b;
import y.K;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f53a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f54c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f55d;

    public c() {
        if (d.b == null) {
            d.b = new d(0);
        }
    }

    public int a(int i2) {
        if (i2 < this.f54c) {
            return ((ByteBuffer) this.f55d).getShort(this.b + i2);
        }
        return 0;
    }

    public abstract Object b(View view);

    public abstract void c(View view, Object obj);

    public void d(View view, Object obj) {
        Object tag;
        if (Build.VERSION.SDK_INT >= this.b) {
            c(view, obj);
            return;
        }
        if (Build.VERSION.SDK_INT >= this.b) {
            tag = b(view);
        } else {
            tag = view.getTag(this.f53a);
            if (!((Class) this.f55d).isInstance(tag)) {
                tag = null;
            }
        }
        if (e(tag, obj)) {
            View.AccessibilityDelegate accessibilityDelegateC = K.c(view);
            C0150b c0150b = accessibilityDelegateC == null ? null : accessibilityDelegateC instanceof C0149a ? ((C0149a) accessibilityDelegateC).f1190a : new C0150b(accessibilityDelegateC);
            if (c0150b == null) {
                c0150b = new C0150b();
            }
            K.h(view, c0150b);
            view.setTag(this.f53a, obj);
            K.e(view, this.f54c);
        }
    }

    public abstract boolean e(Object obj, Object obj2);
}
