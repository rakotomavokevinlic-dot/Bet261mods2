package r;

import android.graphics.Insets;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class b {
    public static Insets a(int i2, int i3, int i4, int i5) {
        return Insets.of(i2, i3, i4, i5);
    }
}
