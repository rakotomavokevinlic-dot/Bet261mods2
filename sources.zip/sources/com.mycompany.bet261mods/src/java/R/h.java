package r;

import android.content.Context;
import android.graphics.Typeface;
import android.net.Uri;
import android.util.Log;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;
import l.C0103k;
import v.C0135g;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class h extends D.g {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final Class f1128o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final Constructor f1129p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final Method f1130q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final Method f1131r;

    static {
        Class<?> cls;
        Method method;
        Method method2;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            Class cls2 = Integer.TYPE;
            method2 = cls.getMethod("addFontWeightStyle", ByteBuffer.class, cls2, List.class, cls2, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi24Impl", e2.getClass().getName(), e2);
            cls = null;
            method = null;
            method2 = null;
        }
        f1129p = constructor;
        f1128o = cls;
        f1130q = method2;
        f1131r = method;
    }

    public static boolean k0(Object obj, ByteBuffer byteBuffer, int i2, int i3, boolean z2) {
        try {
            return ((Boolean) f1130q.invoke(obj, byteBuffer, Integer.valueOf(i2), null, Integer.valueOf(i3), Boolean.valueOf(z2))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public static Typeface l0(Object obj) {
        try {
            Object objNewInstance = Array.newInstance((Class<?>) f1128o, 1);
            Array.set(objNewInstance, 0, obj);
            return (Typeface) f1131r.invoke(null, objNewInstance);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x005b  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0067 A[SYNTHETIC] */
    @Override // D.g
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.graphics.Typeface l(android.content.Context r17, q.f r18, android.content.res.Resources r19, int r20) throws java.lang.IllegalAccessException, java.lang.InstantiationException, java.lang.reflect.InvocationTargetException {
        /*
            r16 = this;
            r1 = 0
            java.lang.reflect.Constructor r0 = r.h.f1129p     // Catch: java.lang.Throwable -> L9
            java.lang.Object r0 = r0.newInstance(r1)     // Catch: java.lang.Throwable -> L9
            r2 = r0
            goto La
        L9:
            r2 = r1
        La:
            if (r2 != 0) goto Ld
            goto L67
        Ld:
            r0 = r18
            q.g[] r3 = r0.f1094a
            int r4 = r3.length
            r0 = 0
            r5 = r0
        L14:
            if (r5 >= r4) goto L70
            r6 = r3[r5]
            int r0 = r6.f
            java.io.File r7 = D.g.B(r17)
            if (r7 != 0) goto L24
            r8 = r19
        L22:
            r0 = r1
            goto L58
        L24:
            r8 = r19
            boolean r0 = D.g.i(r7, r8, r0)     // Catch: java.lang.Throwable -> L6b
            if (r0 != 0) goto L30
            r7.delete()
            goto L22
        L30:
            java.io.FileInputStream r9 = new java.io.FileInputStream     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L6b
            r9.<init>(r7)     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L6b
            java.nio.channels.FileChannel r10 = r9.getChannel()     // Catch: java.lang.Throwable -> L49
            long r14 = r10.size()     // Catch: java.lang.Throwable -> L49
            java.nio.channels.FileChannel$MapMode r11 = java.nio.channels.FileChannel.MapMode.READ_ONLY     // Catch: java.lang.Throwable -> L49
            r12 = 0
            java.nio.MappedByteBuffer r0 = r10.map(r11, r12, r14)     // Catch: java.lang.Throwable -> L49
            r9.close()     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L6b
            goto L55
        L49:
            r0 = move-exception
            r10 = r0
            r9.close()     // Catch: java.lang.Throwable -> L4f
            goto L53
        L4f:
            r0 = move-exception
            r10.addSuppressed(r0)     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L6b
        L53:
            throw r10     // Catch: java.io.IOException -> L54 java.lang.Throwable -> L6b
        L54:
            r0 = r1
        L55:
            r7.delete()
        L58:
            if (r0 != 0) goto L5b
            goto L67
        L5b:
            int r7 = r6.b
            boolean r9 = r6.f1096c
            int r6 = r6.f1098e
            boolean r0 = k0(r2, r0, r6, r7, r9)
            if (r0 != 0) goto L68
        L67:
            return r1
        L68:
            int r5 = r5 + 1
            goto L14
        L6b:
            r0 = move-exception
            r7.delete()
            throw r0
        L70:
            android.graphics.Typeface r0 = l0(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: r.h.l(android.content.Context, q.f, android.content.res.Resources, int):android.graphics.Typeface");
    }

    @Override // D.g
    public final Typeface m(Context context, C0135g[] c0135gArr, int i2) {
        Object objNewInstance;
        try {
            objNewInstance = f1129p.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            objNewInstance = null;
        }
        if (objNewInstance != null) {
            C0103k c0103k = new C0103k();
            int length = c0135gArr.length;
            int i3 = 0;
            while (true) {
                if (i3 >= length) {
                    Typeface typefaceL0 = l0(objNewInstance);
                    if (typefaceL0 != null) {
                        return Typeface.create(typefaceL0, i2);
                    }
                } else {
                    C0135g c0135g = c0135gArr[i3];
                    Uri uri = c0135g.f1153a;
                    ByteBuffer byteBufferH = (ByteBuffer) c0103k.getOrDefault(uri, null);
                    if (byteBufferH == null) {
                        byteBufferH = D.g.H(context, uri);
                        c0103k.put(uri, byteBufferH);
                    }
                    if (byteBufferH == null) {
                        break;
                    }
                    if (!k0(objNewInstance, byteBufferH, c0135g.b, c0135g.f1154c, c0135g.f1155d)) {
                        break;
                    }
                    i3++;
                }
            }
        }
        return null;
    }
}
