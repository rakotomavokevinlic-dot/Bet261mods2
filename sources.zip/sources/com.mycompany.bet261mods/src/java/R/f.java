package r;

import android.content.res.Resources;
import android.os.Build;
import android.util.Log;
import java.lang.reflect.Method;
import l.C0098f;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final D.g f1122a;
    public static final C0098f b;

    static {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 29) {
            f1122a = new k();
        } else if (i2 >= 28) {
            f1122a = new j();
        } else if (i2 >= 26) {
            f1122a = new i();
        } else {
            Method method = h.f1130q;
            if (method == null) {
                Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
            }
            if (method != null) {
                f1122a = new h();
            } else {
                f1122a = new g();
            }
        }
        b = new C0098f(16);
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x002d  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0030  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0042  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static android.graphics.Typeface a(android.content.Context r11, q.e r12, android.content.res.Resources r13, int r14, java.lang.String r15, int r16, int r17, i.U r18) {
        /*
            Method dump skipped, instruction units count: 415
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: r.f.a(android.content.Context, q.e, android.content.res.Resources, int, java.lang.String, int, int, i.U):android.graphics.Typeface");
    }

    public static String b(Resources resources, int i2, String str, int i3, int i4) {
        return resources.getResourcePackageName(i2) + '-' + str + '-' + i3 + '-' + i2 + '-' + i4;
    }
}
