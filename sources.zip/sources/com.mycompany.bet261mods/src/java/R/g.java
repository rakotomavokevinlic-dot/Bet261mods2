package r;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import v.C0135g;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public class g extends D.g {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static Class f1123o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static Constructor f1124p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static Method f1125q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static Method f1126r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static boolean f1127s;

    public static boolean k0(Object obj, String str, int i2, boolean z2) throws NoSuchMethodException {
        l0();
        try {
            return ((Boolean) f1125q.invoke(obj, str, Integer.valueOf(i2), Boolean.valueOf(z2))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e2) {
            throw new RuntimeException(e2);
        }
    }

    public static void l0() throws NoSuchMethodException {
        Method method;
        Class<?> cls;
        Method method2;
        if (f1127s) {
            return;
        }
        f1127s = true;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            method2 = cls.getMethod("addFontWeightStyle", String.class, Integer.TYPE, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi21Impl", e2.getClass().getName(), e2);
            method = null;
            cls = null;
            method2 = null;
        }
        f1124p = constructor;
        f1123o = cls;
        f1125q = method2;
        f1126r = method;
    }

    @Override // D.g
    public Typeface l(Context context, q.f fVar, Resources resources, int i2) throws NoSuchMethodException {
        l0();
        try {
            Object objNewInstance = f1124p.newInstance(null);
            for (q.g gVar : fVar.f1094a) {
                File fileB = D.g.B(context);
                if (fileB == null) {
                    return null;
                }
                try {
                    if (!D.g.i(fileB, resources, gVar.f)) {
                        return null;
                    }
                    if (!k0(objNewInstance, fileB.getPath(), gVar.b, gVar.f1096c)) {
                        return null;
                    }
                    fileB.delete();
                } catch (RuntimeException unused) {
                    return null;
                } finally {
                    fileB.delete();
                }
            }
            l0();
            try {
                Object objNewInstance2 = Array.newInstance((Class<?>) f1123o, 1);
                Array.set(objNewInstance2, 0, objNewInstance);
                return (Typeface) f1126r.invoke(null, objNewInstance2);
            } catch (IllegalAccessException | InvocationTargetException e2) {
                throw new RuntimeException(e2);
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e3) {
            throw new RuntimeException(e3);
        }
    }

    @Override // D.g
    public Typeface m(Context context, C0135g[] c0135gArr, int i2) {
        String str;
        if (c0135gArr.length >= 1) {
            try {
                ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(s(i2, c0135gArr).f1153a, "r", null);
                if (parcelFileDescriptorOpenFileDescriptor != null) {
                    try {
                        try {
                            str = Os.readlink("/proc/self/fd/" + parcelFileDescriptorOpenFileDescriptor.getFd());
                        } finally {
                        }
                    } catch (ErrnoException unused) {
                    }
                    File file = OsConstants.S_ISREG(Os.stat(str).st_mode) ? new File(str) : null;
                    if (file != null && file.canRead()) {
                        Typeface typefaceCreateFromFile = Typeface.createFromFile(file);
                        parcelFileDescriptorOpenFileDescriptor.close();
                        return typefaceCreateFromFile;
                    }
                    FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor());
                    try {
                        Typeface typefaceN = n(context, fileInputStream);
                        fileInputStream.close();
                        parcelFileDescriptorOpenFileDescriptor.close();
                        return typefaceN;
                    } finally {
                    }
                }
                if (parcelFileDescriptorOpenFileDescriptor != null) {
                    parcelFileDescriptorOpenFileDescriptor.close();
                    return null;
                }
            } catch (IOException unused2) {
            }
        }
        return null;
    }
}
