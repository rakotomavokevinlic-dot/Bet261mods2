package r;

import android.graphics.Paint;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class d {
    public static boolean a(Paint paint, String str) {
        return paint.hasGlyph(str);
    }
}
