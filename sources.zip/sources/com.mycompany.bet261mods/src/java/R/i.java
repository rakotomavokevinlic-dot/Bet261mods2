package r;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import v.C0135g;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public class i extends g {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final Class f1132t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Constructor f1133u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Method f1134v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final Method f1135w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final Method f1136x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final Method f1137y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final Method f1138z;

    public i() throws NoSuchMethodException {
        Method methodS0;
        Constructor<?> constructor;
        Method methodR0;
        Method method;
        Method method2;
        Method method3;
        Class<?> cls = null;
        try {
            Class<?> cls2 = Class.forName("android.graphics.FontFamily");
            constructor = cls2.getConstructor(null);
            methodR0 = r0(cls2);
            Class cls3 = Integer.TYPE;
            method = cls2.getMethod("addFontFromBuffer", ByteBuffer.class, cls3, FontVariationAxis[].class, cls3, cls3);
            method2 = cls2.getMethod("freeze", null);
            method3 = cls2.getMethod("abortCreation", null);
            methodS0 = s0(cls2);
            cls = cls2;
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class ".concat(e2.getClass().getName()), e2);
            methodS0 = null;
            constructor = null;
            methodR0 = null;
            method = null;
            method2 = null;
            method3 = null;
        }
        this.f1132t = cls;
        this.f1133u = constructor;
        this.f1134v = methodR0;
        this.f1135w = method;
        this.f1136x = method2;
        this.f1137y = method3;
        this.f1138z = methodS0;
    }

    public static Method r0(Class cls) {
        Class cls2 = Integer.TYPE;
        return cls.getMethod("addFontFromAssetManager", AssetManager.class, String.class, cls2, Boolean.TYPE, cls2, cls2, cls2, FontVariationAxis[].class);
    }

    @Override // r.g, D.g
    public final Typeface l(Context context, q.f fVar, Resources resources, int i2) {
        Method method = this.f1134v;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method == null) {
            return super.l(context, fVar, resources, i2);
        }
        Object objQ0 = q0();
        if (objQ0 != null) {
            q.g[] gVarArr = fVar.f1094a;
            int length = gVarArr.length;
            int i3 = 0;
            while (i3 < length) {
                q.g gVar = gVarArr[i3];
                String str = gVar.f1095a;
                FontVariationAxis[] fontVariationAxisArrFromFontVariationSettings = FontVariationAxis.fromFontVariationSettings(gVar.f1097d);
                Context context2 = context;
                if (!n0(context2, objQ0, str, gVar.f1098e, gVar.b, gVar.f1096c ? 1 : 0, fontVariationAxisArrFromFontVariationSettings)) {
                    m0(objQ0);
                    return null;
                }
                i3++;
                context = context2;
            }
            if (p0(objQ0)) {
                return o0(objQ0);
            }
        }
        return null;
    }

    @Override // r.g, D.g
    public final Typeface m(Context context, C0135g[] c0135gArr, int i2) {
        Typeface typefaceO0;
        boolean zBooleanValue;
        if (c0135gArr.length >= 1) {
            Method method = this.f1134v;
            if (method == null) {
                Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
            }
            if (method != null) {
                HashMap map = new HashMap();
                for (C0135g c0135g : c0135gArr) {
                    if (c0135g.f1156e == 0) {
                        Uri uri = c0135g.f1153a;
                        if (!map.containsKey(uri)) {
                            map.put(uri, D.g.H(context, uri));
                        }
                    }
                }
                Map mapUnmodifiableMap = Collections.unmodifiableMap(map);
                Object objQ0 = q0();
                if (objQ0 != null) {
                    int length = c0135gArr.length;
                    int i3 = 0;
                    boolean z2 = false;
                    while (i3 < length) {
                        C0135g c0135g2 = c0135gArr[i3];
                        ByteBuffer byteBuffer = (ByteBuffer) mapUnmodifiableMap.get(c0135g2.f1153a);
                        if (byteBuffer != null) {
                            try {
                                zBooleanValue = ((Boolean) this.f1135w.invoke(objQ0, byteBuffer, Integer.valueOf(c0135g2.b), null, Integer.valueOf(c0135g2.f1154c), Integer.valueOf(c0135g2.f1155d ? 1 : 0))).booleanValue();
                            } catch (IllegalAccessException | InvocationTargetException unused) {
                                zBooleanValue = false;
                            }
                            if (!zBooleanValue) {
                                m0(objQ0);
                                return null;
                            }
                            z2 = true;
                        }
                        i3++;
                        z2 = z2;
                    }
                    if (!z2) {
                        m0(objQ0);
                        return null;
                    }
                    if (p0(objQ0) && (typefaceO0 = o0(objQ0)) != null) {
                        return Typeface.create(typefaceO0, i2);
                    }
                }
            } else {
                C0135g c0135gS = s(i2, c0135gArr);
                try {
                    ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(c0135gS.f1153a, "r", null);
                    if (parcelFileDescriptorOpenFileDescriptor != null) {
                        try {
                            Typeface typefaceBuild = new Typeface.Builder(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor()).setWeight(c0135gS.f1154c).setItalic(c0135gS.f1155d).build();
                            parcelFileDescriptorOpenFileDescriptor.close();
                            return typefaceBuild;
                        } finally {
                        }
                    }
                    if (parcelFileDescriptorOpenFileDescriptor != null) {
                        parcelFileDescriptorOpenFileDescriptor.close();
                        return null;
                    }
                } catch (IOException unused2) {
                }
            }
        }
        return null;
    }

    public final void m0(Object obj) {
        try {
            this.f1137y.invoke(obj, null);
        } catch (IllegalAccessException | InvocationTargetException unused) {
        }
    }

    public final boolean n0(Context context, Object obj, String str, int i2, int i3, int i4, FontVariationAxis[] fontVariationAxisArr) {
        try {
            return ((Boolean) this.f1134v.invoke(obj, context.getAssets(), str, 0, Boolean.FALSE, Integer.valueOf(i2), Integer.valueOf(i3), Integer.valueOf(i4), fontVariationAxisArr)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    @Override // D.g
    public final Typeface o(Context context, Resources resources, int i2, String str, int i3) {
        Method method = this.f1134v;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method == null) {
            return super.o(context, resources, i2, str, i3);
        }
        Object objQ0 = q0();
        if (objQ0 != null) {
            if (!n0(context, objQ0, str, 0, -1, -1, null)) {
                m0(objQ0);
                return null;
            }
            if (p0(objQ0)) {
                return o0(objQ0);
            }
        }
        return null;
    }

    public Typeface o0(Object obj) {
        try {
            Object objNewInstance = Array.newInstance((Class<?>) this.f1132t, 1);
            Array.set(objNewInstance, 0, obj);
            return (Typeface) this.f1138z.invoke(null, objNewInstance, -1, -1);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    public final boolean p0(Object obj) {
        try {
            return ((Boolean) this.f1136x.invoke(obj, null)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public final Object q0() {
        try {
            return this.f1133u.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            return null;
        }
    }

    public Method s0(Class cls) throws NoSuchMethodException {
        Class<?> cls2 = Array.newInstance((Class<?>) cls, 1).getClass();
        Class cls3 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", cls2, cls3, cls3);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
}
