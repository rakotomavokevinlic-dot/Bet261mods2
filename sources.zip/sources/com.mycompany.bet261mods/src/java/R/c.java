package r;

import android.graphics.Insets;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class c {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final c f1117e = new c(0, 0, 0, 0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f1118a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1119c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1120d;

    public c(int i2, int i3, int i4, int i5) {
        this.f1118a = i2;
        this.b = i3;
        this.f1119c = i4;
        this.f1120d = i5;
    }

    public static c a(int i2, int i3, int i4, int i5) {
        return (i2 == 0 && i3 == 0 && i4 == 0 && i5 == 0) ? f1117e : new c(i2, i3, i4, i5);
    }

    public static c b(Insets insets) {
        return a(insets.left, insets.top, insets.right, insets.bottom);
    }

    public final Insets c() {
        return b.a(this.f1118a, this.b, this.f1119c, this.f1120d);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || c.class != obj.getClass()) {
            return false;
        }
        c cVar = (c) obj;
        return this.f1120d == cVar.f1120d && this.f1118a == cVar.f1118a && this.f1119c == cVar.f1119c && this.b == cVar.b;
    }

    public final int hashCode() {
        return (((((this.f1118a * 31) + this.b) * 31) + this.f1119c) * 31) + this.f1120d;
    }

    public final String toString() {
        return "Insets{left=" + this.f1118a + ", top=" + this.b + ", right=" + this.f1119c + ", bottom=" + this.f1120d + '}';
    }
}
