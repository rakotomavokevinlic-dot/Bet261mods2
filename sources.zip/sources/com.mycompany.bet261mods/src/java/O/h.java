package o;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import androidx.lifecycle.A;
import androidx.lifecycle.s;
import androidx.lifecycle.y;
import y.InterfaceC0159k;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class h extends Activity implements androidx.lifecycle.q, InterfaceC0159k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final s f1079a = new s(this);

    @Override // y.InterfaceC0159k
    public final boolean d(KeyEvent keyEvent) {
        e0.c.e(keyEvent, "event");
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        e0.c.e(keyEvent, "event");
        View decorView = getWindow().getDecorView();
        e0.c.d(decorView, "window.decorView");
        if (D.g.p(decorView, keyEvent)) {
            return true;
        }
        return D.g.q(this, decorView, this, keyEvent);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        e0.c.e(keyEvent, "event");
        View decorView = getWindow().getDecorView();
        e0.c.d(decorView, "window.decorView");
        if (D.g.p(decorView, keyEvent)) {
            return true;
        }
        return super.dispatchKeyShortcutEvent(keyEvent);
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i2 = A.b;
        y.b(this);
    }

    @Override // android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        e0.c.e(bundle, "outState");
        androidx.lifecycle.l lVar = androidx.lifecycle.l.c;
        s sVar = this.f1079a;
        sVar.c("setCurrentState");
        sVar.e(lVar);
        super.onSaveInstanceState(bundle);
    }
}
