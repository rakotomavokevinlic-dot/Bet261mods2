package o;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class c implements Application.ActivityLifecycleCallbacks {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f1069a;
    public Activity b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1070c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1071d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1072e = false;
    public boolean f = false;

    public c(Activity activity) {
        this.b = activity;
        this.f1070c = activity.hashCode();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityDestroyed(Activity activity) {
        if (this.b == activity) {
            this.b = null;
            this.f1072e = true;
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityPaused(Activity activity) {
        if (!this.f1072e || this.f || this.f1071d) {
            return;
        }
        Object obj = this.f1069a;
        try {
            Object obj2 = d.f1074c.get(activity);
            if (obj2 == obj && activity.hashCode() == this.f1070c) {
                d.f1077g.postAtFrontOfQueue(new T.c(d.b.get(activity), 3, obj2));
                this.f = true;
                this.f1069a = null;
            }
        } catch (Throwable th) {
            Log.e("ActivityRecreator", "Exception while fetching field values", th);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStarted(Activity activity) {
        if (this.b == activity) {
            this.f1071d = true;
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityResumed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityStopped(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivityCreated(Activity activity, Bundle bundle) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }
}
