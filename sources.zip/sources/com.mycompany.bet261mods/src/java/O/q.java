package o;

import android.app.NotificationManager;
import android.content.Context;
import java.util.HashSet;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final NotificationManager f1081a;

    static {
        new HashSet();
    }

    public q(Context context) {
        this.f1081a = (NotificationManager) context.getSystemService("notification");
    }
}
