package n;

import android.R;

/* JADX INFO: renamed from: n.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract class AbstractC0112a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f1067a = {R.attr.color, R.attr.alpha, R.attr.lStar, 2130903081, 2130903208};
    public static final int[] b = {2130903183, 2130903184, 2130903185, 2130903186, 2130903187, 2130903188, 2130903189};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int[] f1068c = {R.attr.font, R.attr.fontWeight, R.attr.fontStyle, R.attr.ttcIndex, R.attr.fontVariationSettings, 2130903181, 2130903190, 2130903191, 2130903192, 2130903329};
}
