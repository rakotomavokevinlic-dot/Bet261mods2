package W;

import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class f extends U.h {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ String f262p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ String f263q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ String f264r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(String str, F.d dVar, F.d dVar2, String str2, String str3, String str4) {
        super(1, str, dVar, dVar2);
        this.f262p = str2;
        this.f263q = str3;
        this.f264r = str4;
    }

    @Override // U.h
    public final Map e() {
        HashMap map = new HashMap();
        map.put("si", this.f262p);
        map.put("ri", this.f263q);
        map.put("ai", this.f264r);
        return map;
    }
}
