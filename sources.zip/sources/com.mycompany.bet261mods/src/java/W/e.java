package W;

import T.o;
import android.content.Context;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class e implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ g f261a;

    public /* synthetic */ e(g gVar) {
        this.f261a = gVar;
    }

    public void a() {
        this.f261a.b.finish();
    }

    @Override // T.o
    public void u(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            boolean zHas = jSONObject.has("ad_display_running");
            g gVar = this.f261a;
            if (zHas && !jSONObject.isNull("ad_display_running")) {
                gVar.f271i = jSONObject.getString("ad_display_running");
            }
            if (jSONObject.has("ad_display_exit") && !jSONObject.isNull("ad_display_exit")) {
                gVar.f272j = jSONObject.getString("ad_display_exit");
            }
            if (jSONObject.has("session_id") && !jSONObject.isNull("session_id")) {
                gVar.f278p = jSONObject.getString("session_id");
            }
            if (jSONObject.has("app_mode") && !jSONObject.isNull("app_mode")) {
                gVar.f279q = jSONObject.getString("app_mode");
            }
            String str2 = gVar.f279q;
            androidx.activity.l lVar = gVar.b;
            if (str2.equals("finish")) {
                Toast.makeText((Context) lVar, (CharSequence) "The current version of this App is not available anymore. Please update to the new version or contact the administrator.", 1).show();
                lVar.finish();
            }
            if (jSONObject.has("next_call") && !jSONObject.isNull("next_call")) {
                gVar.f269g = Integer.parseInt(jSONObject.getString("next_call")) * 1000;
            }
            T.h hVar = new T.h(gVar, (gVar.f270h + "ads-running.json") + "?ai=" + gVar.f276n + "&ik=" + gVar.f277o + "&si=" + gVar.f278p);
            gVar.f265a = hVar;
            gVar.f267d.post(hVar);
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }
}
