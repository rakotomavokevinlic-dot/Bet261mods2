package W;

import android.app.Dialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import com.mycompany.bet261mods.MainActivity;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class h implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f282a = 0;
    public final String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f283c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f284d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f285e;

    public h(G.a aVar, String str, String str2, Dialog dialog) {
        this.f285e = aVar;
        this.b = str;
        this.f283c = str2;
        this.f284d = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        Method method;
        switch (this.f282a) {
            case 0:
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(this.b));
                G.a aVar = (G.a) this.f285e;
                ((MainActivity) aVar.f57a).startActivity(intent);
                e eVar = (e) ((C.j) aVar.b).b;
                if (eVar != null) {
                    String str = (String) this.f283c;
                    g gVar = eVar.f261a;
                    String str2 = gVar.f278p;
                    gVar.getClass();
                    gVar.a(gVar.f278p, str, gVar.f276n);
                }
                ((Dialog) this.f284d).dismiss();
                return;
            default:
                if (((Method) this.f284d) == null) {
                    View view2 = (View) this.f283c;
                    Context context = view2.getContext();
                    while (true) {
                        String str3 = this.b;
                        if (context == null) {
                            int id = view2.getId();
                            throw new IllegalStateException("Could not find method " + str3 + "(View) in a parent or ancestor Context for android:onClick attribute defined on view " + view2.getClass() + (id == -1 ? "" : " with id '" + view2.getContext().getResources().getResourceEntryName(id) + "'"));
                        }
                        try {
                            if (!context.isRestricted() && (method = context.getClass().getMethod(str3, View.class)) != null) {
                                this.f284d = method;
                                this.f285e = context;
                            }
                            break;
                        } catch (NoSuchMethodException unused) {
                        }
                        context = context instanceof ContextWrapper ? ((ContextWrapper) context).getBaseContext() : null;
                    }
                }
                try {
                    ((Method) this.f284d).invoke((Context) this.f285e, view);
                    return;
                } catch (IllegalAccessException e2) {
                    throw new IllegalStateException("Could not execute non-public method for android:onClick", e2);
                } catch (InvocationTargetException e3) {
                    throw new IllegalStateException("Could not execute method for android:onClick", e3);
                }
        }
    }

    public h(View view, String str) {
        this.f283c = view;
        this.b = str;
    }
}
