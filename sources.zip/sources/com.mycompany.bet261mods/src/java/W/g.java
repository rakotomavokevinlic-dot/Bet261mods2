package W;

import android.os.Handler;
import com.mycompany.bet261mods.MainActivity;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public T.h f265a;
    public MainActivity b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f266c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Handler f267d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f268e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f269g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f270h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public String f271i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f272j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public String f273k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public String f274l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public String f275m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public String f276n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public String f277o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public String f278p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public String f279q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public String f280r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Boolean f281s;

    public final void a(String str, String str2, String str3) {
        if (this.f281s.booleanValue()) {
            return;
        }
        D.g.I(this.b).a(new f(this.f270h + "ads-click.json", new F.d(10), new F.d(11), str, str2, str3));
        this.f281s = Boolean.TRUE;
    }
}
