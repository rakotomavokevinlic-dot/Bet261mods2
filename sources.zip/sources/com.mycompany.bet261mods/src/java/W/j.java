package W;

import android.content.DialogInterface;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class j implements DialogInterface.OnDismissListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ G.a f287a;

    public j(G.a aVar) {
        this.f287a = aVar;
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        e eVar = (e) ((C.j) this.f287a.b).b;
        if (eVar != null) {
            eVar.a();
        }
    }
}
