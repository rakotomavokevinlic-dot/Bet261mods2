package W;

import android.R;
import android.graphics.Point;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ImageButton;
import com.mycompany.bet261mods.MainActivity;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f257a = 0;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f258c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f259d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f260e;
    public Object f;

    public d(MainActivity mainActivity) {
        this.b = mainActivity;
    }

    public void a(String str, String str2) {
        androidx.activity.l lVar = (MainActivity) this.b;
        ((WindowManager) lVar.getSystemService("window")).getDefaultDisplay().getSize(new Point());
        this.f260e = (ViewGroup) lVar.findViewById(R.id.content);
        View viewInflate = View.inflate(lVar, 2131427357, null);
        this.f = viewInflate;
        ((ViewGroup) this.f260e).addView(viewInflate);
        WebView webView = (WebView) ((ViewGroup) this.f260e).findViewById(2131230778);
        this.f259d = webView;
        webView.setWebChromeClient(new WebChromeClient());
        ((WebView) this.f259d).getSettings().setJavaScriptEnabled(true);
        ((WebView) this.f259d).setOnTouchListener(new a(this, str2));
        ((WebView) this.f259d).loadUrl(str);
        ((WebView) this.f259d).setWebViewClient(new b());
        ImageButton imageButton = (ImageButton) ((ViewGroup) this.f260e).findViewById(2131230798);
        imageButton.setOnClickListener(new c(0, this));
        imageButton.getBackground().setAlpha(64);
    }

    public String toString() {
        switch (this.f257a) {
            case 1:
                StringBuilder sb = new StringBuilder();
                sb.append("FontRequest {mProviderAuthority: " + ((String) this.b) + ", mProviderPackage: " + ((String) this.f258c) + ", mQuery: " + ((String) this.f259d) + ", mCertificates:");
                int i2 = 0;
                while (true) {
                    List list = (List) this.f260e;
                    if (i2 >= list.size()) {
                        sb.append("}mCertificatesArray: 0");
                        return sb.toString();
                    }
                    sb.append(" [");
                    List list2 = (List) list.get(i2);
                    for (int i3 = 0; i3 < list2.size(); i3++) {
                        sb.append(" \"");
                        sb.append(Base64.encodeToString((byte[]) list2.get(i3), 0));
                        sb.append("\"");
                    }
                    sb.append(" ]");
                    i2++;
                }
                break;
            default:
                return super.toString();
        }
    }

    public d(String str, String str2, String str3, List list) {
        str.getClass();
        this.b = str;
        str2.getClass();
        this.f258c = str2;
        this.f259d = str3;
        list.getClass();
        this.f260e = list;
        this.f = str + "-" + str2 + "-" + str3;
    }
}
