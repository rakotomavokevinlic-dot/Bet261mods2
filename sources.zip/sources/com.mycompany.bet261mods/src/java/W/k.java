package W;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class k implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Dialog f288a;
    public final /* synthetic */ G.a b;

    public k(G.a aVar, Dialog dialog) {
        this.b = aVar;
        this.f288a = dialog;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        e eVar = (e) ((C.j) this.b.b).b;
        if (eVar != null) {
            eVar.a();
        }
        this.f288a.dismiss();
    }
}
