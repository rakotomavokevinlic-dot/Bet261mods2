package W;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;
import java.net.URL;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class l extends AsyncTask {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ImageView f289a;

    @Override // android.os.AsyncTask
    public final Object doInBackground(Object[] objArr) {
        try {
            return BitmapFactory.decodeStream(new URL(((String[]) objArr)[0]).openStream());
        } catch (Exception e2) {
            Log.e("Error", e2.getMessage());
            e2.printStackTrace();
            return null;
        }
    }

    @Override // android.os.AsyncTask
    public final void onPostExecute(Object obj) {
        this.f289a.setImageBitmap((Bitmap) obj);
    }
}
