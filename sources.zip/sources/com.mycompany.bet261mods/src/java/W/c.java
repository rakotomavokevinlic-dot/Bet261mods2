package W;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.appcompat.widget.Toolbar;
import e.C0010e;
import g.AbstractC0020a;
import h.p;
import i.Z0;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class c implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f256a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c(int i2, Object obj) {
        this.f256a = i2;
        this.b = obj;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        switch (this.f256a) {
            case 0:
                d dVar = (d) this.b;
                ((ViewGroup) dVar.f260e).removeView((View) dVar.f);
                break;
            case 1:
                C0010e c0010e = (C0010e) this.b;
                Button button = c0010e.f;
                c0010e.f489v.obtainMessage(1, c0010e.b).sendToTarget();
                break;
            case 2:
                ((AbstractC0020a) this.b).a();
                break;
            default:
                Z0 z0 = ((Toolbar) this.b).M;
                p pVar = z0 == null ? null : z0.b;
                if (pVar != null) {
                    pVar.collapseActionView();
                }
                break;
        }
    }
}
