package W;

import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class a implements View.OnTouchListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f255a;
    public final /* synthetic */ d b;

    public a(d dVar, String str) {
        this.b = dVar;
        this.f255a = str;
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        ((WebView) view).getHitTestResult();
        C.j jVar = (C.j) this.b.f258c;
        if (jVar == null) {
            return false;
        }
        String str = this.f255a;
        C.j jVar2 = (C.j) jVar.b;
        g gVar = (g) ((T.h) jVar2.b).f186d;
        String str2 = gVar.f278p;
        gVar.getClass();
        g gVar2 = (g) ((T.h) jVar2.b).f186d;
        gVar2.a(gVar2.f278p, str, gVar2.f276n);
        return false;
    }
}
