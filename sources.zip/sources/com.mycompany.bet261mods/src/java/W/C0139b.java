package w;

import android.os.Build;
import android.text.PrecomputedText;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils;
import java.util.Objects;

/* JADX INFO: renamed from: w.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0139b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextPaint f1158a;
    public final TextDirectionHeuristic b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1159c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1160d;

    public C0139b(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i2, int i3) {
        if (Build.VERSION.SDK_INT >= 29) {
            androidx.emoji2.text.b.m(androidx.emoji2.text.b.e(androidx.emoji2.text.b.r(androidx.emoji2.text.b.d(androidx.emoji2.text.b.f(textPaint), i2), i3), textDirectionHeuristic));
        }
        this.f1158a = textPaint;
        this.b = textDirectionHeuristic;
        this.f1159c = i2;
        this.f1160d = i3;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0139b)) {
            return false;
        }
        C0139b c0139b = (C0139b) obj;
        if (this.f1159c != c0139b.f1159c || this.f1160d != c0139b.f1160d) {
            return false;
        }
        TextPaint textPaint = this.f1158a;
        float textSize = textPaint.getTextSize();
        TextPaint textPaint2 = c0139b.f1158a;
        if (textSize != textPaint2.getTextSize() || textPaint.getTextScaleX() != textPaint2.getTextScaleX() || textPaint.getTextSkewX() != textPaint2.getTextSkewX() || textPaint.getLetterSpacing() != textPaint2.getLetterSpacing() || !TextUtils.equals(textPaint.getFontFeatureSettings(), textPaint2.getFontFeatureSettings()) || textPaint.getFlags() != textPaint2.getFlags() || !textPaint.getTextLocales().equals(textPaint2.getTextLocales())) {
            return false;
        }
        if (textPaint.getTypeface() == null) {
            if (textPaint2.getTypeface() != null) {
                return false;
            }
        } else if (!textPaint.getTypeface().equals(textPaint2.getTypeface())) {
            return false;
        }
        return this.b == c0139b.b;
    }

    public final int hashCode() {
        TextPaint textPaint = this.f1158a;
        return Objects.hash(Float.valueOf(textPaint.getTextSize()), Float.valueOf(textPaint.getTextScaleX()), Float.valueOf(textPaint.getTextSkewX()), Float.valueOf(textPaint.getLetterSpacing()), Integer.valueOf(textPaint.getFlags()), textPaint.getTextLocales(), textPaint.getTypeface(), Boolean.valueOf(textPaint.isElegantTextHeight()), this.b, Integer.valueOf(this.f1159c), Integer.valueOf(this.f1160d));
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("{");
        StringBuilder sb2 = new StringBuilder("textSize=");
        TextPaint textPaint = this.f1158a;
        sb2.append(textPaint.getTextSize());
        sb.append(sb2.toString());
        sb.append(", textScaleX=" + textPaint.getTextScaleX());
        sb.append(", textSkewX=" + textPaint.getTextSkewX());
        int i2 = Build.VERSION.SDK_INT;
        sb.append(", letterSpacing=" + textPaint.getLetterSpacing());
        sb.append(", elegantTextHeight=" + textPaint.isElegantTextHeight());
        sb.append(", textLocale=" + textPaint.getTextLocales());
        sb.append(", typeface=" + textPaint.getTypeface());
        if (i2 >= 26) {
            sb.append(", variationSettings=" + textPaint.getFontVariationSettings());
        }
        sb.append(", textDir=" + this.b);
        sb.append(", breakStrategy=" + this.f1159c);
        sb.append(", hyphenationFrequency=" + this.f1160d);
        sb.append("}");
        return sb.toString();
    }

    public C0139b(PrecomputedText.Params params) {
        this.f1158a = androidx.emoji2.text.b.h(params);
        this.b = androidx.emoji2.text.b.g(params);
        this.f1159c = androidx.emoji2.text.b.a(params);
        this.f1160d = androidx.emoji2.text.b.q(params);
    }
}
