package j;

import D.g;
import java.util.concurrent.Executors;

/* JADX INFO: renamed from: j.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class C0090a extends g {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static volatile C0090a f999p;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Object f1000o;

    public C0090a(int i2) {
        switch (i2) {
            case 1:
                this.f1000o = new Object();
                Executors.newFixedThreadPool(4, new ThreadFactoryC0091b());
                break;
            default:
                this.f1000o = new C0090a(1);
                break;
        }
    }
}
