package b0;

import f0.c;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public class b extends a0.a {
    @Override // Z.a
    public final f0.a a() {
        Integer num = a.f304a;
        return (num == null || num.intValue() >= 34) ? new g0.a() : new c();
    }
}
