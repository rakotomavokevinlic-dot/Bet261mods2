package v;

import java.util.ArrayList;
import l.C0103k;
import x.InterfaceC0141a;

/* JADX INFO: renamed from: v.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0132d implements InterfaceC0141a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1148a;
    public final /* synthetic */ Object b;

    public /* synthetic */ C0132d(int i2, Object obj) {
        this.f1148a = i2;
        this.b = obj;
    }

    @Override // x.InterfaceC0141a
    public final void a(Object obj) {
        switch (this.f1148a) {
            case 0:
                C0133e c0133e = (C0133e) obj;
                if (c0133e == null) {
                    c0133e = new C0133e(-3);
                }
                ((G.a) this.b).e(c0133e);
                return;
            default:
                C0133e c0133e2 = (C0133e) obj;
                synchronized (AbstractC0134f.f1151c) {
                    try {
                        C0103k c0103k = AbstractC0134f.f1152d;
                        ArrayList arrayList = (ArrayList) c0103k.getOrDefault((String) this.b, null);
                        if (arrayList == null) {
                            return;
                        }
                        c0103k.remove((String) this.b);
                        for (int i2 = 0; i2 < arrayList.size(); i2++) {
                            ((InterfaceC0141a) arrayList.get(i2)).a(c0133e2);
                        }
                        return;
                    } finally {
                    }
                }
        }
    }
}
