package v;

import java.util.concurrent.ThreadFactory;

/* JADX INFO: renamed from: v.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class ThreadFactoryC0137i implements ThreadFactory {
    @Override // java.util.concurrent.ThreadFactory
    public final Thread newThread(Runnable runnable) {
        return new C0136h(runnable);
    }
}
