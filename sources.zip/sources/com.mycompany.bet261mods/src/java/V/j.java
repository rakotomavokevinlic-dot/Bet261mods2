package V;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.l;
import com.mycompany.bet261mods.MainActivity;
import java.net.URISyntaxException;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class j extends WebViewClient {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ MainActivity f254a;

    public j(MainActivity mainActivity) {
        this.f254a = mainActivity;
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.mycompany.bet261mods.MainActivity] */
    @Override // android.webkit.WebViewClient
    public final void onLoadResource(WebView webView, String str) {
        ?? r1 = this.f254a;
        if (MainActivity.q(r1)) {
            return;
        }
        r1.f308C = true;
    }

    @Override // android.webkit.WebViewClient
    public final void onPageFinished(WebView webView, String str) {
        MainActivity mainActivity = this.f254a;
        super.onPageFinished(mainActivity.f315x, str);
        mainActivity.f310E.setRefreshing(false);
        mainActivity.f309D.setRefreshing(false);
        mainActivity.findViewById(2131230781).setVisibility(8);
        mainActivity.findViewById(2131230780).setVisibility(0);
        mainActivity.f307B = true;
        if (MainActivity.f305J) {
            return;
        }
        MainActivity.f305J = true;
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [android.content.Context, com.mycompany.bet261mods.MainActivity] */
    @Override // android.webkit.WebViewClient
    public final void onPageStarted(WebView webView, String str, Bitmap bitmap) {
        super.onPageStarted(webView, str, bitmap);
        boolean z2 = MainActivity.f305J;
        ?? r2 = this.f254a;
        if (z2) {
            r2.f310E.setRefreshing(true);
        }
        if (MainActivity.q(r2)) {
            return;
        }
        r2.f310E.setRefreshing(false);
    }

    @Override // android.webkit.WebViewClient
    public final void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
        MainActivity mainActivity = this.f254a;
        if (!mainActivity.f307B) {
            mainActivity.f315x.loadUrl("file:///android_asset/htmlapp/helpers/error.html");
            mainActivity.f307B = true;
        }
        int errorCode = webResourceError.getErrorCode();
        if (errorCode == -8) {
            webView.loadUrl("https://www.webintoapp.com/landing/ERROR_TIMEOUT");
        } else if (errorCode == -6) {
            webView.loadUrl("https://www.webintoapp.com/landing/ERROR_CONNECT");
        } else {
            if (errorCode != -2) {
                return;
            }
            webView.loadUrl("https://www.webintoapp.com/landing/ERROR_HOST_LOOKUP");
        }
    }

    @Override // android.webkit.WebViewClient
    public final boolean shouldOverrideUrlLoading(WebView webView, String str) {
        if (str.startsWith("https") || str.startsWith("http")) {
            return false;
        }
        boolean zStartsWith = str.startsWith("mailto:");
        l lVar = this.f254a;
        if (zStartsWith) {
            try {
                lVar.startActivity(new Intent("android.intent.action.SENDTO", Uri.parse(str)));
            } catch (ActivityNotFoundException unused) {
                Toast.makeText((Context) lVar, (CharSequence) "No email app found", 0).show();
            }
            return true;
        }
        if (str.startsWith("tel:")) {
            try {
                lVar.startActivity(new Intent("android.intent.action.DIAL", Uri.parse(str)));
            } catch (ActivityNotFoundException unused2) {
                Toast.makeText((Context) lVar, (CharSequence) "No phone app found", 0).show();
            }
            return true;
        }
        if (str.startsWith("sms:") || str.startsWith("smsto:")) {
            Intent intent = new Intent("android.intent.action.SENDTO");
            intent.setData(Uri.parse(str));
            try {
                lVar.startActivity(intent);
            } catch (ActivityNotFoundException unused3) {
                Toast.makeText((Context) lVar, (CharSequence) "No SMS app found", 0).show();
            }
            return true;
        }
        if (str.startsWith("geo:") || str.startsWith("maps:")) {
            try {
                lVar.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
            } catch (ActivityNotFoundException unused4) {
                Toast.makeText((Context) lVar, (CharSequence) "No Maps app found", 0).show();
            }
            return true;
        }
        if (str.startsWith("market:")) {
            try {
                lVar.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
            } catch (ActivityNotFoundException unused5) {
                Toast.makeText((Context) lVar, (CharSequence) "No Play Store app found", 0).show();
            }
            return true;
        }
        if (str.startsWith("whatsapp:") || str.startsWith("tg:") || str.startsWith("fb:") || str.startsWith("twitter:") || str.startsWith("skype:") || str.startsWith("zoomus:")) {
            try {
                lVar.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
            } catch (ActivityNotFoundException unused6) {
                Toast.makeText((Context) lVar, (CharSequence) "App not installed", 0).show();
            }
            return true;
        }
        if (str.startsWith("intent:")) {
            Uri uri = Uri.parse(str);
            PackageManager packageManager = lVar.getPackageManager();
            Intent data = new Intent("android.intent.action.VIEW").setData(uri);
            if (data.resolveActivity(packageManager) != null) {
                lVar.startActivity(data);
                return true;
            }
            try {
                Intent uri2 = Intent.parseUri(str, 1);
                if (uri2.resolveActivity(lVar.getPackageManager()) != null) {
                    lVar.startActivity(uri2);
                    return true;
                }
                Intent data2 = new Intent("android.intent.action.VIEW").setData(Uri.parse("market://details?id=" + uri2.getPackage()));
                if (data2.resolveActivity(packageManager) != null) {
                    lVar.startActivity(data2);
                    return true;
                }
                String stringExtra = uri2.getStringExtra("browser_fallback_url");
                if (stringExtra != null) {
                    webView.loadUrl(stringExtra);
                }
            } catch (URISyntaxException unused7) {
            }
        }
        return true;
    }
}
