package v;

import android.content.Context;
import java.util.concurrent.Callable;

/* JADX INFO: renamed from: v.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class CallableC0131c implements Callable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1144a;
    public final /* synthetic */ String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Context f1145c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ W.d f1146d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f1147e;

    public /* synthetic */ CallableC0131c(String str, Context context, W.d dVar, int i2, int i3) {
        this.f1144a = i3;
        this.b = str;
        this.f1145c = context;
        this.f1146d = dVar;
        this.f1147e = i2;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        switch (this.f1144a) {
            case 0:
                return AbstractC0134f.a(this.b, this.f1145c, this.f1146d, this.f1147e);
            default:
                try {
                    return AbstractC0134f.a(this.b, this.f1145c, this.f1146d, this.f1147e);
                } catch (Throwable unused) {
                    return new C0133e(-3);
                }
        }
    }
}
