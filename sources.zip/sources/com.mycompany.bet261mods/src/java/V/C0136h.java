package v;

import android.os.Process;

/* JADX INFO: renamed from: v.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0136h extends Thread {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f1157a;

    public C0136h(Runnable runnable) {
        super(runnable, "fonts-androidx");
        this.f1157a = 10;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        Process.setThreadPriority(this.f1157a);
        super.run();
    }
}
