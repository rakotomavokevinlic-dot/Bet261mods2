package V;

import android.R;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import com.mycompany.bet261mods.MainActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import l.C0095c;
import o.k;
import o.l;
import o.m;
import o.n;
import o.o;
import p.C0117d;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public MainActivity f248a;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r13v11 */
    /* JADX WARN: Type inference failed for: r13v12 */
    /* JADX WARN: Type inference failed for: r13v5, types: [android.app.Notification$Builder] */
    /* JADX WARN: Type inference failed for: r1v0, types: [java.lang.CharSequence, java.lang.String] */
    /* JADX WARN: Type inference failed for: r1v28, types: [android.app.Notification$Builder] */
    /* JADX WARN: Type inference failed for: r1v32, types: [java.lang.CharSequence] */
    /* JADX WARN: Type inference failed for: r1v5, types: [java.lang.CharSequence] */
    /* JADX WARN: Type inference failed for: r4v12, types: [android.app.Notification$Builder] */
    /* JADX WARN: Type inference failed for: r6v15, types: [android.app.Notification$Builder] */
    /* JADX WARN: Type inference failed for: r7v0, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r7v5, types: [android.content.Context, com.mycompany.bet261mods.MainActivity] */
    /* JADX WARN: Type inference failed for: r9v18 */
    /* JADX WARN: Type inference failed for: r9v19, types: [android.net.Uri, java.lang.CharSequence, java.lang.CharSequence[], java.lang.String, long[]] */
    /* JADX WARN: Type inference failed for: r9v22 */
    public static void a(d dVar, String str, String str2, String str3) {
        ?? r9;
        Bundle bundle;
        ?? SubSequence = str3;
        String str4 = str2.split("/")[1];
        byte[] bArrDecode = Base64.decode(str.replaceFirst("^data:" + str2 + ";base64,", ""), 0);
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/" + SubSequence);
        byte[] bytes = new String(bArrDecode, "UTF-8").getBytes(Charset.forName("UTF-8"));
        FileOutputStream fileOutputStream = new FileOutputStream(file, false);
        fileOutputStream.write(bytes);
        fileOutputStream.flush();
        boolean zExists = file.exists();
        ?? r7 = dVar.f248a;
        if (zExists) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            C0117d c0117dC = FileProvider.c((Context) r7, r7.getApplicationContext().getPackageName() + ".provider");
            try {
                String canonicalPath = file.getCanonicalPath();
                Map.Entry entry = null;
                for (Map.Entry entry2 : c0117dC.b.entrySet()) {
                    String path = ((File) entry2.getValue()).getPath();
                    if (C0117d.a(canonicalPath, path) && (entry == null || path.length() > ((File) entry.getValue()).getPath().length())) {
                        entry = entry2;
                    }
                }
                if (entry == null) {
                    throw new IllegalArgumentException("Failed to find configured root that contains " + canonicalPath);
                }
                String path2 = ((File) entry.getValue()).getPath();
                intent.setDataAndType(new Uri.Builder().scheme("content").authority(c0117dC.f1083a).encodedPath(Uri.encode((String) entry.getKey()) + '/' + Uri.encode(path2.endsWith("/") ? canonicalPath.substring(path2.length()) : canonicalPath.substring(path2.length() + 1), "/")).build(), MimeTypeMap.getSingleton().getMimeTypeFromExtension(str4));
                intent.addFlags(1);
                PendingIntent activity = PendingIntent.getActivity(r7, 1, intent, 335544320);
                NotificationManager notificationManager = (NotificationManager) r7.getSystemService("notification");
                int i2 = Build.VERSION.SDK_INT;
                if (i2 >= 26) {
                    NotificationChannel notificationChannelD = a.d();
                    Notification notificationBuild = a.c(r7).setContentTitle("Download Complete").setContentText(SubSequence).setContentIntent(activity).setChannelId("MYCHANNEL").setSmallIcon(R.drawable.stat_sys_download_done).build();
                    if (notificationManager != null) {
                        notificationManager.createNotificationChannel(notificationChannelD);
                        notificationManager.notify(1, notificationBuild);
                    }
                } else {
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    ArrayList arrayList3 = new ArrayList();
                    Notification notification = new Notification();
                    notification.when = System.currentTimeMillis();
                    notification.audioStreamType = -1;
                    ArrayList arrayList4 = new ArrayList();
                    notification.defaults = -1;
                    notification.flags |= 1;
                    notification.when = System.currentTimeMillis();
                    notification.icon = R.drawable.sym_action_chat;
                    CharSequence charSequenceSubSequence = "Download Complete".length() > 5120 ? "Download Complete".subSequence(0, 5120) : "Download Complete";
                    if (SubSequence != 0 && SubSequence.length() > 5120) {
                        SubSequence = SubSequence.subSequence(0, 5120);
                    }
                    if (notificationManager != null) {
                        new ArrayList();
                        Bundle bundle2 = new Bundle();
                        ?? A2 = i2 >= 26 ? n.a(r7, "MYCHANNEL") : new Notification.Builder(r7);
                        A2.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, null).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(charSequenceSubSequence).setContentText(SubSequence).setContentInfo(null).setContentIntent(null).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(null, (notification.flags & 128) != 0).setNumber(0).setProgress(0, 0, false);
                        l.b(A2, null);
                        A2.setSubText(null).setUsesChronometer(false).setPriority(0);
                        Iterator it = arrayList.iterator();
                        if (it.hasNext()) {
                            it.next().getClass();
                            throw new ClassCastException();
                        }
                        A2.setShowWhen(true);
                        o.j.i(A2, false);
                        o.j.g(A2, null);
                        o.j.j(A2, null);
                        o.j.h(A2, false);
                        k.b(A2, null);
                        k.c(A2, 0);
                        k.f(A2, 0);
                        k.d(A2, null);
                        k.e(A2, notification.sound, notification.audioAttributes);
                        if (i2 < 28) {
                            ArrayList arrayList5 = new ArrayList(arrayList2.size());
                            Iterator it2 = arrayList2.iterator();
                            if (it2.hasNext()) {
                                it2.next().getClass();
                                throw new ClassCastException();
                            }
                            C0095c c0095c = new C0095c(arrayList4.size() + arrayList5.size());
                            c0095c.addAll(arrayList5);
                            c0095c.addAll(arrayList4);
                            arrayList4 = new ArrayList(c0095c);
                        }
                        if (!arrayList4.isEmpty()) {
                            int size = arrayList4.size();
                            int i3 = 0;
                            while (i3 < size) {
                                Object obj = arrayList4.get(i3);
                                i3++;
                                k.a(A2, (String) obj);
                            }
                        }
                        if (arrayList3.size() > 0) {
                            bundle = new Bundle();
                            Bundle bundle3 = bundle.getBundle("android.car.EXTENSIONS");
                            if (bundle3 == null) {
                                bundle3 = new Bundle();
                            }
                            Bundle bundle4 = new Bundle(bundle3);
                            Bundle bundle5 = new Bundle();
                            if (arrayList3.size() > 0) {
                                Integer.toString(0);
                                if (arrayList3.get(0) != null) {
                                    throw new ClassCastException();
                                }
                                new Bundle();
                                throw null;
                            }
                            bundle3.putBundle("invisible_actions", bundle5);
                            bundle4.putBundle("invisible_actions", bundle5);
                            bundle.putBundle("android.car.EXTENSIONS", bundle3);
                            bundle2.putBundle("android.car.EXTENSIONS", bundle4);
                            r9 = 0;
                        } else {
                            r9 = 0;
                            bundle = null;
                        }
                        int i4 = Build.VERSION.SDK_INT;
                        A2.setExtras(bundle);
                        m.e(A2, r9);
                        if (i4 >= 26) {
                            n.b(A2, 0);
                            n.e(A2, r9);
                            n.f(A2, r9);
                            n.g(A2, 0L);
                            n.d(A2, 0);
                            if (!TextUtils.isEmpty("MYCHANNEL")) {
                                A2.setSound(r9).setDefaults(0).setLights(0, 0, 0).setVibrate(r9);
                            }
                        }
                        if (i4 >= 28) {
                            Iterator it3 = arrayList2.iterator();
                            if (it3.hasNext()) {
                                it3.next().getClass();
                                throw new ClassCastException();
                            }
                        }
                        if (i4 >= 29) {
                            o.a(A2, true);
                            o.b(A2, null);
                        }
                        notificationManager.notify(1, i4 >= 26 ? A2.build() : A2.build());
                        new Handler().postDelayed(new D.b(1, notificationManager), 1000L);
                    }
                }
            } catch (IOException unused) {
                throw new IllegalArgumentException("Failed to resolve canonical path for " + file);
            }
        }
        Toast.makeText((Context) r7, "Download Completed.", 0).show();
    }

    @JavascriptInterface
    public void getBase64FromBlobData(String str, String str2) {
        androidx.activity.l lVar = this.f248a;
        AlertDialog.Builder builder = new AlertDialog.Builder(lVar);
        builder.setTitle("Save As");
        EditText editText = new EditText(lVar);
        editText.setInputType(1);
        builder.setView(editText);
        builder.setPositiveButton("OK", new b(this, str, str2, editText, 0));
        builder.setNegativeButton("Cancel", new c(0));
        builder.show();
    }
}
