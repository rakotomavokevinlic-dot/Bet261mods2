package V;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import androidx.activity.l;
import com.mycompany.bet261mods.MainActivity;
import java.io.File;
import java.io.IOException;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class h extends WebChromeClient {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public View f249a;
    public WebChromeClient.CustomViewCallback b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f250c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f251d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ MainActivity f252e;

    public h(MainActivity mainActivity) {
        this.f252e = mainActivity;
    }

    @Override // android.webkit.WebChromeClient
    public final Bitmap getDefaultVideoPoster() {
        l lVar = this.f252e;
        if (lVar == null) {
            return null;
        }
        return BitmapFactory.decodeResource(lVar.getApplicationContext().getResources(), 2130837573);
    }

    @Override // android.webkit.WebChromeClient
    public final boolean onCreateWindow(WebView webView, boolean z2, boolean z3, Message message) {
        return true;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [android.app.Activity, android.content.Context, com.mycompany.bet261mods.MainActivity] */
    @Override // android.webkit.WebChromeClient
    public final void onGeolocationPermissionsShowPrompt(String str, GeolocationPermissions.Callback callback) {
        ?? r0 = this.f252e;
        if (o.e.a(r0, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            callback.invoke(str, true, true);
            return;
        }
        o.e.g(r0, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 100);
        r0.f313H = str;
        r0.f312G = callback;
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class g9.g
    	at g9.j.l(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:17)
    	at k4.a.y(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:78)
    	at ga.d.o(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:186)
    	at ga.c.apply(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1776)
    	at ga.d.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:30)
     */
    @Override // android.webkit.WebChromeClient
    public final void onHideCustomView() {
        l lVar = this.f252e;
        ((FrameLayout) lVar.getWindow().getDecorView()).removeView(this.f249a);
        this.f249a = null;
        lVar.getWindow().getDecorView().setSystemUiVisibility(this.f251d);
        lVar.setRequestedOrientation(this.f250c);
        this.b.onCustomViewHidden();
        this.b = null;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [android.app.Activity, android.content.Context, com.mycompany.bet261mods.MainActivity] */
    @Override // android.webkit.WebChromeClient
    public final void onPermissionRequest(PermissionRequest permissionRequest) {
        ?? r0 = this.f252e;
        r0.f314I = permissionRequest;
        for (String str : permissionRequest.getResources()) {
            if (str.equals("android.webkit.resource.VIDEO_CAPTURE")) {
                if (o.e.a(r0, "android.permission.RECORD_AUDIO") != 0) {
                    o.e.g(r0, new String[]{"android.permission.RECORD_AUDIO"}, 1002);
                    return;
                } else {
                    PermissionRequest permissionRequest2 = r0.f314I;
                    permissionRequest2.grant(permissionRequest2.getResources());
                }
            }
        }
    }

    @Override // android.webkit.WebChromeClient
    public final void onShowCustomView(View view, WebChromeClient.CustomViewCallback customViewCallback) {
        if (this.f249a != null) {
            onHideCustomView();
            return;
        }
        this.f249a = view;
        l lVar = this.f252e;
        this.f251d = lVar.getWindow().getDecorView().getSystemUiVisibility();
        this.f250c = lVar.getRequestedOrientation();
        this.b = customViewCallback;
        ((FrameLayout) lVar.getWindow().getDecorView()).addView(this.f249a, new FrameLayout.LayoutParams(-1, -1));
        lVar.getWindow().getDecorView().setSystemUiVisibility(3846);
    }

    /* JADX WARN: Type inference failed for: r5v1, types: [android.app.Activity, android.content.Context, com.mycompany.bet261mods.MainActivity] */
    @Override // android.webkit.WebChromeClient
    public final boolean onShowFileChooser(WebView webView, ValueCallback valueCallback, WebChromeClient.FileChooserParams fileChooserParams) {
        File fileO;
        ?? r5 = this.f252e;
        ValueCallback valueCallback2 = r5.f316y;
        Intent intent = null;
        if (valueCallback2 != null) {
            valueCallback2.onReceiveValue(null);
        }
        r5.f316y = valueCallback;
        Intent intent2 = new Intent("android.media.action.IMAGE_CAPTURE");
        if (intent2.resolveActivity(r5.getPackageManager()) != null) {
            try {
                fileO = MainActivity.o(r5);
                try {
                    intent2.putExtra("PhotoPath", r5.f317z);
                } catch (IOException e2) {
                    e = e2;
                    Log.e("MainActivity", "Unable to create Image File", e);
                }
            } catch (IOException e3) {
                e = e3;
                fileO = null;
            }
            if (fileO != null) {
                r5.f317z = "file:" + fileO.getAbsolutePath();
                intent2.putExtra("output", Uri.fromFile(fileO));
                intent = intent2;
            }
        } else {
            intent = intent2;
        }
        Intent intent3 = new Intent("android.intent.action.GET_CONTENT");
        intent3.addCategory("android.intent.category.OPENABLE");
        intent3.setType("*/*");
        Intent[] intentArr = intent != null ? new Intent[]{intent} : new Intent[0];
        Intent intent4 = new Intent("android.intent.action.CHOOSER");
        intent4.putExtra("android.intent.extra.INTENT", intent3);
        intent4.putExtra("android.intent.extra.TITLE", "Files Chooser");
        intent4.putExtra("android.intent.extra.INITIAL_INTENTS", intentArr);
        r5.startActivityForResult(intent4, 1);
        return true;
    }

    @Override // android.webkit.WebChromeClient
    public final void onCloseWindow(WebView webView) {
    }
}
