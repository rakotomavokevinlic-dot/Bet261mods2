package V;

import android.graphics.Insets;
import android.os.Build;
import android.view.View;
import com.mycompany.bet261mods.MainActivity;
import y.InterfaceC0164p;
import y.d0;
import y.f0;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final /* synthetic */ class g implements InterfaceC0164p {
    @Override // y.InterfaceC0164p
    public f0 a(View view, f0 f0Var) {
        boolean z2 = MainActivity.f305J;
        int i2 = Build.VERSION.SDK_INT;
        d0 d0Var = f0Var.f1202a;
        Insets insetsC = i2 >= 29 ? d0Var.f(8).c() : null;
        if (i2 >= 29) {
            d0Var.f(7).c();
        }
        if (i2 >= 29) {
            view.setPadding(0, 0, 0, insetsC.bottom);
        }
        return f0Var;
    }
}
