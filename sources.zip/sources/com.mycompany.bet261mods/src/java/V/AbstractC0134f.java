package v;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import e.C0011f;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import l.C0098f;
import l.C0103k;

/* JADX INFO: renamed from: v.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class AbstractC0134f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0098f f1150a = new C0098f(16);
    public static final ThreadPoolExecutor b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Object f1151c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final C0103k f1152d;

    static {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 10000, TimeUnit.MILLISECONDS, new LinkedBlockingDeque(), new ThreadFactoryC0137i());
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        b = threadPoolExecutor;
        f1151c = new Object();
        f1152d = new C0103k();
    }

    public static C0133e a(String str, Context context, W.d dVar, int i2) {
        C0098f c0098f = f1150a;
        Typeface typeface = (Typeface) c0098f.a(str);
        if (typeface != null) {
            return new C0133e(typeface);
        }
        try {
            C0011f c0011fA = AbstractC0130b.a(context, dVar);
            int i3 = 1;
            C0135g[] c0135gArr = (C0135g[]) c0011fA.b;
            int i4 = c0011fA.f491a;
            if (i4 != 0) {
                i3 = i4 != 1 ? -3 : -2;
            } else if (c0135gArr != null && c0135gArr.length != 0) {
                int length = c0135gArr.length;
                i3 = 0;
                int i5 = 0;
                while (true) {
                    if (i5 >= length) {
                        break;
                    }
                    int i6 = c0135gArr[i5].f1156e;
                    if (i6 == 0) {
                        i5++;
                    } else if (i6 >= 0) {
                        i3 = i6;
                    }
                }
            }
            if (i3 != 0) {
                return new C0133e(i3);
            }
            Typeface typefaceM = r.f.f1122a.m(context, c0135gArr, i2);
            if (typefaceM == null) {
                return new C0133e(-3);
            }
            c0098f.b(str, typefaceM);
            return new C0133e(typefaceM);
        } catch (PackageManager.NameNotFoundException unused) {
            return new C0133e(-1);
        }
    }
}
