package V;

import android.app.Notification;
import android.app.NotificationChannel;
import com.mycompany.bet261mods.MainActivity;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public abstract /* synthetic */ class a {
    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ Notification.Builder c(MainActivity mainActivity) {
        return new Notification.Builder(mainActivity, "MYCHANNEL");
    }

    public static /* synthetic */ NotificationChannel d() {
        return new NotificationChannel("MYCHANNEL", "name", 2);
    }
}
