package V;

import android.graphics.Color;
import android.view.View;
import android.view.WindowInsets;
import com.mycompany.bet261mods.MainActivity;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final /* synthetic */ class f implements View.OnApplyWindowInsetsListener {
    @Override // android.view.View.OnApplyWindowInsetsListener
    public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        boolean z2 = MainActivity.f305J;
        view.setBackgroundColor(Color.parseColor("#1a1a1a"));
        view.setPadding(0, windowInsets.getInsets(WindowInsets.Type.statusBars()).top, 0, 0);
        return windowInsets;
    }
}
