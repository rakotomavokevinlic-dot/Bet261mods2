package V;

import android.app.DownloadManager;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.webkit.CookieManager;
import android.widget.EditText;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertController;
import com.mycompany.bet261mods.MainActivity;
import e.C0007b;
import e.C0011f;
import e.DialogC0012g;
import i.L;
import i.Q;
import i.S;
import java.io.IOException;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class b implements DialogInterface.OnClickListener, Q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f243a;
    public Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f244c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f245d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f246e;

    public /* synthetic */ b(Object obj, String str, String str2, Object obj2, int i2) {
        this.f243a = i2;
        this.f246e = obj;
        this.b = str;
        this.f244c = str2;
        this.f245d = obj2;
    }

    @Override // i.Q
    public boolean a() {
        DialogC0012g dialogC0012g = (DialogC0012g) this.b;
        if (dialogC0012g != null) {
            return dialogC0012g.isShowing();
        }
        return false;
    }

    @Override // i.Q
    public CharSequence b() {
        return (CharSequence) this.f245d;
    }

    @Override // i.Q
    public void c(int i2) {
        Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
    }

    @Override // i.Q
    public int d() {
        return 0;
    }

    @Override // i.Q
    public void dismiss() {
        DialogC0012g dialogC0012g = (DialogC0012g) this.b;
        if (dialogC0012g != null) {
            dialogC0012g.dismiss();
            this.b = null;
        }
    }

    @Override // i.Q
    public void e(int i2, int i3) {
        if (((L) this.f244c) == null) {
            return;
        }
        S s2 = (S) this.f246e;
        C0011f c0011f = new C0011f(s2.getPopupContext());
        CharSequence charSequence = (CharSequence) this.f245d;
        C0007b c0007b = (C0007b) c0011f.b;
        if (charSequence != null) {
            c0007b.f463d = charSequence;
        }
        L l2 = (L) this.f244c;
        int selectedItemPosition = s2.getSelectedItemPosition();
        c0007b.f465g = l2;
        c0007b.f466h = this;
        c0007b.f468j = selectedItemPosition;
        c0007b.f467i = true;
        DialogC0012g dialogC0012gA = c0011f.a();
        this.b = dialogC0012gA;
        AlertController.RecycleListView recycleListView = dialogC0012gA.f.f473e;
        recycleListView.setTextDirection(i2);
        recycleListView.setTextAlignment(i3);
        ((DialogC0012g) this.b).show();
    }

    @Override // i.Q
    public void g(CharSequence charSequence) {
        this.f245d = charSequence;
    }

    @Override // i.Q
    public int i() {
        return 0;
    }

    @Override // i.Q
    public void j(Drawable drawable) {
        Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
    }

    @Override // i.Q
    public void k(int i2) {
        Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
    }

    @Override // i.Q
    public Drawable l() {
        return null;
    }

    @Override // i.Q
    public void m(ListAdapter listAdapter) {
        this.f244c = (L) listAdapter;
    }

    @Override // i.Q
    public void n(int i2) {
        Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i2) {
        switch (this.f243a) {
            case 0:
                try {
                    d.a((d) this.f246e, (String) this.b, (String) this.f244c, ((EditText) this.f245d).getText().toString());
                } catch (IOException e2) {
                    e2.printStackTrace();
                    return;
                }
                break;
            case 1:
                String str = (String) this.b;
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(str));
                request.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(str));
                request.addRequestHeader("User-Agent", (String) this.f244c);
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(1);
                DownloadManager downloadManager = (DownloadManager) ((MainActivity) this.f246e).getSystemService("download");
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, (String) this.f245d);
                downloadManager.enqueue(request);
                break;
            default:
                S s2 = (S) this.f246e;
                s2.setSelection(i2);
                if (s2.getOnItemClickListener() != null) {
                    s2.performItemClick(null, i2, ((L) this.f244c).getItemId(i2));
                }
                dismiss();
                break;
        }
    }

    public b(S s2) {
        this.f243a = 2;
        this.f246e = s2;
    }
}
