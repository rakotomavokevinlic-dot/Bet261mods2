package v;

import android.graphics.Typeface;

/* JADX INFO: renamed from: v.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0133e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Typeface f1149a;
    public final int b;

    public C0133e(int i2) {
        this.f1149a = null;
        this.b = i2;
    }

    public C0133e(Typeface typeface) {
        this.f1149a = typeface;
        this.b = 0;
    }
}
