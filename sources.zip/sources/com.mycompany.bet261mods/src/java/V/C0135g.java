package v;

import android.net.Uri;

/* JADX INFO: renamed from: v.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public final class C0135g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Uri f1153a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1154c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f1155d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f1156e;

    public C0135g(Uri uri, int i2, int i3, boolean z2, int i4) {
        uri.getClass();
        this.f1153a = uri;
        this.b = i2;
        this.f1154c = i3;
        this.f1155d = z2;
        this.f1156e = i4;
    }
}
