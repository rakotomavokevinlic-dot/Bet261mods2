package V;

import android.app.AlertDialog;
import android.util.Log;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebView;
import com.mycompany.bet261mods.MainActivity;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class i implements DownloadListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ MainActivity f253a;

    public i(MainActivity mainActivity) {
        this.f253a = mainActivity;
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [android.content.Context, com.mycompany.bet261mods.MainActivity, java.lang.Object] */
    @Override // android.webkit.DownloadListener
    public final void onDownloadStart(String str, String str2, String str3, String str4, long j2) {
        String str5;
        Log.v("MainActivity", "Permission is granted");
        ?? r1 = this.f253a;
        if (!str.startsWith("blob")) {
            String strGuessFileName = URLUtil.guessFileName(str, str3, str4);
            AlertDialog.Builder builder = new AlertDialog.Builder(r1);
            builder.setTitle("Download");
            builder.setMessage("Download File " + strGuessFileName);
            builder.setPositiveButton("Yes", new b(r1, str, str2, strGuessFileName, 1));
            builder.setNegativeButton("No", new c(1));
            builder.show();
            return;
        }
        WebView webView = r1.f315x;
        if (str.startsWith("blob")) {
            str5 = "javascript: var xhr = new XMLHttpRequest();xhr.open('GET', '" + str + "', true);xhr.setRequestHeader('Content-type','" + str4 + "');xhr.responseType = 'blob';xhr.onload = function(e) {    if (this.status == 200) {        var blobData = this.response;        var reader = new FileReader();        reader.readAsDataURL(blobData);        reader.onloadend = function() {            base64data = reader.result;            Android.getBase64FromBlobData(base64data, '" + str4 + "');        }    }};xhr.send();";
        } else {
            str5 = "javascript: console.log('It is not a Blob URL');";
        }
        webView.loadUrl(str5);
    }
}
