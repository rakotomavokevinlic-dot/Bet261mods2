package s;

import android.graphics.drawable.Drawable;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/1.dex */
public abstract class e extends Drawable implements Drawable.Callback, d {
    public abstract void a(Drawable drawable);
}
