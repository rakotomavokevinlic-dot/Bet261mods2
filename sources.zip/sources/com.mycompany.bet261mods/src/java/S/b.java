package S;

import android.os.Parcel;
import android.util.SparseIntArray;
import l.C0094b;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.mycompany.bet261mods/dex-files/0.dex */
public final class b extends a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final SparseIntArray f162d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Parcel f163e;
    public final int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f164g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final String f165h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f166i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f167j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f168k;

    public b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new C0094b(), new C0094b(), new C0094b());
    }

    @Override // S.a
    public final b a() {
        Parcel parcel = this.f163e;
        int iDataPosition = parcel.dataPosition();
        int i2 = this.f167j;
        if (i2 == this.f) {
            i2 = this.f164g;
        }
        return new b(parcel, iDataPosition, i2, this.f165h + "  ", this.f160a, this.b, this.f161c);
    }

    @Override // S.a
    public final boolean e(int i2) {
        while (this.f167j < this.f164g) {
            int i3 = this.f168k;
            if (i3 == i2) {
                return true;
            }
            if (String.valueOf(i3).compareTo(String.valueOf(i2)) > 0) {
                return false;
            }
            int i4 = this.f167j;
            Parcel parcel = this.f163e;
            parcel.setDataPosition(i4);
            int i5 = parcel.readInt();
            this.f168k = parcel.readInt();
            this.f167j += i5;
        }
        return this.f168k == i2;
    }

    @Override // S.a
    public final void h(int i2) {
        int i3 = this.f166i;
        SparseIntArray sparseIntArray = this.f162d;
        Parcel parcel = this.f163e;
        if (i3 >= 0) {
            int i4 = sparseIntArray.get(i3);
            int iDataPosition = parcel.dataPosition();
            parcel.setDataPosition(i4);
            parcel.writeInt(iDataPosition - i4);
            parcel.setDataPosition(iDataPosition);
        }
        this.f166i = i2;
        sparseIntArray.put(i2, parcel.dataPosition());
        parcel.writeInt(0);
        parcel.writeInt(i2);
    }

    public b(Parcel parcel, int i2, int i3, String str, C0094b c0094b, C0094b c0094b2, C0094b c0094b3) {
        super(c0094b, c0094b2, c0094b3);
        this.f162d = new SparseIntArray();
        this.f166i = -1;
        this.f168k = -1;
        this.f163e = parcel;
        this.f = i2;
        this.f164g = i3;
        this.f167j = i2;
        this.f165h = str;
    }
}
